# second-brain · 公开源码摘录

本地优先的收藏夹转 Obsidian 管线。本包公开 14 个处理模块与工程配置，用于展示实现，不含任何收藏内容或个人 Vault。

## 包含

- `second_brain/*.py`：采集、转写、OCR、清洗、切分、分析、Vault 写入与端到端编排
- `CLAUDE.md` / `second_brain/CLAUDE.md`：关键约束与模块地图
- `pyproject.toml` / `Modelfile`：依赖与本地模型配置

## 有意排除

- `../SecondBrain/`：默认 Obsidian Vault，含收藏原文与个人批注
- `tests/`：用例可能引用本地素材
- `swift/`、`*.egg-info`、运行缓存与临时目录

## 说明

图片与音频只在本机处理；音频每 10 分钟切片、文本每 8000 字切段，原始转写与分段分析全部留底。
原文、摘要、个人判断三层分离；新概念需本人确认后才建双链。设计说明见作品集案例页。
