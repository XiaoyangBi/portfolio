"""[INPUT] 知乎、小红书和普通网页链接，以及可选 Cookie。
[OUTPUT] 正文、图片 OCR、附件和可转写的视频路径。
[POS] 网页采集层；优先公开正文，不模拟账号操作。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from .models import Source, Transcript
from .ocr import recognize_images
from .util import safe_filename, stable_id

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/131 Safari/537.36"
WECHAT_UA = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.44"
)


@dataclass
class WebResult:
    source: Source
    transcript: Transcript | None = None
    video_path: Path | None = None
    attachments: list[str] = field(default_factory=list)
    ocr_results: list[dict[str, str | int]] = field(default_factory=list)


def platform_for_url(url: str) -> str:
    host = urlparse(url).netloc.lower()
    if "xiaohongshu.com" in host or "xhslink.com" in host:
        return "xiaohongshu"
    if "mp.weixin.qq.com" in host:
        return "wechat"
    if "feishu.cn" in host or "larksuite.com" in host:
        return "feishu"
    if "zhihu.com" in host:
        return "zhihu"
    if "youtube.com" in host or "youtu.be" in host:
        return "youtube"
    if "bilibili.com" in host or "b23.tv" in host:
        return "bilibili"
    return "web"


def find_note(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        if "imageList" in value and ("desc" in value or "title" in value):
            return value
        for child in value.values():
            found = find_note(child)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = find_note(child)
            if found:
                return found
    return None


def find_video_url(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("masterUrl", "master_url", "originVideoKey"):
            candidate = value.get(key)
            if isinstance(candidate, str) and candidate.startswith("http"):
                return candidate
        for child in value.values():
            found = find_video_url(child)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = find_video_url(child)
            if found:
                return found
    return ""


def image_urls(note: dict[str, Any]) -> list[str]:
    urls: list[str] = []
    for image in note.get("imageList", []):
        candidates: list[str] = []
        if isinstance(image, dict):
            candidates.extend(image.get(key, "") for key in ("urlDefault", "urlPre", "url"))
            for info in image.get("infoList", []):
                if isinstance(info, dict):
                    candidates.append(info.get("url", ""))
        for candidate in candidates:
            if isinstance(candidate, str) and candidate.startswith("http"):
                urls.append(candidate.replace("&amp;", "&"))
                break
    return list(dict.fromkeys(urls))


def clean_text(value: str | None) -> str:
    if not value:
        return ""
    value = value.replace("\r", "\n")
    value = re.sub(r"[ \t]+\n", "\n", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def wechat_meta(soup: BeautifulSoup) -> tuple[str, str]:
    """公众号页面在脚本文本里保存昵称与发布时间，需要在清理脚本前取。"""
    nickname = ""
    published = ""
    node = soup.select_one("#js_name")
    if node:
        nickname = node.get_text(" ", strip=True)
    for script in soup.find_all("script"):
        content = script.string or script.get_text() or ""
        if not content:
            continue
        if not nickname:
            match = re.search(r'var nickname = htmlDecode\("([^"]*)"\)', content)
            if match:
                nickname = match.group(1)
        if not published:
            match = re.search(r"var createTime = '([^']*)'", content)
            if match:
                published = match.group(1)
    return clean_text(nickname), clean_text(published)


class WebExtractor:
    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.7"})
        cookie = os.environ.get("SECOND_BRAIN_COOKIE", "")
        cookie_file = os.environ.get("SECOND_BRAIN_COOKIE_FILE", "")
        if cookie_file and not cookie:
            cookie = Path(cookie_file).read_text(encoding="utf-8").strip()
        if cookie:
            self.session.headers["Cookie"] = cookie

    def fetch(self, url: str) -> requests.Response:
        headers: dict[str, str] = {}
        if "mp.weixin.qq.com" in url:
            headers["User-Agent"] = WECHAT_UA
            headers["Referer"] = "https://mp.weixin.qq.com/"
        response = self.session.get(url, timeout=45, headers=headers or None)
        response.raise_for_status()
        return response

    def extract(self, url: str, assets_root: Path) -> WebResult:
        response = self.fetch(url)
        final_url = response.url
        platform = platform_for_url(final_url)
        soup = BeautifulSoup(response.text, "lxml")
        source_id = stable_id(final_url)
        assets_dir = assets_root / source_id
        if platform == "xiaohongshu":
            return self.extract_xiaohongshu(final_url, soup, assets_dir)
        return self.extract_article(final_url, platform, soup)

    def extract_article(self, url: str, platform: str, soup: BeautifulSoup) -> WebResult:
        wechat_nickname, wechat_published = ("", "")
        if platform == "wechat":
            wechat_nickname, wechat_published = wechat_meta(soup)
        for element in soup(["script", "style", "noscript", "svg", "nav", "footer"]):
            element.decompose()
        selectors = [
            "div.Post-RichText", "div.RichContent", "div.rich_media_content", "#js_content",
            "article", "main", "div.article-content", "div.content",
        ]
        body = next((soup.select_one(selector) for selector in selectors if soup.select_one(selector)), None)
        body = body or soup.body or soup
        title_node = soup.find("meta", property="og:title")
        title = title_node.get("content", "") if title_node else ""
        if not title:
            heading = soup.find("h1")
            title = heading.get_text(" ", strip=True) if heading else (soup.title.string if soup.title else url)
        author_node = soup.find("meta", attrs={"name": "author"})
        description_node = soup.find("meta", attrs={"name": "description"})
        text = clean_text(body.get_text("\n", strip=True))
        if not text:
            raise RuntimeError("Article text is unavailable. Supply login Cookie or save the page as HTML.")
        source = Source(
            url=url,
            platform=platform,
            title=clean_text(title) or url,
            author=clean_text(author_node.get("content", "")) if author_node and author_node.get("content") else wechat_nickname,
            description=description_node.get("content", "") if description_node else "",
            published_at=wechat_published,
            source_id=stable_id(url),
        )
        return WebResult(source=source, transcript=Transcript(text=text, source_type="web"))

    def extract_xiaohongshu(self, url: str, soup: BeautifulSoup, assets_dir: Path) -> WebResult:
        note: dict[str, Any] | None = None
        for script in soup.find_all("script"):
            content = script.string or script.get_text()
            match = re.search(r"window\.__INITIAL_STATE__\s*=\s*", content)
            if not match:
                continue
            payload = content[match.end():].replace("undefined", "null")
            try:
                data, _ = json.JSONDecoder().raw_decode(payload)
            except json.JSONDecodeError:
                continue
            note = find_note(data)
            if note:
                break
        title = str(note.get("title", "")) if note else ""
        description = str(note.get("desc", "")) if note else ""
        if not note:
            title_node = soup.find("meta", property="og:title")
            description_node = soup.find("meta", property="og:description")
            title = title_node.get("content", "") if title_node else ""
            description = description_node.get("content", "") if description_node else ""
        source = Source(
            url=url,
            platform="xiaohongshu",
            title=title or "小红书收藏",
            description=description,
            source_id=stable_id(url),
        )
        assets_dir.mkdir(parents=True, exist_ok=True)
        paths: list[Path] = []
        urls = image_urls(note) if note else []
        if not urls:
            urls = [node.get("content", "") for node in soup.find_all("meta", property="og:image")]
            urls = [item for item in urls if item.startswith("http")]
            if urls:
                source.metadata["collection_warning"] = "页面图集解析失败，仅识别公开封面。请使用带 xsec_token 的分享链接和有效 Cookie 后重跑。"
        for index, image_url in enumerate(dict.fromkeys(urls), start=1):
            image_response = self.fetch(image_url)
            path = assets_dir / f"image_{index:03d}.jpg"
            path.write_bytes(image_response.content)
            paths.append(path)
        ocr_results = recognize_images(paths) if paths else []
        video_url = find_video_url(note) if note else ""
        video_path: Path | None = None
        if video_url:
            video_response = self.fetch(video_url)
            video_path = assets_dir / "video.mp4"
            video_path.write_bytes(video_response.content)
        if not urls and description and not video_path:
            source.metadata["collection_warning"] = "页面图集解析失败且未发现公开封面，当前仅保存正文；图片内容未进入 OCR。请使用带 xsec_token 的分享链接和有效 Cookie 后重跑。"
        if not description and not ocr_results and not video_path:
            raise RuntimeError("Xiaohongshu content is unavailable. Use the share URL with xsec_token and a valid Cookie.")
        text_parts = [description] if description else []
        text_parts.extend(f"[图片 {item['index']}]\n{item['text']}" for item in ocr_results if item["text"])
        transcript = Transcript(text="\n\n".join(text_parts), source_type="ocr" if ocr_results else "web")
        return WebResult(
            source=source,
            transcript=transcript if text_parts else None,
            video_path=video_path,
            attachments=[path.name for path in paths],
            ocr_results=ocr_results,
        )


def source_from_html(path: Path, url: str = "") -> WebResult:
    soup = BeautifulSoup(path.read_text(encoding="utf-8"), "lxml")
    extractor = WebExtractor()
    source_url = url or f"file://{path.resolve()}"
    platform = platform_for_url(source_url) if url else "html"
    return extractor.extract_article(source_url, platform, soup)


def attachment_markdown(source: Source, names: list[str]) -> list[str]:
    return [f"[[90_附件/{source.source_id}/{safe_filename(name)}|{name}]]" for name in names]
