"""[INPUT] 命令行参数、本地路径、URL 与环境变量。
[OUTPUT] ingest、promote、remerge、reflect、distill、ocr、doctor 七类操作。
[POS] 用户入口；只解析参数并调用应用层。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import shutil
import sys
from pathlib import Path

import requests

from . import __version__
from .ocr import ocr_binary, recognize_images
from .pipeline import IngestOptions, Pipeline
from .transcribe import DEFAULT_MAX_MINUTES


def default_vault() -> Path:
    return Path(__file__).resolve().parents[2] / "SecondBrain"


def add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--vault", type=Path, default=default_vault(), help="Obsidian Vault 路径")
    parser.add_argument("--ai-model", default="qwen3:4b", help="本机 Ollama 模型")
    parser.add_argument("--whisper-model", default="small", help="本地 faster-whisper 模型")
    parser.add_argument("--max-minutes", type=float, default=DEFAULT_MAX_MINUTES, help="单集最多处理分钟数")
    parser.add_argument("--language", help="音频语言代码，默认自动检测")
    parser.add_argument("--cookies-from-browser", default="", help="yt-dlp 浏览器名，例如 chrome")
    parser.add_argument("--no-ai", action="store_true", help="只入库原文，不生成 AI 摘要")
    parser.add_argument("--force", action="store_true", help="重新生成已有笔记，保留我的批注")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="second-brain", description="本地收藏内容转 Obsidian")
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)

    ingest = commands.add_parser("ingest", help="处理一个或多个 URL 或本地文件")
    ingest.add_argument("sources", nargs="+")
    add_common(ingest)
    ingest.add_argument("--title", default="", help="本地文件标题")
    ingest.add_argument("--author", default="", help="本地文件作者")
    ingest.add_argument("--description", default="", help="本地文件简介，供转写识别专有名词")
    ingest.add_argument("--source-url", default="", help="本地文件原始链接")

    promote = commands.add_parser("promote", help="升格笔记中已勾选的概念")
    promote.add_argument("--vault", type=Path, default=default_vault())

    extract = commands.add_parser("extract", help="把已勾选的提炼提案建为原子笔记")
    extract.add_argument("record_id")
    extract.add_argument("--topic", default="", help="主题标签，如 个人Agent；缺省写 未分类")
    extract.add_argument("--vault", type=Path, default=default_vault())

    verify = commands.add_parser("verify", help="巡检提炼提案的证据是否都能回到原文")
    verify.add_argument("--vault", type=Path, default=default_vault())

    audit = commands.add_parser("audit", help="只读体检：断链、孤儿页、缺标签、待补摘要")
    audit.add_argument("--write", action="store_true", help="把报告写到 99_系统/reports/")
    audit.add_argument("--vault", type=Path, default=default_vault())

    remerge = commands.add_parser("remerge", help="复用逐段结果，只重跑合并分析")
    remerge.add_argument("record_id")
    add_common(remerge)

    reflect = commands.add_parser("reflect", help="召回个人记忆，生成独立的与我相关区块")
    reflect.add_argument("record_id")
    reflect.add_argument("--memory-root", type=Path, default=Path.home() / "personal-memory")
    reflect.add_argument("--memory", action="append", default=[], help="记忆选择器，可重复传入")
    add_common(reflect)

    distill = commands.add_parser("distill", help="生成候选记忆报告，不写入 personal-memory")
    distill.add_argument("record_id")
    add_common(distill)

    ocr = commands.add_parser("ocr", help="本地识别一张或多张图片")
    ocr.add_argument("images", nargs="+", type=Path)

    commands.add_parser("doctor", help="检查本地运行依赖")
    return parser


def options_from(args: argparse.Namespace) -> IngestOptions:
    return IngestOptions(
        vault=args.vault,
        whisper_model=args.whisper_model,
        ai_model=args.ai_model,
        max_minutes=args.max_minutes,
        no_ai=args.no_ai,
        cookies_from_browser=args.cookies_from_browser,
        language=args.language,
        force=args.force,
        title=getattr(args, "title", ""),
        author=getattr(args, "author", ""),
        description=getattr(args, "description", ""),
        source_url=getattr(args, "source_url", ""),
    )


def doctor() -> int:
    checks: list[tuple[str, bool, str]] = []
    for name in ("ffmpeg", "ffprobe", "ollama"):
        path = shutil.which(name)
        checks.append((name, bool(path), path or "未安装"))
    for name in ("faster_whisper", "yt_dlp", "bs4", "requests"):
        available = importlib.util.find_spec(name) is not None
        checks.append((name, available, "可用" if available else "缺少 Python 包"))
    try:
        checks.append(("macOS Vision OCR", True, str(ocr_binary())))
    except RuntimeError as error:
        checks.append(("macOS Vision OCR", False, str(error)))
    try:
        response = requests.get("http://127.0.0.1:11434/api/tags", timeout=3)
        response.raise_for_status()
        models = [item.get("name", "") for item in response.json().get("models", [])]
        checks.append(("Ollama 模型", bool(models), ", ".join(models) or "服务已启动，尚未下载模型"))
    except requests.RequestException as error:
        checks.append(("Ollama 服务", False, str(error)))
    for name, ok, detail in checks:
        print(f"{'OK' if ok else 'MISS'}  {name}: {detail}")
    return 0 if all(item[1] for item in checks) else 1


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            return doctor()
        if args.command == "ocr":
            results = recognize_images([path.expanduser().resolve() for path in args.images])
            print(json.dumps(results, ensure_ascii=False, indent=2))
            return 0
        if args.command == "promote":
            from .vault import Vault

            promoted = Vault(args.vault).promote()
            print(json.dumps({"promoted": promoted}, ensure_ascii=False))
            return 0
        if args.command == "extract":
            from .vault import Vault

            result = Vault(args.vault).extract(args.record_id, topic=args.topic)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "verify":
            from .vault import Vault

            result = Vault(args.vault).verify_proposals()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "audit":
            from .util import atomic_text, today
            from .vault import Vault

            vault = Vault(args.vault)
            result = vault.audit()
            if args.write:
                report_dir = vault.root / "99_系统" / "reports"
                report_dir.mkdir(parents=True, exist_ok=True)
                path = report_dir / f"{today()}-audit.md"
                atomic_text(path, vault.audit_report(result))
                result["report"] = path.relative_to(vault.root).as_posix()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        pipeline = Pipeline(options_from(args))
        if args.command == "remerge":
            print(pipeline.remerge(args.record_id))
            return 0
        if args.command == "reflect":
            print(pipeline.reflect(args.record_id, args.memory_root, args.memory))
            return 0
        if args.command == "distill":
            print(pipeline.distill(args.record_id))
            return 0
        for source in args.sources:
            notes = pipeline.ingest(source)
            for note in notes:
                print(note)
        return 0
    except Exception as error:
        print(f"错误：{error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
