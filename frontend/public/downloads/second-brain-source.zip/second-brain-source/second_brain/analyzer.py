"""[INPUT] 清洗全文、语义分段和本机 Ollama JSON 接口。
[OUTPUT] 逐段分析、合并摘要、要点、概念、人物和工具。
[POS] 文本理解层；每段留底，合并规则可独立重跑。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

import requests

from .chunking import DEFAULT_CHUNK_CHARS, chunk_segments, chunk_text
from .models import Analysis, Transcript
from .util import atomic_json, read_json, stable_id


def parse_json_object(content: str) -> dict[str, Any]:
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", content.strip())
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start < 0 or end < start:
        raise ValueError("Model response does not contain a JSON object")
    return json.loads(cleaned[start:end + 1])


def string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))


def concept_list(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    output: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in value:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip()
        if not name or name in seen:
            continue
        seen.add(name)
        output.append({
            "name": name,
            "definition": str(item.get("definition", "")).strip(),
            "evidence": str(item.get("evidence", "")).strip(),
            "origin": str(item.get("origin", "归纳")).strip() or "归纳",
        })
    return output


def normalize_analysis(data: dict[str, Any], status: str = "done") -> Analysis:
    return Analysis(
        summary=str(data.get("summary", "")).strip(),
        key_points=string_list(data.get("key_points")),
        concepts=concept_list(data.get("concepts")),
        people=string_list(data.get("people")),
        tools=string_list(data.get("tools")),
        status=status,
    )


class OllamaAnalyzer:
    def __init__(self, model: str = "qwen3:4b", base_url: str = "http://127.0.0.1:11434") -> None:
        self.model = model
        self.base_url = base_url.rstrip("/")

    def generate(self, prompt: str) -> dict[str, Any]:
        # 按输入长度给上下文窗口，避免固定 32K 拖慢 CPU 上的预填充
        estimated = int(len(prompt) / 1.6) + 2048
        num_ctx = max(8192, min(32768, int(estimated * 1.25)))
        response = requests.post(
            f"{self.base_url}/api/chat",
            json={
                "model": self.model,
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
                "format": "json",
                "think": False,
                "keep_alive": "30m",
                "options": {"temperature": 0.1, "num_ctx": num_ctx, "num_predict": 2048},
            },
            timeout=int(os.environ.get("SECOND_BRAIN_AI_TIMEOUT", "1800")),
        )
        response.raise_for_status()
        payload = response.json()
        if payload.get("done_reason") == "length":
            raise RuntimeError("Model output reached the length limit; analysis was not accepted")
        return parse_json_object(payload["message"]["content"])

    def analyze_chunk(self, text: str, index: int, count: int) -> Analysis:
        prompt = f"""你在阅读一条收藏内容的第 {index}/{count} 段。只允许依据所给文本提取，不得补充外部知识。
输出一个 JSON 对象，字段如下：
summary：本段摘要，150字以内。必须概括本段主线和最终结论，不得只概括开头。
key_points：本段要点数组，最多8条。先通读到末尾再提取，至少3条必须来自本段后三分之一；后三分之一不足3条则全部保留，再补充前部要点。保留独特判断、数字、条件和反常识结论，不写成空泛概括。若原文列出多个问题、方法或步骤，每一项的现象、原因和解决办法都要覆盖。不得拼接不同句子的主语和结论。
concepts：概念数组，只收原文实际解释或定义的术语，仅被提及的词不要收。每项包含 name、definition、evidence、origin。evidence 必须逐字复制原文中的连续句子，不得改写或拼接；origin 只能填“原文”或“归纳”。不满足证据要求或没有概念就返回空数组。
people：文本明确提到的人物姓名数组。
tools：文本明确提到的软件、模型或工具名称数组。
不要输出 JSON 以外的内容。

本段原文：
{text}"""
        analysis = normalize_analysis(self.generate(prompt), status="chunk_done")
        normalized_text = re.sub(r"\s+", "", text)
        analysis.concepts = [
            item for item in analysis.concepts
            if item["evidence"] and re.sub(r"\s+", "", item["evidence"]) in normalized_text
        ]
        return analysis

    def merge_chunks(self, analyses: list[Analysis]) -> Analysis:
        payload = [item.to_dict() for item in analyses]
        prompt = f"""你要合并一条长内容的全部分段分析。输入已经覆盖原文首尾，不得只保留靠前主题。
合并重复项，但保留嘉宾特有的判断、少数观点和出现在尾段的新主题。不要把不同观点平均成空泛共识，不要创造分段分析中不存在的因果关系。
输出一个 JSON 对象：
summary：全文摘要，300字以内。概括全文主线、关键方法和最终结论，不得只概括开头。
key_points：全文要点数组，最多30条，不机械压缩成5条。按原文顺序覆盖开头、中段和结尾；若原文列出多个问题、方法或步骤，每一项的现象、原因和解决办法都要保留，尾段结论不得遗漏。
concepts：去重后的概念数组，每项保留 name、definition、evidence、origin。
people：人物姓名数组。
tools：软件、模型或工具名称数组。
不要输出 JSON 以外的内容。

分段分析：
{json.dumps(payload, ensure_ascii=False)}"""
        return normalize_analysis(self.generate(prompt))

    def analyze(
        self,
        transcript: Transcript,
        work_dir: Path,
        max_chars: int = DEFAULT_CHUNK_CHARS,
        force_merge: bool = False,
    ) -> Analysis:
        chunks = chunk_segments(transcript.segments, max_chars) if transcript.segments else chunk_text(transcript.text, max_chars)
        if not chunks:
            raise ValueError("No text available for analysis")
        atomic_json(work_dir / "analysis_inputs.json", [
            {"index": item.index, "start": item.start, "end": item.end, "chars": len(item.text), "text": item.text}
            for item in chunks
        ])
        analyses: list[Analysis] = []
        fingerprints: list[str] = []
        for chunk in chunks:
            path = work_dir / f"analysis_{chunk.index:03d}.json"
            fingerprint = stable_id(f"chunk-v3|{self.model}|{chunk.text}")
            fingerprints.append(fingerprint)
            cached: Analysis | None = None
            if path.exists():
                payload = read_json(path)
                if payload.get("_fingerprint") == fingerprint:
                    cached = Analysis.from_dict(payload)
            if cached is not None:
                analyses.append(cached)
                continue
            analysis = self.analyze_chunk(chunk.text, chunk.index, len(chunks))
            atomic_json(path, {
                **analysis.to_dict(),
                "_fingerprint": fingerprint,
                "_model": self.model,
            })
            analyses.append(analysis)
        merged_path = work_dir / "merged_analysis.json"
        merged_fingerprint = stable_id(f"merge-v3|{self.model}|{'|'.join(fingerprints)}")
        if merged_path.exists() and not force_merge:
            payload = read_json(merged_path)
            if payload.get("_fingerprint") == merged_fingerprint:
                return Analysis.from_dict(payload)
        merged = self.merge_chunks(analyses)
        atomic_json(merged_path, {
            **merged.to_dict(),
            "chunk_count": len(chunks),
            "covered_chars": sum(len(item.text) for item in chunks),
            "last_timestamp": max(item.end for item in chunks),
            "_fingerprint": merged_fingerprint,
            "_model": self.model,
        })
        return merged
