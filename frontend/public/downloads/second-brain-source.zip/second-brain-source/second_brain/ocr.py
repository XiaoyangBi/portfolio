"""[INPUT] 本地图片与工作区编译的 macOS Vision OCR 可执行文件。
[OUTPUT] 每张图片的独立 OCR 结果。
[POS] 图片文字化层；不上传图片，不调用云端 OCR。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path


def ocr_binary() -> Path:
    configured = os.environ.get("SECOND_BRAIN_OCR_BIN")
    path = Path(configured) if configured else Path(__file__).resolve().parent.parent / ".build" / "vision-ocr"
    if not path.exists():
        raise RuntimeError("Local OCR is missing. Run install.sh on macOS first.")
    return path


def recognize_image(image: Path) -> str:
    result = subprocess.run(
        [str(ocr_binary()), str(image)],
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def recognize_images(images: list[Path]) -> list[dict[str, str | int]]:
    results: list[dict[str, str | int]] = []
    for index, image in enumerate(images, start=1):
        results.append({"image": image.name, "index": index, "text": recognize_image(image)})
    return results
