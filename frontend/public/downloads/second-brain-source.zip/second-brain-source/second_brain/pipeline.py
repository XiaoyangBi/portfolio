"""[INPUT] URL、本地媒体、网页正文、OCR 与转写分析模块。
[OUTPUT] 每条收藏的可续跑记录和 Obsidian 原始笔记。
[POS] 应用编排层；控制分集、清洗、分析、入库和失败留痕。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from urllib.parse import urlparse

from .analyzer import OllamaAnalyzer, string_list
from .cleaning import clean_transcript, removed_segments
from .media import MediaItem, iter_media, parse_vtt
from .memory_bridge import PersonalMemoryBridge
from .models import Segment, Source, Transcript
from .ocr import recognize_images
from .transcribe import DEFAULT_MAX_MINUTES, load_transcript, transcribe_audio
from .util import atomic_json, atomic_text, now_iso, read_json, stable_id
from .vault import Vault
from .web import WebExtractor, platform_for_url, source_from_html

MEDIA_EXTENSIONS = {".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg", ".aiff", ".aif", ".mp4", ".mov", ".mkv", ".m4s"}
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff"}
TEXT_EXTENSIONS = {".txt", ".md"}


def connection_list(value) -> list[str]:
    if not isinstance(value, list):
        return []
    output: list[str] = []
    for item in value:
        if isinstance(item, dict):
            memory = str(item.get("memory", "")).strip()
            reason = str(item.get("reason", "")).strip()
            text = f"{memory}：{reason}" if memory and reason else memory or reason
        else:
            text = str(item).strip()
        if text and text not in output:
            output.append(text)
    return output


@dataclass
class IngestOptions:
    vault: Path
    whisper_model: str = "small"
    ai_model: str = "qwen3:4b"
    max_minutes: float = DEFAULT_MAX_MINUTES
    no_ai: bool = False
    cookies_from_browser: str = ""
    language: str | None = None
    force: bool = False
    title: str = ""
    author: str = ""
    description: str = ""
    source_url: str = ""


class Pipeline:
    def __init__(self, options: IngestOptions) -> None:
        self.options = options
        self.vault = Vault(options.vault)

    def ingest(self, value: str) -> list[Path]:
        parsed = urlparse(value)
        if parsed.scheme in {"http", "https"}:
            platform = platform_for_url(value)
            if platform in {"bilibili", "youtube"}:
                notes: list[Path] = []
                for item in iter_media(value, self.vault.root / "99_系统" / "cache", self.options.cookies_from_browser):
                    notes.append(self.process_media(item))
                return notes
            return [self.process_web(value)]
        path = Path(value).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(path)
        return [self.process_local(path)]

    def process_local(self, path: Path) -> Path:
        suffix = path.suffix.lower()
        source_url = self.options.source_url or f"file://{path}"
        if suffix in {".html", ".htm"}:
            result = source_from_html(path, self.options.source_url)
            if self.options.title:
                result.source.title = self.options.title
            return self.process_web_result(result)
        source = Source(
            url=source_url,
            platform=platform_for_url(source_url) if self.options.source_url else "local",
            title=self.options.title or path.stem,
            author=self.options.author,
            description=self.options.description,
            source_id=stable_id(source_url),
            metadata={"local_path": str(path)},
        )
        if suffix in TEXT_EXTENSIONS:
            transcript = Transcript(text=path.read_text(encoding="utf-8"), source_type="text")
            return self.process_transcript(source, transcript, transcript)
        if suffix in IMAGE_EXTENSIONS:
            result = recognize_images([path])
            text = "\n".join(str(item["text"]) for item in result if item["text"])
            transcript = Transcript(text=text, source_type="ocr")
            return self.process_transcript(source, transcript, transcript)
        if suffix == ".vtt":
            transcript = parse_vtt(path)
            return self.process_transcript(source, transcript, transcript)
        if suffix not in MEDIA_EXTENSIONS:
            raise ValueError(f"Unsupported local file type: {suffix}")
        return self.process_media(MediaItem(source=source, audio_path=path))

    def process_web(self, url: str) -> Path:
        extractor = WebExtractor()
        result = extractor.extract(url, self.vault.root / "90_附件")
        return self.process_web_result(result)

    def process_web_result(self, result) -> Path:
        source = result.source
        if result.attachments:
            source.metadata["attachments"] = result.attachments
        record = self.vault.record_dir(source)
        atomic_json(record / "source.json", asdict(source))
        if result.ocr_results:
            atomic_json(record / "ocr_results.json", result.ocr_results)
        if result.video_path:
            audio_raw = transcribe_audio(
                result.video_path,
                source,
                record,
                self.options.whisper_model,
                self.options.max_minutes,
                self.options.language,
            )
            atomic_json(record / "audio_raw_transcript.json", audio_raw.to_dict())
            audio_clean = clean_transcript(audio_raw)
            prefix = result.transcript.text if result.transcript else ""
            raw = self.add_prefix(audio_raw, prefix)
            cleaned = self.add_prefix(audio_clean, prefix)
            return self.process_transcript(source, raw, cleaned, result.attachments)
        if not result.transcript or not result.transcript.text:
            raise ValueError("No text or video found at the source")
        return self.process_transcript(source, result.transcript, result.transcript, result.attachments)

    def add_prefix(self, transcript: Transcript, prefix: str) -> Transcript:
        if not prefix:
            return transcript
        segment = Segment(start=0.0, end=0.0, text=prefix)
        return Transcript(
            text=prefix + "\n\n" + transcript.text,
            segments=[segment] + transcript.segments,
            source_type="mixed",
            language=transcript.language,
            truncated=transcript.truncated,
            original_duration=transcript.original_duration,
            processed_duration=transcript.processed_duration,
        )

    def limit_subtitles(self, source: Source, transcript: Transcript) -> Transcript:
        limit = self.options.max_minutes * 60
        original = float(source.metadata.get("duration") or 0.0)
        original = max(original, max((item.end for item in transcript.segments), default=0.0))
        if original <= limit:
            return transcript
        segments = [item for item in transcript.segments if item.end <= limit]
        return Transcript(
            text="\n".join(item.text for item in segments),
            segments=segments,
            source_type=transcript.source_type,
            language=transcript.language,
            truncated=True,
            original_duration=original,
            processed_duration=limit,
        )

    def process_media(self, item: MediaItem) -> Path:
        source = item.source
        if item.transcript:
            limited = self.limit_subtitles(source, item.transcript)
            return self.process_transcript(source, limited, limited)
        if not item.audio_path:
            raise ValueError("Media item has neither subtitles nor audio")
        record = self.vault.record_dir(source)
        raw = transcribe_audio(
            item.audio_path,
            source,
            record,
            self.options.whisper_model,
            self.options.max_minutes,
            self.options.language,
        )
        cleaned = clean_transcript(raw)
        return self.process_transcript(source, raw, cleaned)

    def process_transcript(
        self,
        source: Source,
        raw: Transcript,
        cleaned: Transcript,
        attachments: list[str] | None = None,
    ) -> Path:
        note = self.vault.note_path(source)
        if note.exists() and not self.options.force:
            return note
        record = self.vault.record_dir(source)
        atomic_json(record / "source.json", asdict(source))
        atomic_json(record / "raw_transcript.json", raw.to_dict())
        atomic_json(record / "cleaned_transcript.json", cleaned.to_dict())
        atomic_json(record / "removed_segments.json", [item.to_dict() for item in removed_segments(cleaned)])
        atomic_json(record / "job_status.json", {"status": "processing", "updated_at": now_iso()})
        try:
            if not cleaned.text.strip():
                raise ValueError("Transcript is empty after collection and cleaning")
            if self.options.no_ai:
                from .models import Analysis

                analysis = Analysis(summary="尚未生成摘要（使用了 --no-ai）。", status="pending_analysis")
            else:
                from .models import Analysis

                try:
                    analysis = OllamaAnalyzer(self.options.ai_model).analyze(cleaned, record)
                except Exception as ai_error:
                    # 摘要失败不应吞掉已经采集到的原文，先入库，摘要留待重跑补
                    atomic_json(record / "analysis_error.json", {
                        "error": str(ai_error),
                        "updated_at": now_iso(),
                    })
                    analysis = Analysis(
                        summary=f"AI 摘要未完成：{ai_error}。原文已完整入库，可稍后重跑补摘要。",
                        status="analysis_failed",
                    )
            note = self.vault.write_note(source, cleaned, analysis, attachments)
            atomic_json(record / "job_status.json", {
                "status": analysis.status,
                "updated_at": now_iso(),
                "note": note.relative_to(self.vault.root).as_posix(),
                "raw_chars": len(raw.text),
                "cleaned_chars": len(cleaned.text),
                "last_timestamp": max((item.end for item in cleaned.segments if item.kept), default=0.0),
            })
            return note
        except Exception as error:
            atomic_json(record / "job_status.json", {
                "status": "failed",
                "updated_at": now_iso(),
                "error": str(error),
            })
            raise

    def remerge(self, record_id: str) -> Path:
        record = self.vault.root / "99_系统" / "records" / record_id
        source_data = record / "source.json"
        if not source_data.exists():
            raise FileNotFoundError(source_data)
        import json

        source = Source(**json.loads(source_data.read_text(encoding="utf-8")))
        cleaned = load_transcript(record / "cleaned_transcript.json")
        analysis = OllamaAnalyzer(self.options.ai_model).analyze(cleaned, record, force_merge=True)
        attachments = source.metadata.get("attachments")
        if attachments is None:
            assets_dir = self.vault.root / "90_附件" / record_id
            attachments = [
                path.name for path in sorted(assets_dir.iterdir())
                if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
            ] if assets_dir.is_dir() else []
        return self.vault.write_note(source, cleaned, analysis, attachments)

    def reflect(self, record_id: str, memory_root: Path, selectors: list[str]) -> Path:
        record = self.vault.root / "99_系统" / "records" / record_id
        source_data = record / "source.json"
        if not source_data.is_file():
            raise FileNotFoundError(source_data)
        source = Source(**read_json(source_data))
        note = self.vault.note_path(source)
        if not note.is_file():
            raise FileNotFoundError(note)
        bridge = PersonalMemoryBridge(memory_root)
        packet = bridge.pack(record, record_id, selectors)
        summary = self.vault.read_section(note, "摘要")
        key_points = self.vault.read_section(note, "要点")
        fingerprint = stable_id(
            f"reflect-v1|{self.options.ai_model}|{packet['receipt']['context_sha256']}|{summary}|{key_points}"
        )
        reflection_record = record / "reflection.json"
        cached = read_json(reflection_record) if reflection_record.exists() else {}
        if cached.get("_fingerprint") == fingerprint and (record / "reflection.md").exists():
            result = cached
        else:
            prompt = f"""你在做个人关联，不重写原文摘要，也不把个人记忆当作原文事实。
只能依据来源摘要、要点和所给个人记忆，找出真正相关的联系。没有可靠联系就返回空数组，不得硬凑。
输出一个 JSON 对象：
connections：与我的关联数组，最多5条。每项用对象表示，memory 填记忆主题，reason 填具体理由；只保留直接关联，不因都使用 AI 就算相关。
actions：可执行动作数组，最多5条；必须与本来源直接相关，没有明确动作就返回空数组。
questions：需要小毕判断的问题数组，最多3条；只问是否沉淀、采取什么动作等直接决策，禁止生成泛泛的讨论题。
不要输出 JSON 以外的内容。

来源标题：{source.title}
来源摘要：{summary}
来源要点：{key_points}

按需召回的个人记忆：
{packet['context']}"""
            result = OllamaAnalyzer(self.options.ai_model).generate(prompt)
        sections = (
            ("connections", "与我的关联"),
            ("actions", "可执行动作"),
            ("questions", "待我判断"),
        )
        lines = ["> 此区由 personal-memory 与本地模型生成，不属于原文摘要，也未写入个人记忆。"]
        for key, heading in sections:
            lines.extend(["", f"### {heading}"])
            items = connection_list(result.get(key)) if key == "connections" else string_list(result.get(key))
            lines.extend(f"- {item}" for item in items) if items else lines.append("- 暂无。")
        recalled = [item["selector"] for item in packet["receipt"]["items"]]
        lines.extend(["", "### 本次召回", *(f"- {item}" for item in recalled)])
        body = "\n".join(lines)
        atomic_text(record / "reflection.md", body + "\n")
        atomic_json(reflection_record, {
            "connections": connection_list(result.get("connections")),
            "actions": string_list(result.get("actions")),
            "questions": string_list(result.get("questions")),
            "recalled": recalled,
            "_fingerprint": fingerprint,
            "_model": self.options.ai_model,
        })
        bridge.acknowledge(record)
        self.vault.upsert_section(note, "与我相关", body)
        return note

    def distill(self, record_id: str) -> Path:
        record = self.vault.root / "99_系统" / "records" / record_id
        source_data = record / "source.json"
        if not source_data.is_file():
            raise FileNotFoundError(source_data)
        source = Source(**read_json(source_data))
        note = self.vault.note_path(source)
        if not note.is_file():
            raise FileNotFoundError(note)
        summary = self.vault.read_section(note, "摘要")
        key_points = self.vault.read_section(note, "要点")
        annotations = self.vault.read_section(note, "我的批注")
        content = f"""# 候选记忆：{source.title}

状态：needs_decision
建议类型：Learning（外部输入）
建议位置：personal-memory/knowledge/learnings/新文件，需小毕确认
生成时间：{now_iso()}

## 来源

- 原始链接：{source.url}
- SecondBrain 笔记：{note}
- 记录 ID：{record_id}

## 候选摘要

{summary}

## 候选要点

{key_points}

## 我的批注

{annotations or "暂无。"}

## 写入前核查

- [ ] 内容是否值得跨项目、跨会话保留
- [ ] 是否与现有记忆重复或冲突
- [ ] 是否只是外部观点，而非小毕本人的原则或偏好
- [ ] 是否需要从 Learning 升级为 Skill 或其他类型
- [ ] 是否保留可定位的原始来源

本命令只生成候选报告，没有写入 personal-memory。确认后才可执行 curator 写入、回读和索引更新。
"""
        output = record / "memory_candidate.md"
        atomic_text(output, content)
        return output
