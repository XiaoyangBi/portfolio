"""[INPUT] B站、YouTube 等视频链接和 yt-dlp 可读取的公开媒体。
[OUTPUT] 分集音轨、来源元数据，以及 YouTube 原声字幕。
[POS] 媒体采集层；B站始终走本地音轨转写。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator

import yt_dlp

from .models import Segment, Source, Transcript
from .util import stable_id
from .web import platform_for_url


@dataclass
class MediaItem:
    source: Source
    audio_path: Path | None = None
    transcript: Transcript | None = None


def ydl_options(cookies_from_browser: str = "") -> dict[str, Any]:
    options: dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": False,
        "socket_timeout": 45,
        "retries": 3,
    }
    if cookies_from_browser:
        options["cookiesfrombrowser"] = (cookies_from_browser,)
    elif os.environ.get("SECOND_BRAIN_YTDLP_COOKIE_FILE"):
        options["cookiefile"] = os.environ["SECOND_BRAIN_YTDLP_COOKIE_FILE"]
    return options


def entries_for_url(url: str, cookies_from_browser: str = "") -> tuple[list[dict[str, Any]], dict[str, Any]]:
    with yt_dlp.YoutubeDL(ydl_options(cookies_from_browser)) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise RuntimeError("No media metadata returned")
    entries = list(info.get("entries") or []) if info.get("_type") == "playlist" else [info]
    entries = [item for item in entries if item]
    return entries, info


def build_source(info: dict[str, Any], url: str, index: int, count: int) -> Source:
    webpage_url = info.get("webpage_url") or info.get("original_url") or url
    title = info.get("title") or f"media-{index}"
    if count > 1 and info.get("playlist_index"):
        title = f"{title} P{info['playlist_index']}"
    return Source(
        url=webpage_url,
        platform=platform_for_url(webpage_url),
        title=title,
        author=info.get("uploader") or info.get("channel") or "",
        description=info.get("description") or "",
        published_at=info.get("upload_date") or "",
        episode=index,
        episode_count=count,
        source_id=stable_id(f"{webpage_url}#episode={index}"),
        metadata={"media_id": info.get("id", ""), "duration": info.get("duration") or 0},
    )


def download_audio(info: dict[str, Any], directory: Path, cookies_from_browser: str = "") -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    output = directory / "media.m4a"
    if output.exists():
        return output
    options = ydl_options(cookies_from_browser)
    options.update({
        "format": "bestaudio/best",
        "outtmpl": str(directory / "media.%(ext)s"),
        "overwrites": True,
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "m4a",
            "preferredquality": "128",
        }],
    })
    target = info.get("webpage_url") or info.get("original_url") or info.get("url")
    if not target:
        raise RuntimeError("Media entry has no downloadable URL")
    with yt_dlp.YoutubeDL(options) as ydl:
        ydl.download([target])
    if not output.exists():
        candidates = sorted(directory.glob("media.*"))
        if not candidates:
            raise RuntimeError("Audio download completed without an output file")
        return candidates[0]
    return output


def subtitle_language(info: dict[str, Any]) -> str:
    subtitles = info.get("subtitles") or {}
    if not subtitles:
        return ""
    language = info.get("language") or info.get("audio_language") or ""
    if language in subtitles:
        return language
    if len(subtitles) == 1:
        return next(iter(subtitles))
    return ""


def download_original_subtitles(
    info: dict[str, Any],
    directory: Path,
    cookies_from_browser: str = "",
) -> Transcript | None:
    language = subtitle_language(info)
    if not language:
        return None
    directory.mkdir(parents=True, exist_ok=True)
    options = ydl_options(cookies_from_browser)
    options.update({
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsub": False,
        "subtitleslangs": [language],
        "subtitlesformat": "vtt",
        "outtmpl": str(directory / "subtitle.%(ext)s"),
    })
    target = info.get("webpage_url") or info.get("original_url")
    with yt_dlp.YoutubeDL(options) as ydl:
        ydl.download([target])
    files = sorted(directory.glob("subtitle*.vtt"))
    return parse_vtt(files[0]) if files else None


def timestamp_seconds(value: str) -> float:
    parts = value.replace(",", ".").split(":")
    numbers = [float(item) for item in parts]
    if len(numbers) == 2:
        return numbers[0] * 60 + numbers[1]
    return numbers[0] * 3600 + numbers[1] * 60 + numbers[2]


def parse_vtt(path: Path) -> Transcript:
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    segments: list[Segment] = []
    index = 0
    previous = ""
    while index < len(lines):
        match = re.match(r"(\d{2}:\d{2}(?::\d{2})?[.,]\d{3})\s+-->\s+(\d{2}:\d{2}(?::\d{2})?[.,]\d{3})", lines[index])
        if not match:
            index += 1
            continue
        index += 1
        text_lines: list[str] = []
        while index < len(lines) and lines[index].strip():
            text_lines.append(re.sub(r"<[^>]+>", "", lines[index]).strip())
            index += 1
        text = re.sub(r"\s+", " ", " ".join(text_lines)).strip()
        if text and text != previous:
            segments.append(Segment(timestamp_seconds(match.group(1)), timestamp_seconds(match.group(2)), text))
        previous = text
    return Transcript(
        text="\n".join(item.text for item in segments),
        segments=segments,
        source_type="subtitle",
    )


def iter_media(url: str, cache_dir: Path, cookies_from_browser: str = "") -> Iterator[MediaItem]:
    entries, _ = entries_for_url(url, cookies_from_browser)
    count = len(entries)
    for index, info in enumerate(entries, start=1):
        source = build_source(info, url, index, count)
        directory = cache_dir / source.source_id
        if source.platform == "youtube":
            transcript = download_original_subtitles(info, directory, cookies_from_browser)
            if transcript and transcript.text:
                yield MediaItem(source=source, transcript=transcript)
                continue
        audio = download_audio(info, directory, cookies_from_browser)
        yield MediaItem(source=source, audio_path=audio)
