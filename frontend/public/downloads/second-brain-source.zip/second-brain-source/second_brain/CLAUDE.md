# second_brain 模块地图

父级：`../CLAUDE.md`

- `models.py`：Source、Segment、Transcript、Analysis 数据模型。
- `util.py`：稳定 ID、文件名、YAML 字符串与原子写入。
- `media.py`：yt-dlp 分集采集、B站音轨与 YouTube 原声字幕。
- `web.py`：知乎正文、小红书图文 OCR 与视频、普通网页提取。
- `ocr.py`：调用 macOS Vision 原生 OCR。
- `transcribe.py`：240 分钟上限、10 分钟音频分片、逐片续跑。
- `cleaning.py`：音乐幻觉、乱码、低置信度与重复段清洗。
- `chunking.py`：8000 字按句或转写段切分，保留尾段。
- `analyzer.py`：Ollama 逐段提取与独立合并，全部结果留底。
- `vault.py`：Obsidian 笔记、附件、实体双链和概念确认。
- `pipeline.py`：URL 与本地文件的端到端编排及失败状态。
- `cli.py`：ingest、promote、remerge、ocr、doctor 命令。
