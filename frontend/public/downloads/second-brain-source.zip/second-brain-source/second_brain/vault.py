"""[INPUT] 来源元数据、清洗稿、AI 分析和 Obsidian Vault 路径。
[OUTPUT] 原始笔记、实体双链、待确认概念及可续跑处理记录。
[POS] 入库层；保留原文与批注，不替用户批准新概念。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import re
from pathlib import Path

from .models import Analysis, Source, Transcript
from .util import atomic_json, atomic_text, now_iso, read_json, safe_filename, stable_id, today, yaml_string

DIRECTORIES = [
    "00_收件箱", "01_原始笔记", "02_概念", "03_人物", "04_工具", "06_主题", "07_输出",
    "90_附件", "99_系统/records",
]

PROPOSAL_PATTERN = re.compile(
    r"^- \[(?P<mark>[ xX])\]\s*(?P<kind>[^｜\n]+?)｜(?P<name>[^：\n]+)：(?P<desc>.+?)\n"
    r"(?:\s+- 证据：(?P<evidence>.+?)\n)?"
    r"(?:\s+- 归属：(?P<target>.+?)\n)?",
    re.M,
)


class Vault:
    def __init__(self, root: Path) -> None:
        self.root = root.expanduser().resolve()
        for directory in DIRECTORIES:
            (self.root / directory).mkdir(parents=True, exist_ok=True)

    def record_dir(self, source: Source) -> Path:
        path = self.root / "99_系统" / "records" / source.source_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def note_path(self, source: Source) -> Path:
        if source.source_id:
            record = self.root / "99_系统" / "records" / source.source_id / "job_status.json"
            if record.exists():
                relative = read_json(record).get("note", "")
                existing = self.root / relative
                if relative and existing.is_file() and existing.resolve().is_relative_to(self.root):
                    return existing
            notes_root = self.root / "01_原始笔记"
            matches = sorted(notes_root.rglob(f"*_{source.source_id[:8]}.md"))
            if matches:
                return matches[0]
        published = source.published_at
        date = today()
        if re.match(r"^\d{8}$", published):
            date = f"{published[:4]}-{published[4:6]}-{published[6:8]}"
        elif re.match(r"^\d{4}-\d{2}-\d{2}", published):
            date = published[:10]
        filename = f"{date}_{safe_filename(source.title)}_{source.source_id[:8] or 'local'}.md"
        return self.root / "01_原始笔记" / source.platform / filename

    def approved_concepts(self) -> set[str]:
        path = self.root / "99_系统" / "approved_concepts.json"
        if not path.exists():
            return set()
        return set(read_json(path))

    def save_approved_concepts(self, names: set[str]) -> None:
        atomic_json(self.root / "99_系统" / "approved_concepts.json", sorted(names))

    def write_note(
        self,
        source: Source,
        transcript: Transcript,
        analysis: Analysis,
        attachments: list[str] | None = None,
    ) -> Path:
        path = self.note_path(source)
        annotations = self.read_section(path, "我的批注") if path.exists() else ""
        checked = self.checked_concepts(path) if path.exists() else set()
        proposals = self.read_section(path, "待确认提炼") if path.exists() else ""
        reflection_path = self.record_dir(source) / "reflection.md"
        reflection = reflection_path.read_text(encoding="utf-8").strip() if reflection_path.exists() else ""
        if attachments is None:
            attachments = source.metadata.get("attachments", [])
        approved = self.approved_concepts()
        pending = [item for item in analysis.concepts if item["name"] not in approved]
        linked = [item for item in analysis.concepts if item["name"] in approved]
        lines = [
            "---",
            "type: source",
            f"title: {yaml_string(source.title)}",
            f"source: {yaml_string(source.url)}",
            f"platform: {yaml_string(source.platform)}",
            f"author: {yaml_string(source.author)}",
            f"created: {yaml_string(now_iso())}",
            f"analysis_status: {yaml_string(analysis.status)}",
            f"transcript_chars: {len(transcript.text)}",
            f"truncated: {str(transcript.truncated).lower()}",
            "---",
            "",
            f"# {source.title}",
            "",
            f"来源：<{source.url}>",
            "",
        ]
        if transcript.truncated:
            hours = transcript.original_duration / 3600
            lines.extend([
                "> [!warning] 内容未全部处理",
                f"> 原始时长 {hours:.2f} 小时，仅处理前 {transcript.processed_duration / 60:.1f} 分钟。超出部分没有进入摘要。",
                "",
            ])
        if source.metadata.get("collection_warning"):
            lines.extend([
                "> [!warning] 采集可能不完整",
                f"> {source.metadata['collection_warning']}",
                "",
            ])
        lines.extend(["## 摘要", analysis.summary or "尚未生成摘要。", "", "## 要点"])
        lines.extend(f"- {item}" for item in analysis.key_points)
        if not analysis.key_points:
            lines.append("- 尚未生成要点。")
        lines.extend(["", "## 完整原文", transcript.text, ""])
        if reflection:
            lines.extend(["## 与我相关", reflection, ""])
        lines.extend(["## 我的批注", annotations, ""])
        if attachments:
            lines.extend(["## 图片附件"])
            lines.extend(f"![[90_附件/{source.source_id}/{name}]]" for name in attachments)
            lines.append("")
        lines.extend(["## 待确认概念"])
        if pending:
            for item in pending:
                suffix = f" — {item['definition']}" if item["definition"] else ""
                mark = "x" if item["name"] in checked else " "
                lines.append(f"- [{mark}] {item['name']}{suffix}")
                if item["evidence"]:
                    lines.append(f"  - 依据：{item['evidence']}（{item['origin']}）")
        else:
            lines.append("无。")
        if proposals:
            lines.extend(["", "## 待确认提炼", proposals])
        lines.extend(["", "## 相关笔记"])
        lines.extend(f"- 人物：{name}" for name in analysis.people)
        lines.extend(f"- 工具：{name}" for name in analysis.tools)
        lines.extend(f"- 概念：[[{safe_filename(item['name'])}]]" for item in linked)
        if not analysis.people and not analysis.tools and not linked:
            lines.append("暂无。")
        lines.extend([
            "",
            "## 处理记录",
            f"- [[99_系统/records/{source.source_id}/raw_transcript.json|原始转写]]",
            f"- [[99_系统/records/{source.source_id}/removed_segments.json|清洗删除记录]]",
        ])
        record = self.record_dir(source)
        for filename, label in (("analysis_inputs.json", "全部分段输入"), ("merged_analysis.json", "合并分析")):
            if (record / filename).is_file():
                lines.append(f"- [[99_系统/records/{source.source_id}/{filename}|{label}]]")
        lines.extend([
            "",
            "[[开始这里|返回首页]] · [[01_原始笔记/原始笔记索引|原始笔记索引]]",
            "",
        ])
        atomic_text(path, "\n".join(lines))
        return path

    def read_section(self, path: Path, heading: str) -> str:
        content = path.read_text(encoding="utf-8")
        matches = list(re.finditer(rf"^## {re.escape(heading)}\n(.*?)(?=^## |\Z)", content, re.M | re.S))
        return matches[-1].group(1).strip() if matches else ""

    def upsert_section(self, path: Path, heading: str, body: str) -> None:
        content = path.read_text(encoding="utf-8")
        matches = list(re.finditer(rf"^## {re.escape(heading)}\n.*?(?=^## |\Z)", content, re.M | re.S))
        replacement = f"## {heading}\n{body.strip()}\n\n"
        if matches:
            match = matches[-1]
            content = content[:match.start()] + replacement + content[match.end():]
        else:
            content = content.rstrip() + "\n\n" + replacement
        atomic_text(path, content)

    def checked_concepts(self, path: Path) -> set[str]:
        section = self.read_section(path, "待确认概念")
        return {
            match.group(1).strip()
            for match in re.finditer(r"^- \[x\]\s+([^—\n]+?)(?:\s+—\s*.*)?$", section, re.M | re.I)
            if not match.group(1).strip().startswith("[[")
        }

    def find_note(self, record_id: str) -> Path:
        matches = sorted((self.root / "01_原始笔记").rglob(f"*_{record_id[:8]}.md"))
        if not matches:
            raise FileNotFoundError(f"找不到记录 {record_id} 对应的原始笔记")
        return matches[0]

    def extract(self, record_id: str, topic: str = "") -> dict[str, list]:
        """把待确认提炼中已勾选的条目建为原子笔记。证据必须逐字出现在原文中。"""
        note = self.find_note(record_id)
        text = note.read_text(encoding="utf-8")
        section = self.read_section(note, "待确认提炼")
        if not section.strip():
            return {"created": [], "rejected": [], "reason": "待确认提炼区块为空"}
        body = text.split("## 完整原文", 1)[-1].split("## 我的批注", 1)[0]
        # 与 verify_proposals 保持一致：逐行 ASR 稿的行首时间戳是版式噪声
        body = re.sub(r"(?m)^\s*\d{1,2}:\d{2}(?:\.\d+)?\s*", "", body)
        normalized = re.sub(r"\s+", "", body)
        note_link = note.relative_to(self.root).with_suffix("").as_posix()
        source_url = self.frontmatter_value(text, "source")

        created: list[str] = []
        rejected: list[dict[str, str]] = []
        for match in PROPOSAL_PATTERN.finditer(section):
            if match.group("mark").lower() != "x":
                continue
            kind = match.group("kind").strip()
            name = match.group("name").strip()
            desc = match.group("desc").strip()
            evidence = (match.group("evidence") or "").strip()
            if not name:
                continue
            if not evidence or re.sub(r"\s+", "", evidence) not in normalized:
                rejected.append({"name": name, "reason": "证据未在原文中找到"})
                continue
            path = self.write_atom(kind, name, desc, evidence, note_link, topic or "未分类", source_url)
            created.append(path.relative_to(self.root).as_posix())

        if created:
            links = "".join(f"\n- [[{item[:-3]}]]" for item in created)
            current = self.read_section(note, "相关笔记")
            if current.strip() in ("", "暂无。"):
                self.upsert_section(note, "相关笔记", links.strip())
            else:
                merged = current.rstrip()
                for item in created:
                    link = f"[[{item[:-3]}]]"
                    if link not in merged:
                        merged += f"\n- {link}"
                self.upsert_section(note, "相关笔记", merged)
        return {"created": created, "rejected": rejected, "topic": topic or "未分类"}

    def verify_proposals(self) -> dict:
        """巡检全库提炼提案，证据必须能在原文中逐字找到。"""
        notes_count = 0
        proposals = 0
        checked = 0
        invalid: list[dict[str, str]] = []
        for note in sorted((self.root / "01_原始笔记").rglob("*.md")):
            section = self.read_section(note, "待确认提炼")
            if not section.strip():
                continue
            text = note.read_text(encoding="utf-8")
            body = text.split("## 完整原文", 1)[-1].split("## 我的批注", 1)[0]
            # 逐行 ASR 稿的时间戳属于版式噪声，剥掉后才能比对跨行证据
            body = re.sub(r"(?m)^\s*\d{1,2}:\d{2}(?:\.\d+)?\s*", "", body)
            normalized = re.sub(r"\s+", "", body)
            notes_count += 1
            for match in PROPOSAL_PATTERN.finditer(section):
                proposals += 1
                if match.group("mark").lower() == "x":
                    checked += 1
                evidence = (match.group("evidence") or "").strip()
                if not evidence or re.sub(r"\s+", "", evidence) not in normalized:
                    invalid.append({
                        "note": note.relative_to(self.root).as_posix(),
                        "name": match.group("name").strip(),
                        "reason": "证据未在原文中找到",
                    })
        return {"notes": notes_count, "proposals": proposals, "checked": checked, "invalid": invalid}

    def frontmatter_value(self, content: str, key: str) -> str:
        match = re.search(rf'^{re.escape(key)}:\s*"?(.*?)"?$', content, re.M)
        return match.group(1).strip() if match else ""

    def write_atom(
        self,
        kind: str,
        name: str,
        desc: str,
        evidence: str,
        note_link: str,
        topic: str = "未分类",
        source_url: str = "",
    ) -> Path:
        directory = self.root / "02_概念"
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{safe_filename(name)}.md"
        source_line = f"- [[{note_link}]]"
        if path.exists():
            content = path.read_text(encoding="utf-8")
            if source_line not in content:
                atomic_text(path, content.rstrip() + "\n" + source_line + "\n")
            return path
        frontmatter = [
            "---",
            "type: atom",
            f"kind: {kind}",
            f"title: {yaml_string(name)}",
            f"topic: {yaml_string(topic)}",
        ]
        if source_url:
            frontmatter.append(f"source: {yaml_string(source_url)}")
        frontmatter.extend([
            f"tags: [\"#主题/{topic}\", \"#类型/{kind}\", \"#状态/待消化\"]",
            f"created: {now_iso()}",
            "---",
        ])
        content = (
            "\n".join(frontmatter)
            + "\n\n"
            f"# {name}\n\n"
            "## 定义\n"
            f"{desc}\n\n"
            "## 原文证据\n"
            f"> {evidence}\n\n"
            "## 我的理解\n\n"
            "## 来源\n"
            f"{source_line}\n"
        )
        atomic_text(path, content)
        return path

    def promote(self) -> list[str]:
        approved = self.approved_concepts()
        promoted: list[str] = []
        for note in (self.root / "01_原始笔记").rglob("*.md"):
            original = note.read_text(encoding="utf-8")
            content = original
            section = self.read_section(note, "待确认概念")
            updated_section = section
            note_promoted: list[str] = []
            matches = list(re.finditer(r"^- \[x\]\s+([^—\n]+?)(?:\s+—\s*(.*))?$", section, re.M | re.I))
            for match in matches:
                name = match.group(1).strip()
                if not name or name.startswith("[["):
                    continue
                definition = (match.group(2) or "").strip()
                self.ensure_concept(name, definition, note)
                approved.add(name)
                promoted.append(name)
                note_promoted.append(name)
                suffix = f" — {definition}" if definition else ""
                updated_section = updated_section.replace(match.group(0), f"- [x] [[{safe_filename(name)}]]{suffix}", 1)
            if updated_section != section:
                position = content.rfind(section)
                content = content[:position] + updated_section + content[position + len(section):]
            for name in note_promoted:
                link = f"- 概念：[[{safe_filename(name)}]]"
                if link in self.read_section(note, "相关笔记") or link in content:
                    continue
                headings = list(re.finditer(r"^## 相关笔记\n", content, re.M))
                if headings:
                    position = headings[-1].end()
                    content = content[:position] + link + "\n" + content[position:]
            if content != original:
                atomic_text(note, content)
        self.save_approved_concepts(approved)
        return sorted(set(promoted))

    def ensure_concept(self, name: str, definition: str, source_note: Path) -> None:
        path = self.root / "02_概念" / f"{safe_filename(name)}.md"
        relative = source_note.relative_to(self.root).with_suffix("").as_posix()
        link = f"- [[{relative}]]"
        if path.exists():
            content = path.read_text(encoding="utf-8")
            if link not in content:
                atomic_text(path, content.rstrip() + "\n" + link + "\n")
            return
        atomic_text(
            path,
            f"---\ntype: concept\ntitle: {yaml_string(name)}\n---\n\n# {name}\n\n{definition or '待补充定义。'}\n\n## 来源\n{link}\n",
        )

    def audit(self) -> dict:
        """只读体检：断链、孤儿页、缺标签、待补摘要、待确认提案、未挂图的原子。"""
        files = [
            p for p in sorted(self.root.rglob("*.md"))
            if "回收" not in p.relative_to(self.root).parts
        ]
        stems: dict[str, Path] = {}
        for p in files:
            stems.setdefault(p.stem, p)
            stems.setdefault(p.relative_to(self.root).with_suffix("").as_posix(), p)

        def frontmatter_type(text: str) -> str:
            match = re.search(r"^type:\s*(\w+)", text, re.M)
            return match.group(1) if match else ""

        contents = {p: p.read_text(encoding="utf-8") for p in files}
        broken: list[dict[str, str]] = []
        inbound: dict[Path, int] = {p: 0 for p in files}
        for p, text in contents.items():
            for match in re.finditer(r"\[\[([^\]]+)\]\]", text):
                target = match.group(1).split("|")[0].split("#")[0].strip().rstrip("\\")
                if not target:
                    continue
                if target.startswith(("90_附件", "99_系统")):
                    continue
                resolved = stems.get(target) or stems.get(target + ".md")
                if resolved is None:
                    broken.append({"note": p.relative_to(self.root).as_posix(), "target": target})
                    continue
                if resolved != p and frontmatter_type(contents[resolved]) not in ("index", "moc"):
                    inbound[resolved] = inbound.get(resolved, 0) + 1

        orphans = [
            p.relative_to(self.root).as_posix()
            for p in files
            if frontmatter_type(contents[p]) in ("atom", "entity")
            and p.parent.name in ("02_概念", "03_人物", "04_工具")
            and inbound.get(p, 0) == 0
        ]

        missing_tags = []
        for p in files:
            if frontmatter_type(contents[p]) != "atom":
                continue
            tags = re.search(r"^tags:\s*\[(.+)\]$", contents[p], re.M)
            if not tags or len(re.findall(r"#[^\"',]+", tags.group(1))) < 3:
                missing_tags.append(p.relative_to(self.root).as_posix())

        pending_summary = [
            p.relative_to(self.root).as_posix()
            for p in files
            if p.parent.name not in ("99_系统",)
            and frontmatter_type(contents[p]) == "source"
            and "尚未生成摘要" in contents[p]
        ]

        unchecked = 0
        for p in files:
            section = self.read_section(p, "待确认提炼")
            if section:
                unchecked += len(re.findall(r"^- \[ \] ", section, re.M))

        moc_text = "\n".join(
            text for p, text in contents.items() if p.parent.name == "06_主题" and p.name.startswith("MOC-")
        )
        unmapped = [
            p.stem
            for p in files
            if frontmatter_type(contents[p]) == "atom" and f"[[02_概念/{p.stem}]]" not in moc_text
        ]

        outputs = [
            p for p in files
            if frontmatter_type(contents[p]) == "output" and p.relative_to(self.root).parts[0] != "05_模板"
        ]
        referenced: set[str] = set()
        for p in outputs:
            for match in re.finditer(r"\[\[([^\]]+)\]\]", contents[p]):
                target = match.group(1).split("|")[0].split("#")[0].strip()
                if target:
                    referenced.add(Path(target).stem)
        unreferenced = [
            p.stem
            for p in files
            if frontmatter_type(contents[p]) == "atom" and p.stem not in referenced
        ]

        return {
            "markdown_files": len(files),
            "broken_links": broken,
            "orphans": orphans,
            "missing_tags": missing_tags,
            "pending_summary": len(pending_summary),
            "pending_summary_notes": pending_summary,
            "unchecked_proposals": unchecked,
            "unmapped_atoms": unmapped,
            "outputs": len(outputs),
            "unreferenced_atoms": unreferenced,
        }

    def audit_report(self, result: dict) -> str:
        lines = [
            "---",
            "type: report",
            f"created: {now_iso()}",
            "---",
            "",
            "# 知识库体检报告",
            "",
            f"扫描 {result['markdown_files']} 篇 Markdown。",
            "",
            "## 需要处理",
            "",
            f"- 断链 {len(result['broken_links'])} 条",
            f"- 孤儿页 {len(result['orphans'])} 个",
            f"- 缺三维标签的原子页 {len(result['missing_tags'])} 个",
            f"- 未挂到主题地图的原子页 {len(result['unmapped_atoms'])} 个",
            f"- 待补摘要 {result['pending_summary']} 篇",
            f"- 待确认提案 {result['unchecked_proposals']} 条（等人勾选，不算问题）",
            f"- 输出 {result['outputs']} 篇，未被任何输出引用的原子 {len(result['unreferenced_atoms'])} 个",
            "",
        ]
        if result["broken_links"]:
            lines += ["## 断链", ""] + [f"- `{b['note']}` 指向 `{b['target']}`" for b in result["broken_links"]] + [""]
        if result["orphans"]:
            lines += ["## 孤儿页", ""] + [f"- `{o}`" for o in result["orphans"]] + [""]
        if result["missing_tags"]:
            lines += ["## 缺标签", ""] + [f"- `{m}`" for m in result["missing_tags"]] + [""]
        if result["unmapped_atoms"]:
            lines += ["## 未挂图的原子", ""] + [f"- [[02_概念/{n}]]" for n in result["unmapped_atoms"]] + [""]
        if result["unreferenced_atoms"]:
            lines += ["## 没被输出用过的原子", "",
                      "这些页面还没在任何文章、报告、方案里被引用。数量本身不是问题，长期为零说明积累没转化成产出。", ""]
            lines += [f"- [[02_概念/{n}]]" for n in result["unreferenced_atoms"]] + [""]
        lines += [
            "## 说明",
            "",
            "本报告只读生成，不修改任何笔记。机械问题（断链、缺标签、未挂图）可以按报告修；观点冲突与事实问题必须人工判断，工具不代劳。",
            "",
            "[[开始这里|返回首页]]",
            "",
        ]
        return "\n".join(lines)
