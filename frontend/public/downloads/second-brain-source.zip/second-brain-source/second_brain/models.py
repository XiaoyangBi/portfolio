"""[INPUT] 标准库 dataclasses。
[OUTPUT] 采集、转写和分析共用的数据模型。
[POS] 领域模型；只保存数据，不访问网络或磁盘。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class Segment:
    start: float
    end: float
    text: str
    avg_logprob: float = 0.0
    no_speech_prob: float = 0.0
    compression_ratio: float = 0.0
    kept: bool = True
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Segment":
        fields = cls.__dataclass_fields__
        return cls(**{key: value for key, value in data.items() if key in fields})


@dataclass
class Transcript:
    text: str
    segments: list[Segment] = field(default_factory=list)
    source_type: str = "text"
    language: str = ""
    truncated: bool = False
    original_duration: float = 0.0
    processed_duration: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["segments"] = [segment.to_dict() for segment in self.segments]
        return data


@dataclass
class Source:
    url: str
    platform: str
    title: str
    author: str = ""
    description: str = ""
    published_at: str = ""
    episode: int = 1
    episode_count: int = 1
    source_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Analysis:
    summary: str = ""
    key_points: list[str] = field(default_factory=list)
    concepts: list[dict[str, str]] = field(default_factory=list)
    people: list[str] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)
    status: str = "pending"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Analysis":
        fields = cls.__dataclass_fields__
        return cls(**{key: value for key, value in data.items() if key in fields})
