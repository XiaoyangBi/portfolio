"""[INPUT] SecondBrain 记录、personal-memory 选择器与本机 Python。
[OUTPUT] 可追溯的记忆召回包及真实读取回执。
[POS] 桥接层；只读 personal-memory，不执行记忆写入。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from .util import atomic_json


class PersonalMemoryBridge:
    def __init__(self, root: Path) -> None:
        self.root = root.expanduser().resolve()
        self.runtime = self.root / "tools" / "memory_runtime.py"
        if not self.runtime.is_file():
            raise FileNotFoundError(f"personal-memory runtime not found: {self.runtime}")

    def run(self, arguments: list[str]) -> dict[str, Any]:
        result = subprocess.run(
            [sys.executable, str(self.runtime), *arguments],
            check=True,
            capture_output=True,
            text=True,
        )
        return json.loads(result.stdout)

    def pack(self, record: Path, record_id: str, selectors: list[str]) -> dict[str, Any]:
        arguments = ["pack", "--session", f"second-brain-{record_id}"]
        for selector in selectors:
            arguments.extend(["--select", selector])
        packet = self.run(arguments)
        atomic_json(record / "memory_packet.json", packet)
        return packet

    def acknowledge(self, record: Path) -> dict[str, Any]:
        return self.run(["ack", "--packet", str(record / "memory_packet.json"), "--read-confirmed"])
