"""[INPUT] Python 包元数据。
[OUTPUT] 本地收藏夹知识库包版本。
[POS] 包入口；不包含运行时副作用。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""

__version__ = "0.1.0"
