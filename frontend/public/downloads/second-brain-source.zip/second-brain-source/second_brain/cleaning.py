"""[INPUT] 带置信度、时长和压缩比的 Whisper 原始分段。
[OUTPUT] 清洗稿与逐段删除原因；原始输入不被修改。
[POS] 质量闸门；只处理可解释异常，不做内容改写。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import re
from dataclasses import replace

from .models import Segment, Transcript


def normalize_sentence(text: str) -> str:
    return re.sub(r"\s+", "", text).strip()


def rejection_reason(segment: Segment) -> str:
    text = segment.text.strip()
    duration = max(0.0, segment.end - segment.start)
    length = len(normalize_sentence(text))
    if not text:
        return "空白分段"
    if "\ufffd" in text or re.search(r"(.)\1{11,}", text):
        return "乱码或单字异常重复"
    if segment.compression_ratio > 2.4:
        return "压缩比异常"
    if segment.no_speech_prob >= 0.80:
        return "高无语音概率"
    if segment.avg_logprob < -1.0 and segment.no_speech_prob >= 0.50:
        return "低置信度且疑似无语音"
    if duration >= 25 and length <= 24 and length / duration < 0.8:
        return "长时段低文字密度，疑似音乐幻觉"
    return ""


def clean_transcript(raw: Transcript) -> Transcript:
    cleaned: list[Segment] = []
    previous_text = ""
    repeat_count = 0
    for original in raw.segments:
        segment = replace(original)
        reason = rejection_reason(segment)
        current = normalize_sentence(segment.text)
        if current and current == previous_text:
            repeat_count += 1
        else:
            repeat_count = 1
        if not reason and repeat_count >= 3:
            reason = "同一句连续第三次出现"
        if reason:
            segment.kept = False
            segment.reason = reason
        else:
            segment.kept = True
            segment.reason = ""
        cleaned.append(segment)
        previous_text = current

    return Transcript(
        text="\n".join(item.text for item in cleaned if item.kept and item.text),
        segments=cleaned,
        source_type=raw.source_type,
        language=raw.language,
        truncated=raw.truncated,
        original_duration=raw.original_duration,
        processed_duration=raw.processed_duration,
    )


def removed_segments(transcript: Transcript) -> list[Segment]:
    return [item for item in transcript.segments if not item.kept]
