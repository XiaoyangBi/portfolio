"""[INPUT] 清洗后的全文或带时间戳转写段。
[OUTPUT] 约 8000 字且不主动截断的语义输入块。
[POS] 长文分析前置层；保证尾段进入模型。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from .models import Segment

DEFAULT_CHUNK_CHARS = 8000


@dataclass
class TextChunk:
    index: int
    text: str
    start: float = 0.0
    end: float = 0.0


def split_oversize(text: str, max_chars: int) -> list[str]:
    if len(text) <= max_chars:
        return [text]
    sentences = [item for item in re.split(r"(?<=[。！？!?；;])", text) if item]
    output: list[str] = []
    current = ""
    for sentence in sentences:
        if len(sentence) > max_chars:
            if current:
                output.append(current)
                current = ""
            output.extend(sentence[i:i + max_chars] for i in range(0, len(sentence), max_chars))
        elif len(current) + len(sentence) > max_chars:
            output.append(current)
            current = sentence
        else:
            current += sentence
    if current:
        output.append(current)
    return output


def chunk_text(text: str, max_chars: int = DEFAULT_CHUNK_CHARS) -> list[TextChunk]:
    pieces = split_oversize(text, max_chars)
    chunks: list[str] = []
    current = ""
    for piece in pieces:
        if current and len(current) + len(piece) > max_chars:
            chunks.append(current)
            current = piece
        else:
            current += piece
    if current or not chunks:
        chunks.append(current)
    return [TextChunk(index=index, text=value) for index, value in enumerate(chunks, start=1)]


def chunk_segments(segments: list[Segment], max_chars: int = DEFAULT_CHUNK_CHARS) -> list[TextChunk]:
    kept = [item for item in segments if item.kept and item.text]
    if not kept:
        return []
    chunks: list[TextChunk] = []
    current_text = ""
    start = kept[0].start
    end = kept[0].end

    def flush() -> None:
        nonlocal current_text, start, end
        if current_text:
            chunks.append(TextChunk(len(chunks) + 1, current_text, start, end))
            current_text = ""

    for segment in kept:
        addition = ("\n" if current_text else "") + segment.text
        if current_text and len(current_text) + len(addition) > max_chars:
            flush()
        if not current_text:
            start = segment.start
        if len(segment.text) > max_chars:
            for part in split_oversize(segment.text, max_chars):
                if current_text:
                    flush()
                current_text = part
                start = segment.start
                end = segment.end
                flush()
            continue
        current_text += ("\n" if current_text else "") + segment.text
        end = segment.end
    flush()
    return chunks
