"""[INPUT] 本地音视频、faster-whisper、FFmpeg 与来源标题简介。
[OUTPUT] 十分钟分片的原始转写及可续跑 JSON。
[POS] 语音转写层；媒体不出本机，不生成摘要。
[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
"""
from __future__ import annotations

import json
import math
import subprocess
import wave
from pathlib import Path
from typing import Any

from .models import Segment, Source, Transcript
from .util import atomic_json, read_json, stable_id

CHUNK_SECONDS = 600
DEFAULT_MAX_MINUTES = 240.0


def run_command(arguments: list[str]) -> None:
    subprocess.run(arguments, check=True, capture_output=True, text=True)


def probe_duration(path: Path) -> float:
    result = subprocess.run(
        [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return float(result.stdout.strip())


def prepare_audio(source: Path, work_dir: Path, max_minutes: float) -> tuple[Path, float, float, bool]:
    work_dir.mkdir(parents=True, exist_ok=True)
    original_duration = probe_duration(source)
    limit_seconds = max_minutes * 60
    truncated = original_duration > limit_seconds
    output = work_dir / "audio.wav"
    processed_duration = min(original_duration, limit_seconds)
    incomplete = output.exists() and abs(probe_duration(output) - processed_duration) > 1.0
    if not output.exists() or incomplete:
        arguments = ["ffmpeg", "-y", "-i", str(source)]
        if truncated:
            arguments.extend(["-t", str(limit_seconds)])
        arguments.extend(["-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(output)])
        run_command(arguments)
    if abs(probe_duration(output) - processed_duration) > 1.0:
        raise RuntimeError("Prepared audio duration does not cover the requested range")
    return output, original_duration, processed_duration, truncated


def split_audio(audio: Path, work_dir: Path) -> list[Path]:
    pattern = work_dir / "chunk_%03d.wav"
    manifest = work_dir / "split_manifest.json"
    expected_duration = probe_duration(audio)

    def valid_chunks() -> list[Path]:
        if not manifest.exists():
            return []
        payload = read_json(manifest)
        chunks = [work_dir / name for name in payload.get("chunks", [])]
        if not chunks or any(not path.exists() for path in chunks):
            return []
        if abs(float(payload.get("audio_duration", 0.0)) - expected_duration) > 0.001:
            return []
        covered = sum(probe_duration(path) for path in chunks)
        expected_count = max(1, math.ceil(expected_duration / CHUNK_SECONDS))
        if len(chunks) != expected_count or abs(covered - expected_duration) > 1.0:
            return []
        return chunks

    cached = valid_chunks()
    if cached:
        return cached
    run_command([
        "ffmpeg", "-y", "-i", str(audio), "-f", "segment",
        "-segment_time", str(CHUNK_SECONDS), "-c", "copy", str(pattern),
    ])
    chunks = sorted(work_dir.glob("chunk_*.wav"))
    covered = sum(probe_duration(path) for path in chunks)
    expected_count = max(1, math.ceil(expected_duration / CHUNK_SECONDS))
    if len(chunks) != expected_count or abs(covered - expected_duration) > 1.0:
        raise RuntimeError("Audio chunks do not cover the prepared audio")
    atomic_json(manifest, {
        "audio_duration": expected_duration,
        "covered_duration": covered,
        "chunks": [path.name for path in chunks],
    })
    return chunks


def read_pcm_wav(path: Path):
    """Read prepared audio directly, avoiding optional PyAV decoder signatures."""
    import numpy as np

    with wave.open(str(path), "rb") as handle:
        if handle.getnchannels() != 1 or handle.getsampwidth() != 2 or handle.getframerate() != 16000:
            raise ValueError("Whisper input must be 16 kHz mono 16-bit PCM WAV")
        frames = handle.readframes(handle.getnframes())
    return np.frombuffer(frames, dtype="<i2").astype(np.float32) / 32768.0


class WhisperTranscriber:
    def __init__(self, model_name: str = "small") -> None:
        from faster_whisper import WhisperModel

        self.model = WhisperModel(model_name, device="cpu", compute_type="int8")

    def transcribe_chunk(
        self,
        audio: Path,
        initial_prompt: str,
        language: str | None,
    ) -> tuple[list[Segment], str]:
        segments, info = self.model.transcribe(
            read_pcm_wav(audio),
            language=language,
            initial_prompt=initial_prompt[:1500],
            beam_size=5,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 500},
            condition_on_previous_text=False,
        )
        results = [
            Segment(
                start=float(item.start),
                end=float(item.end),
                text=item.text.strip(),
                avg_logprob=float(item.avg_logprob),
                no_speech_prob=float(item.no_speech_prob),
                compression_ratio=float(item.compression_ratio),
            )
            for item in segments
        ]
        return results, str(info.language or "")


def transcribe_audio(
    source_path: Path,
    source: Source,
    work_dir: Path,
    model_name: str = "small",
    max_minutes: float = DEFAULT_MAX_MINUTES,
    language: str | None = None,
) -> Transcript:
    stat = source_path.stat()
    cache_key = stable_id(
        f"{source_path.resolve()}|{stat.st_size}|{stat.st_mtime_ns}|{max_minutes}|{model_name}|{language or ''}"
        f"|{source.title}|{source.author}|{source.description}"
    )
    media_dir = work_dir / f"media_{cache_key}"
    audio, original, processed, truncated = prepare_audio(source_path, media_dir, max_minutes)
    chunks = split_audio(audio, media_dir)
    transcriber: WhisperTranscriber | None = None
    prompt = f"标题：{source.title}\n作者：{source.author}\n简介：{source.description}"
    all_segments: list[Segment] = []
    detected_language = language or ""
    offset = 0.0

    for index, chunk in enumerate(chunks, start=1):
        chunk_record = media_dir / f"transcript_{index:03d}.json"
        if chunk_record.exists():
            payload = read_json(chunk_record)
            items = [Segment.from_dict(item) for item in payload["segments"]]
            detected_language = detected_language or payload.get("language", "")
        else:
            if transcriber is None:
                transcriber = WhisperTranscriber(model_name)
            items, chunk_language = transcriber.transcribe_chunk(chunk, prompt, language)
            detected_language = detected_language or chunk_language
            atomic_json(chunk_record, {
                "chunk": index,
                "audio": chunk.name,
                "language": chunk_language,
                "segments": [item.to_dict() for item in items],
            })
        for item in items:
            item.start += offset
            item.end += offset
        all_segments.extend(items)
        offset += probe_duration(chunk)

    transcript = Transcript(
        text="\n".join(item.text for item in all_segments if item.text),
        segments=all_segments,
        source_type="audio",
        language=detected_language,
        truncated=truncated,
        original_duration=original,
        processed_duration=processed,
    )
    atomic_json(work_dir / "raw_transcript.json", transcript.to_dict())
    return transcript


def load_transcript(path: Path) -> Transcript:
    payload: dict[str, Any] = read_json(path)
    return Transcript(
        text=payload["text"],
        segments=[Segment.from_dict(item) for item in payload.get("segments", [])],
        source_type=payload.get("source_type", "text"),
        language=payload.get("language", ""),
        truncated=payload.get("truncated", False),
        original_duration=payload.get("original_duration", 0.0),
        processed_duration=payload.get("processed_duration", 0.0),
    )


def dump_transcript(path: Path, transcript: Transcript) -> None:
    path.write_text(json.dumps(transcript.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
