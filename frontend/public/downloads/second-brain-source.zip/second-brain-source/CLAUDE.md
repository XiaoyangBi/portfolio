# 本地收藏夹转 Obsidian

## 定位
把小红书、知乎、YouTube、B站和本地媒体转成可追溯的 Obsidian 笔记。

## 技术栈
Python 3.10+、faster-whisper、yt-dlp、macOS Vision、Ollama。

## 目录职责
- `second_brain/`：采集、转写、清洗、分析、入库及个人记忆桥接命令。
- `swift/`：中文图片 OCR 原生入口。
- `tests/`：无网络单元测试和本地端到端测试。
- `../SecondBrain/`：默认 Obsidian Vault。

## 关键约束
- 图片与音频只在本机处理。
- 单条收藏默认最多处理 240 分钟。
- 音频每 10 分钟切片，文本每 8000 字切段。
- 原始转写、清洗记录、分段分析全部留底。
- 新概念先进入待确认区，勾选后才建双链。
- 摘要不得覆盖原文，用户批注不得被重跑覆盖。
- 链接默认进入 SecondBrain；personal-memory 只在 reflect 时只读召回，distill 仅生成 needs_decision 候选，实际写入必须由小毕确认并走 curator。
- 个人关联独立放在与我相关区块，不得混入原文摘要或作为原文事实。

## 入口
- `./install.sh`：创建隔离环境并编译 OCR。
- `./kb ingest <来源>`：处理链接或本地文件。
- `./kb promote`：把已勾选概念升格为正式笔记。
- `./kb reflect <记录ID>`：只读召回 personal-memory，生成与我相关区块。
- `./kb distill <记录ID>`：生成候选记忆报告，不写入 personal-memory。
- `./kb doctor`：检查运行依赖。
