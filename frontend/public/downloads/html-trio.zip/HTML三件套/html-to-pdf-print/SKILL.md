---
name: html-to-pdf-print
description: Convert an HTML file (especially long single-page reports / 数据分析报告 / 分享 PPT 风格 HTML) into a print-ready A4 PDF using Chromium native page.pdf() (NOT screenshot). Preserves selectable text, vector SVG, real-DPI bitmaps; injects print-specific CSS to keep background colors (微信绿块 / 红色框) and prevent card-mid-page breaks; auto-handles tab / details / collapse expansion so hidden content does not disappear in the PDF. Use when the user wants to "把 HTML 转成 PDF / 导出 PDF / 打印成 PDF / PDF 便于传阅 / 转 PDF 分享". Falls back to chrome-headless-shell when system Chrome is blocked by macOS sandbox. Outputs single-file PDF with text searchable + keywords verifiable via pypdf.
description_zh: HTML 转 PDF 打印
description_en: HTML to print-ready PDF
disable: false
agent_created: true
---

# html-to-pdf-print

## When to use

Trigger when ANY of these signals appear:

- User says: "转成 PDF", "导出 PDF", "把 HTML 转 PDF", "PDF 便于传阅", "PDF 分享", "export to PDF", "save as PDF", "打印成 PDF"
- User wants to share a long-form HTML report (数据分析、PRD、分享笔记、汇报材料) in a portable, printable, version-stable format
- User explicitly asks for vector / text-selectable / non-screenshot PDF (the keyword is "原生 PDF" or mentions Puppeteer/Playwright/Chromium PDF)

DO NOT use this skill when:
- Source is `.docx`, `.pptx`, `.md` — convert to HTML first, or use the doc-specific tooling
- User wants a single-image preview (use screenshot tool instead)
- Output must be editable PDF with form fields (this skill produces final read-only PDF)

## 整体执行流程

```
Step 1  · 预检源 HTML（图片内联 + tab/details 检测）
Step 2  · 如检测到隐藏内容 → 写副本：注入 print CSS + 强制 <details open> + 给 tabpane 打 data-title
Step 3  · 选择渲染引擎：
            ├─ 首选 Playwright + chromium                     （能跑通就最方便）
            └─ 沙盒/macOS Mach 失败时 → chrome-headless-shell  （--single-process --no-zygote）
Step 4  · 生成 PDF
Step 5  · pypdf 验证文本可选 + 关键词命中 + 分页 tab 内容齐全
Step 6  · 清理临时副本
```

---

## Step 1 · 预检源 HTML

```bash
SRC="/abs/path/to/source.html"

ls -lh "$SRC"

# 1.1 图片内联（外链图在 file:// 下会 404）
grep -cE 'src="data:image/' "$SRC"          # 已内联数
grep -cE 'src="(image|http|/|\./)' "$SRC"   # 外链残留

# 1.2 tab / details / collapse / accordion 检测
grep -cE 'role="tab"|class="[^"]*tab-pane|class="[^"]*nav-tabs|<details|class="[^"]*collapse|class="[^"]*accordion|class="[^"]*tabpane' "$SRC"
grep -c "@media print" "$SRC"   # 0 → 必须走 Step 2

# 1.3 顺手看自定义 tab 类名（每份 HTML 可能不一样）
grep -oE 'class="[^"]*tab[a-zA-Z-]*"' "$SRC" | sort -u | head
grep -oE '<details[^>]*>' "$SRC" | sort -u | head
```

**判定**：
- 外链图片 > 0：**先**跑 `html-image-inliner` skill。
- tab/details/accordion > 0 且 `@media print` = 0 → 进入 Step 2（必做，否则隐藏内容会丢）
- 一切干净 → 跳过 Step 2，直奔 Step 3

---

## Step 2 · 处理 tab / details / 折叠内容（核心坑）

### 2.1 三档解决方案

| 方案 | 适用 | 改动 |
|---|---|---|
| **A. 改源 HTML** | 你能改 | 在 `<head>` 加 `@media print` 块 |
| **B. 写副本注入**（**实操首选**） | 不能改源（如别人发的 HTML） | 复制到 workspace 后注入 |
| **C. Playwright 主动点击** | React/Vue 懒加载（DOM 没挂载） | `page.click()` 触发挂载 + 再走 A/B |

90% 实际场景走 B（保留原文件不动 + 完全可控）。

### 2.2 ⚠️ HTML5 `<details>` 必须改 DOM，不能只改 CSS

`<details>` 的折叠是浏览器**原生语义行为**，不是 `display: none`。即使写：
```css
details > *:not(summary) { display: block !important; }
```
Chromium 在 print 时**仍然只渲染 `<summary>`**——必须给 DOM 加 `open` 属性。这是这个 skill 最容易踩的坑。

### 2.3 标准注入脚本（B 方案 + 处理 details）

写 `_inject_print_css.py` 到 workspace：

```python
import re

SRC  = "/abs/source.html"
WORK = "/abs/workspace/_tmp_html_with_print.html"

PRINT_CSS = """<style>
@media print {
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }

  /* === Tab 全部展开（覆盖主流框架 + 自定义） === */
  .tab-pane, [role="tabpanel"], .tab-content > div,
  .ant-tabs-tabpane, .el-tab-pane,
  .tabpane, .tabpane.active {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    height: auto !important;
    max-height: none !important;
    overflow: visible !important;
    break-inside: avoid;
  }
  /* 隐藏 tab 切换条 */
  .tabs, .nav-tabs, [role="tablist"], .ant-tabs-nav, .el-tabs__header { display: none !important; }
  /* 给 tab 加分隔标题（基于 data-title） */
  [data-title]::before {
    content: attr(data-title);
    display: block;
    font-weight: 700; font-size: 1.1em;
    margin: 24px 0 12px;
    padding: 8px 12px;
    border-left: 4px solid #07C160;
    background: #f4f3ef;
    border-radius: 4px;
  }

  /* === HTML5 <details>：DOM 已加 open，CSS 双保险 === */
  details, details[open] { display: block !important; }
  details > * { display: block !important; visibility: visible !important; }
  details > summary { display: none !important; }   /* 内容已展开，"查看详情" 按钮无意义 */

  /* === Bootstrap collapse / accordion === */
  .collapse, .accordion-collapse, .accordion-body {
    display: block !important;
    height: auto !important;
    visibility: visible !important;
  }

  /* 防分页截断 */
  details, .tabpane, .tab-pane, .card, section, .arc-card, .item, .qa, .insight {
    break-inside: avoid; page-break-inside: avoid;
  }
  h1, h2, h3 { break-after: avoid; }
  body { background: #fff !important; }
  img { max-width: 100% !important; height: auto !important; }
}
</style>
</head>"""

# [CUSTOMIZE] 给每个 .tabpane 加上分隔标题（按你 HTML 实际 id 改）
TITLE_MAP = {
    'sales': 'Tab 1 · 销量',
    'hot':   'Tab 2 · 热点',
}

html = open(SRC, encoding='utf-8').read()

# 1. 注入 print CSS
assert "</head>" in html, "missing </head>"
html = html.replace("</head>", PRINT_CSS, 1)

# 2. 关键：给所有 <details ...> 加 open 属性（除非已存在）
html, n_open = re.subn(
    r'<details\b(?![^>]*\sopen)([^>]*)>',
    r'<details open\1>',
    html
)
print(f"forced <details open>: {n_open}")

# 3. 给 .tabpane 打 data-title
def add_title(m):
    pid, cls = m.group(1), m.group(2)
    return f'<div id="{pid}" class="{cls}" data-title="{TITLE_MAP.get(pid, pid)}"'
html, n_tab = re.subn(
    r'<div id="(\w+)" class="(tabpane(?: active)?|tab-pane(?: active)?)"',
    add_title, html
)
print(f"tabpane data-title: {n_tab}")

open(WORK, "w", encoding='utf-8').write(html)
print(f"saved: {WORK}")
```

跑一遍：
```bash
python3 _inject_print_css.py
# 期望输出: forced <details open>: N (N>0)
#          tabpane data-title: M (M=tab数)
```

---

## Step 3 · 选择渲染引擎

### 3.1 首选：Playwright（已经能跑通时）

```bash
python3 _html_to_pdf.py   # 复制自 @scripts/html_to_pdf.py
```

`@scripts/html_to_pdf.py` 已包含 `FORCE_DETAILS_OPEN=True`，会在 `page.goto` 之后用 `setAttribute('open','')` 兜底。

### 3.2 Fallback：chrome-headless-shell（macOS 沙盒环境必走）

详见 P0b。一行命令：
```bash
CHS="$HOME/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-x64/chrome-headless-shell"
"$CHS" --headless --disable-gpu --no-sandbox --single-process --no-zygote \
  --print-to-pdf="/abs/output.pdf" --no-pdf-header-footer \
  --virtual-time-budget=15000 \
  "file:///abs/_tmp_html_with_print.html"
```

**注意**：headless-shell 不支持 Playwright API（无法 `add_init_script`/`page.evaluate`），所以 Step 2 的注入**必须**已经写进 HTML 副本里再调用。

---

## Step 4 · 生成 PDF + 验证

```bash
ls -lh /abs/output.pdf

python3 << 'PY'
from pypdf import PdfReader
r = PdfReader('/abs/output.pdf')
text = '\n'.join((p.extract_text() or '') for p in r.pages)
print(f'Pages: {len(r.pages)}')
print(f'Total text chars: {len(text)}')
# 必须验证：源 HTML 中"非 active tab"或"未展开 details"内的关键短语
for kw in ['<tab2 标题片段>', '<details 内的特征短语>']:
    print(f'  "{kw}": {text.count(kw)} hits')
PY
```

**通过判据**：
- `Pages` ≥ 预期（多 tab/多 details 展开后页数会显著上升）
- `text chars` ≥ 1000，且非 active tab / 折叠内容的关键词命中 > 0
- 拆字模糊匹配补一遍（pypdf 中文偶尔丢字，"香氛留香" 可能只匹配到"留香"）

## Step 5 · 视觉抽查
- 第一页/中间页/最后一页都打开看一眼
- 微信绿块、红框背景色保留（`print-color-adjust: exact` 生效）
- 没有 card 跨页截断（`break-inside: avoid` 生效）
- SVG 在 200% 缩放下仍清晰（vector 保留）

## Step 6 · 清理临时文件

```bash
rm /abs/workspace/_tmp_html_with_print.html /abs/workspace/_inject_print_css.py
```
最终产物只保留 PDF。

---

## Pitfalls

### P0 · Playwright bundled Chromium missing
**Symptom**: `BrowserType.launch: Executable doesn't exist at ...ms-playwright/chromium...`

**Fix**: `python3 -m playwright install chromium` 或安装系统 Chrome。

### P0b · Chrome / Chromium 在沙盒内启动失败 (mach_port_rendezvous_mac) ⭐
**Symptom**: `FATAL:base/apple/mach_port_rendezvous_mac.cc:159 Check failed: kr == KERN_SUCCESS. bootstrap_check_in ...: Permission denied (1100)`、`Crashpad ... settings.dat: Operation not permitted`，PDF 文件不生成。

**Cause**: macOS launchd 拒绝 Chrome 主进程注册 Mach port server——常见于沙盒/自动化执行环境，桌面 GUI Chrome 已经占用同名 server 或权限不足。`/Applications/Google Chrome.app` 和 `playwright install chromium` 都会触发；加 `--user-data-dir` / `--disable-crashpad` 也无效。

**Fix（亲测可用，2026-06-01 已验证）**:
1. 安装更小、更兼容沙盒的 chrome-headless-shell：
   ```bash
   python3 -m playwright install chromium-headless-shell
   ```
2. 直接用二进制（绕过 Playwright launcher），加 `--single-process --no-zygote` 不创建子进程就不需要 Mach port：
   ```bash
   CHS="$HOME/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-x64/chrome-headless-shell"
   "$CHS" --headless --disable-gpu --no-sandbox \
     --single-process --no-zygote \
     --print-to-pdf="/abs/output.pdf" --no-pdf-header-footer \
     --virtual-time-budget=15000 \
     "file:///abs/source.html"
   ```
3. 输出虽有 `CVDisplayLinkCreateWithCGDisplay failed` warning，但 `... bytes written to file ...` 即代表 PDF 已生成。

**注意**: `chrome-headless-shell` 不支持 Playwright API。print CSS 和 `<details open>` 必须**已经**注入到副本 HTML（见 Step 2）。

### P0c · `<details>` 内容在 PDF 中丢失 ⭐⭐
**Symptom**: HTML 里 `<details>` 中的内容（如"查看详情"展开的解释段）在 PDF 中只显示 summary，正文丢失。

**Cause**: `<details>` 的折叠是浏览器原生语义行为，**不是普通 CSS display:none**。即使写 `details > *:not(summary) { display: block !important; }`，Chromium 在打印时仍然只渲染 summary。

**Fix（必须 DOM + CSS 双管齐下）**:
1. **DOM 层**：副本 HTML 里给所有 `<details>` 加 `open` 属性
   ```python
   html, n = re.subn(r'<details\b(?![^>]*\sopen)([^>]*)>', r'<details open\1>', html)
   ```
2. **CSS 层**：把 summary 隐藏（内容已展开，"查看详情" 按钮无意义）
   ```css
   @media print { details > summary { display: none !important; } }
   ```
3. **Playwright 兜底**（用 Playwright 路径时）：在 `page.goto` 后调用
   ```python
   page.evaluate("document.querySelectorAll('details').forEach(d => d.setAttribute('open', ''))")
   ```

**已固化进 `scripts/html_to_pdf.py`**：`FORCE_DETAILS_OPEN = True` 默认开启。

### P0d · 非 active tab 内容在 PDF 中丢失
**Symptom**: 多 tab HTML 转 PDF 后，只有 active tab 的内容出现，其他 tab 全丢。

**Cause**: 非 active tab 用 CSS `display: none` 隐藏（Bootstrap、Antd、自定义 `.tabpane` 都是这套机制）。

**Fix**: Step 2.3 的 PRINT_CSS 已经覆盖主流框架 + 自定义类名（`.tabpane`、`.tab-pane`、`[role="tabpanel"]`、`.ant-tabs-tabpane`、`.el-tab-pane`）。如有更冷门的，加进选择器即可。

**对懒加载场景（DOM 中根本没挂载非 active tab）**：用 Playwright `page.click('[role="tab"]')` 遍历点击预热，参考脚本里的 `preheat_lazy_tabs()` 函数 + `PREHEAT_TABS = True`。

### P1 · Background colors lost (微信绿块变灰白)
**Cause**: 默认 print 模式不打印背景色（节省墨水）。

**Fix** (already in PRINT_CSS):
```css
* { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
```
Plus `print_background=True` in `page.pdf()` (Playwright)，或 chrome-headless-shell 默认就开。

### P2 · Cards split mid-content across pages
**Fix**:
```css
section.section, .card, .arc-card, .method, .insight, .q, .stage, .shot, .item, .qa {
  break-inside: avoid; page-break-inside: avoid;
}
h1, h2, h3 { break-after: avoid; }
```

### P3 · Sticky header / fixed sidebar visible on every page
**Fix**:
```css
.toc, nav.toc { display: none !important; }
header.header { position: static !important; }
footer.footer { position: static !important; }
```

### P4 · Fonts not loaded / 中文变方块
**Fix** (already in script):
```python
page.evaluate("document.fonts && document.fonts.ready")
page.wait_for_load_state("networkidle", timeout=30_000)
time.sleep(0.8)
```
若仍坏 → 改用本地字体栈 `-apple-system, "PingFang SC", sans-serif`。

### P5 · scale=1 但内容看起来还是缩小了
**Cause**: A4 内容区 ~186mm（约 700px @ 96dpi），HTML 容器 1100px → 自动缩放到 0.64×。这是浏览器 print layout 的自然映射，不是 bug。坚持要更大字：
```css
@media print { body { font-size: 110% !important; } }
```

### P6 · 图片在 PDF 中模糊
**Fix**:
- `device_scale_factor=2`（Playwright 路径已设）
- 源 base64 图片至少 1200px 长边

---

## Quick reference

- A4 size = 210 × 297 mm = ~794 × 1123 px @ 96 DPI
- Recommended margin: `14mm 12mm`
- viewport: 1240 × 1754 + device_scale_factor=2
- Output: full Unicode + selectable + searchable，SVG 矢量保留，bitmap 原 DPI

## 关键开关速查（`scripts/html_to_pdf.py`）

| 开关 | 默认 | 何时改 |
|---|---|---|
| `FORCE_DETAILS_OPEN` | `True` | 永远保持 True（除非确实想保留折叠状态） |
| `PREHEAT_TABS` | `False` | React/Vue 懒加载且 CSS 救不了时改 True |
| `device_scale_factor` | `2` | 想更高 DPI 调 3，但 PDF 体积涨 |

See `@scripts/html_to_pdf.py` for the full template script.
See `@references/print-css-cheatsheet.md` for the print CSS reference.
