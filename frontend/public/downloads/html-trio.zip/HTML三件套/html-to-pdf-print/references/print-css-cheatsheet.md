# Print CSS Cheatsheet for HTML-to-PDF

PDF 渲染时常用的 print CSS 速查。本表对应 Chromium / Playwright 渲染行为，其它打印引擎可能略有差异。

## 1. 页面尺寸 / 边距

```css
@page {
  size: A4;                 /* 也可写 letter / 210mm 297mm */
  margin: 14mm 12mm;        /* 上下 14mm, 左右 12mm */
}

/* 横向 */
@page {
  size: A4 landscape;
}

/* 第一页用不同边距 */
@page :first {
  margin-top: 30mm;          /* 给封面留白 */
}
```

调用 Playwright 时配 `prefer_css_page_size=True` 才会使用 @page 的设置。

## 2. 颜色与背景（最常被忽略的一条）

**默认情况下，浏览器打印模式不打印背景色**——这会让你的微信绿块、警告红框、KPI 高亮全部丢失。

```css
* {
  -webkit-print-color-adjust: exact !important;
  print-color-adjust: exact !important;
}
```

调用 `page.pdf()` 时还要传 `print_background=True`（脚本中已有）。

## 3. 分页控制

```css
/* 卡片不要被截断 */
.card, .section, .panel, .insight {
  break-inside: avoid;
  page-break-inside: avoid;       /* 兼容旧引擎 */
}

/* 标题不要孤悬页底 */
h1, h2, h3 {
  break-after: avoid;
  page-break-after: avoid;
}

/* 强制开始新页 */
.chapter-start {
  break-before: page;
  page-break-before: always;
}

/* 此处可断开 */
.section-end {
  break-after: auto;
}
```

## 4. 隐藏屏幕专用元素

```css
@media print {
  .toc, nav.sidebar { display: none !important; }
  header.fixed-top { position: static !important; }
  .floating-button, .scroll-indicator { display: none !important; }
}
```

任何 `position: fixed` / `position: sticky` 元素在 print 模式下会**重复出现在每一页**——必须改为 `static` 或 `display: none`。

## 5. 容器宽度适配

A4 内容宽度（去掉 12mm 左右边距）= 186mm ≈ 700px @ 96dpi。

源 HTML 的 `.container { max-width: 1100px }` 在 PDF 中会被自然映射到 700px 内容区——**这不是 CSS 缩放，是浏览器 print layout 的物理映射**，无需干预。

如果用户觉得字偏小：
```css
@media print {
  body { font-size: 110% !important; }
  .container { max-width: 100% !important; padding: 0 !important; }
}
```

## 6. 图片处理

```css
@media print {
  img {
    max-width: 100% !important;
    height: auto !important;
    page-break-inside: avoid;       /* 图片不被中间断开 */
  }
}
```

源图本身分辨率要求：长边 ≥ 1200px，否则 PDF 中放大会糊。
device_scale_factor 推荐 2（约 192 DPI）。

## 7. 字体加载等待（脚本端必做）

```python
# 浏览器内
page.evaluate("document.fonts && document.fonts.ready")

# 等待所有图片
page.evaluate('''
  () => Promise.all(
    Array.from(document.images).map(img =>
      img.complete && img.naturalHeight !== 0
        ? Promise.resolve()
        : new Promise(res => { img.onload = img.onerror = res; })
    )
  )
''')

# 等网络空闲（base64 不需要，但 webfont 可能下载）
page.wait_for_load_state("networkidle", timeout=30_000)
time.sleep(0.8)  # 缓冲，等 SVG 重新布局
```

## 8. 颜色档（深色 / 高对比度）

如果源 HTML 有暗色模式 `@media (prefers-color-scheme: dark)`，print 时需要强制亮色：

```css
@media print {
  body {
    background: #ffffff !important;
    color: #000000 !important;
  }
  /* 反色卡片（黑底白字）需要反过来 */
  .dark-card {
    background: #ffffff !important;
    color: #000000 !important;
    border: 1px solid #000 !important;
  }
}
```

## 9. SVG / 矢量内容

SVG 在 Chromium PDF 中**自动保持矢量**——无需特殊处理。验证方式：PDF 打开后放大到 400% 还清晰 = 矢量。

注意：如果 SVG 用了 `<use href="...">` 引用外部 symbol，记得 inline 进来；外部引用在 print 时会丢失。

## 10. 链接（可选）

PDF 可以保留点击链接：
```css
@media print {
  a[href]:after {
    content: " (" attr(href) ")";  /* 在文字后追加 URL */
    font-size: 0.85em;
    color: #666;
  }
}
```
但通常不需要——只要 `<a href>` 还在 HTML 里，PDF 就保留可点击。

## 11. 验证清单（每次都跑）

| 项 | 期望 |
|---|---|
| `mdls -name kMDItemNumberOfPages` | 合理页数（4MB HTML → 10-20 页 A4）|
| `pypdf.extract_text()` 总长度 | > 500 字符 |
| 关键词 `'<author_name>'`.count() | ≥ 1 |
| 文件大小 | 通常等于或略大于源 HTML |
| 200% 缩放下 SVG | 仍然清晰（矢量）|
| 200% 缩放下位图 | 不出现明显马赛克 |
| 背景色块（绿/红/灰）| 全部保留 |
| 卡片跨页 | 没有中间断开 |

## 调试技巧

### 想直接预览 print 模式（不走 PDF）
Chrome DevTools → Cmd+Shift+P → "Show Rendering" → CSS media type → print。

### 想保留 PDF 中的页面 outline（侧边目录）
Playwright `page.pdf()` 暂不直接支持自定义 outline。如果需要 PDF 大纲：
```python
page.pdf(path=..., tagged=True)   # 让屏幕阅读器可读
```
或后处理用 `pypdf` / `pikepdf` 加 outline。

### Headless vs Headed
`headless=True` 默认；如果发现某些 webfont 不加载，可以试 `headless=False` + 隐藏窗口（但这不能跑在 server 上）。
