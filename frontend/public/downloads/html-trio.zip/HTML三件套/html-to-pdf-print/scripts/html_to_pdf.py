#!/usr/bin/env python3
"""
TEMPLATE — html-to-pdf-print

把 HTML 文件转成 A4 PDF（Playwright 原生 page.pdf()，非截图）。
使用前需修改的位置已标注 [CUSTOMIZE]。

核心特性：
- Playwright 原生 page.pdf()（Chromium 内置 PDF 引擎，不是截图）
- 等待字体 + 所有图片真正加载完成
- A4 真实尺寸排版（210 × 297 mm）
- scale = 1（不缩放）
- 注入 print CSS：去掉 sticky/fixed，避免页眉页脚遮挡
- print-color-adjust: exact，让背景色和绿色块准确打印
- 文本保持选中，矢量内容（SVG）保持矢量
- channel="chrome" 用系统 Chrome（playwright bundled chromium 经常被清理）
- 内置展开样式覆盖主流 tab 框架（Bootstrap/Antd/Element/自定义.tabpane）
- FORCE_DETAILS_OPEN: 通过 setAttribute('open','') 强制展开所有 <details>
  （CSS display:block 救不了 <details> 的浏览器原生折叠语义）
- PREHEAT_TABS: 针对 React/Vue 懒加载场景，遍历点击所有 tab 触发挂载

依赖:
  pip install playwright pypdf
  playwright install chromium  (沙盒环境失败时改装 chromium-headless-shell, 详见 SKILL.md P0b)

使用:
  1. 修改 SRC / DST 路径
  2. python3 html_to_pdf.py
  3. 用 pypdf 抽文本验证文本可选 + 验证非 active tab/details 内的关键词命中

参考: @SKILL.md, @references/print-css-cheatsheet.md
"""
import sys
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

# [CUSTOMIZE] 输入输出路径
SRC = Path("/path/to/source.html")
DST = Path("/path/to/output.pdf")

# [CUSTOMIZE] 懒加载 tab 预点击开关
# True：在 PDF 渲染前遍历点击所有 tab，触发 React/Vue 懒加载组件挂载（方案 C）
# False：仅依赖 print CSS 强制展开（方案 B，对已渲染但 CSS 隐藏的内容有效）
# 默认 False；若 PDF 中发现 tab 内容缺失，先把这个改 True 再跑一次
PREHEAT_TABS = False

# [CUSTOMIZE] 强制展开所有 HTML5 <details>
# True（默认推荐）：渲染 PDF 前给所有 <details> 加 open 属性。CSS display:block !important
#   救不了 details 的原生折叠行为，必须改 DOM。
# False：保留原 [open] 状态，未展开的 details 在 PDF 中只显示 summary。
FORCE_DETAILS_OPEN = True

# 注入到页面的额外 print CSS
PRINT_CSS = """
@page {
  size: A4;
  margin: 14mm 12mm 14mm 12mm;
}
@media print {
  /* 颜色精确打印（背景色/微信绿块/红框都不能丢） */
  * {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }
  /* 隐藏屏幕专用元素 */
  .toc, nav.toc { display: none !important; }
  header.header { position: static !important; }
  footer.footer { position: static !important; }

  /* 不要让 section 中间硬截断到下页 */
  section.section, .card, .arc-card, .method, .insight, .q, .stage, .shot {
    break-inside: avoid;
    page-break-inside: avoid;
  }
  h1, h2, h3 { break-after: avoid; page-break-after: avoid; }

  /* 容器宽度按 A4 内容区（约 186mm ≈ 700px @ 96dpi）调整 */
  .container { max-width: 100% !important; padding: 0 !important; }
  body { background: #ffffff !important; }

  /* 图片不超出页面 */
  img { max-width: 100% !important; height: auto !important; }

  /* === Tab / 折叠 / 隐藏内容：强制全部展开 === */
  /* 通用 tab 面板（Bootstrap / Ant Design / Element UI / 自定义） */
  .tab-pane, [role="tabpanel"], .tab-content > div,
  .ant-tabs-tabpane, .el-tab-pane {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    height: auto !important;
    max-height: none !important;
    overflow: visible !important;
    break-inside: avoid;
  }
  /* HTML5 <details>：DOM 已通过 FORCE_DETAILS_OPEN 加 open，CSS 双保险 + 隐藏 summary */
  details, details[open] { display: block !important; }
  details > * { display: block !important; visibility: visible !important; }
  details > summary { display: none !important; }   /* 内容已展开，"查看详情" 按钮无意义 */
  details > summary::-webkit-details-marker,
  details > summary::marker { display: none; }
  /* Bootstrap collapse / accordion */
  .collapse, .accordion-collapse, .accordion-body {
    display: block !important;
    height: auto !important;
    visibility: visible !important;
  }
  /* tab 标题分隔（如果元素带 data-title） */
  [data-title]::before {
    content: attr(data-title);
    display: block;
    font-weight: 600;
    font-size: 1.05em;
    margin: 16px 0 8px;
    border-left: 3px solid #07C160;
    padding-left: 8px;
  }
  /* 隐藏交互元素（已展开就不需要切换按钮） */
  .nav-tabs, [role="tablist"], .ant-tabs-nav, .el-tabs__header { display: none !important; }
}
"""


# Tab 触发器选择器（用于懒加载场景的预点击）
TAB_TRIGGER_SELECTORS = [
    '[role="tab"]',
    '.nav-tabs a',
    '.nav-tabs button',
    '.ant-tabs-tab',
    '.el-tabs__item',
    '.tab-button',
]


def preheat_lazy_tabs(page):
    """
    针对 React/Vue 懒加载 tab 的预点击：
    遍历点击所有 tab 触发器，让框架把内容挂载进 DOM。
    对 unmount-on-hide 的框架无效，需要回到方案 A（改源 HTML）。
    若 [CUSTOMIZE] PREHEAT_TABS=True 则在 page.goto 之后调用。
    """
    for sel in TAB_TRIGGER_SELECTORS:
        try:
            elements = page.query_selector_all(sel)
        except Exception:
            continue
        for el in elements:
            try:
                el.click(timeout=1500)
                page.wait_for_timeout(200)
            except Exception:
                pass


def html_to_pdf(src: Path, dst: Path):
    if not src.exists():
        print(f"[ERR] source not found: {src}")
        sys.exit(1)

    # 使用 file:// 加载（确保所有 base64 资源就位）
    src_uri = src.resolve().as_uri()
    print(f"[1/5] loading {src.name} ({src.stat().st_size / 1024 / 1024:.2f} MB)")

    with sync_playwright() as p:
        # 用系统 Chrome（Playwright 自带的 chromium 包未安装）
        browser = p.chromium.launch(
            headless=True,
            channel="chrome",
            args=["--font-render-hinting=none", "--disable-dev-shm-usage"],
        )
        context = browser.new_context(
            viewport={"width": 1240, "height": 1754},  # 接近 A4 96dpi 比例
            device_scale_factor=2,                      # 高 DPI 截 SVG/位图
        )
        page = context.new_page()

        # 注入 print CSS（在 navigation 之前）
        page.add_init_script("""
            (function() {
              const css = `""" + PRINT_CSS.replace("`", "\\`") + """`;
              window.addEventListener('DOMContentLoaded', () => {
                const s = document.createElement('style');
                s.setAttribute('data-print-injected', 'true');
                s.textContent = css;
                document.head.appendChild(s);
              });
            })();
        """)

        page.goto(src_uri, wait_until="load", timeout=60_000)
        print("[2/5] DOM loaded — waiting fonts & images")

        # 等字体
        page.evaluate("document.fonts && document.fonts.ready")

        # 等所有图片完成（base64 是同步，但保险起见）
        page.evaluate("""
            () => Promise.all(
              Array.from(document.images).map(img =>
                img.complete && img.naturalHeight !== 0
                  ? Promise.resolve()
                  : new Promise(res => { img.onload = img.onerror = res; })
              )
            )
        """)

        # 懒加载 tab 预点击（方案 C）
        if PREHEAT_TABS:
            print("[2.5/5] preheating lazy tabs (clicking all tab triggers)")
            preheat_lazy_tabs(page)
            page.wait_for_timeout(500)

        # 强制展开所有 <details>（CSS display:block 救不了原生语义行为，必须 setAttribute）
        if FORCE_DETAILS_OPEN:
            n = page.evaluate("""
                () => {
                  const all = document.querySelectorAll('details');
                  all.forEach(d => d.setAttribute('open', ''));
                  return all.length;
                }
            """)
            print(f"[2.6/5] forced <details> open: {n} elements")

        # 给一点 idle 时间让 SVG 完成布局
        page.wait_for_load_state("networkidle", timeout=30_000)
        time.sleep(0.8)

        print("[3/5] media=print + fonts ready")
        page.emulate_media(media="print")

        print("[4/5] rendering PDF (A4, scale=1)")
        # Chromium 原生 PDF
        page.pdf(
            path=str(dst),
            format="A4",
            print_background=True,
            scale=1.0,                # 不缩放
            prefer_css_page_size=True, # 用 @page CSS 的尺寸
            margin={
                "top": "14mm",
                "bottom": "14mm",
                "left": "12mm",
                "right": "12mm",
            },
            # 不写 displayHeaderFooter，避免出现浏览器默认页眉页脚
        )
        browser.close()

    size_mb = dst.stat().st_size / 1024 / 1024
    print(f"[5/5] DONE: {dst.name} · {size_mb:.2f} MB")


if __name__ == "__main__":
    html_to_pdf(SRC, DST)
