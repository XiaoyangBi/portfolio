---
name: html-image-inliner
description: Compress and inline all external image references in an HTML file as Base64 data URIs, producing a single self-contained HTML that renders correctly when forwarded without the image folder. Use when the user asks to "inline images", "embed images", "嵌入图片", "图片转 base64", "html 转发时图片挂掉", "让 html 不依赖 assets 目录", or anything about making an HTML portable / shareable with images intact.
description_zh: HTML 图片转 Base64 内嵌
description_en: Inline HTML images as Base64
disable: false
agent_created: true
---

# html-image-inliner

## When to use

触发词 / 场景：
- "把图片内嵌到 html"、"嵌入图片"、"图片转 base64"、"html 转发图片挂掉"、"让 html 不依赖 assets"
- "inline images"、"embed images"、"self-contained html"
- 用户要把 HTML 发给同事/客户，希望对方打开就能看到所有图片，不用附带文件夹
- HTML 目前用 `<img src="assets/xxx.png">` 相对路径，需要改成 `<img src="data:image/png;base64,...">`

不触发：
- 用户只问"怎么把图变小"——那是纯图片压缩，不涉及 HTML
- 用户要"上传图片到图床"——那是外链方案，不是内嵌

## Steps

### 1. 摸底（必做）

```bash
cd <workspace>
# 扫描 HTML 里所有图片引用
grep -oE 'src="[^"]*\.(png|jpg|jpeg|gif|webp)"' <html_file> | sort -u
# 汇总图片目录体积
ls -la assets/ && du -sh assets/
```

根据总体积决定：
- ≤ 2 MB → 可直接 Base64，不压缩
- 2~10 MB → 建议先压缩（下一步）
- > 10 MB → 必压缩，否则 HTML 开起来卡

### 2. 备份

```bash
cp <html_file> <html_file>.bak.html
```

### 3. 压缩图片（体积 > 2MB 时执行）

用 macOS 自带 `sips`（无外部依赖）：

```bash
mkdir -p assets/_compressed

# 大 JPG：质量 70 + 宽度上限 800px（手机截图场景足够）
for f in *.jpg *.jpeg; do
  sips -s format jpeg -s formatOptions 70 -Z 800 "$f" --out "_compressed/$f"
done

# 大 PNG（手机截图类，无透明）转 JPG
for f in search_*.png product_*.png mobile_*.png; do
  [ -f "$f" ] || continue
  sips -s format jpeg -s formatOptions 70 -Z 800 "$f" --out "_compressed/${f%.png}.jpg"
done

# 小 PNG（图表/数据口径图，需保留清晰度和透明度）：只压宽度
for f in source_*.png chart_*.png *.png; do
  [ -f "$f" ] || continue
  sips -Z 1200 "$f" --out "_compressed/$f"
done
```

**注意**：压缩后 `xxx.png` → `xxx.jpg` 的文件要在替换映射里显式处理（脚本已考虑）。

### 4. Base64 嵌入 + 替换

使用 @scripts/inline_images.py（详见该文件）。核心逻辑：
- 建立 `"assets/原文件名" → 压缩目录实际文件` 的映射
- 读图 → `base64.b64encode` → 拼成 `data:image/xxx;base64,...`
- 用 `html.replace()` 批量替换（不用正则，避免复杂性）

```bash
python3 /Users/bixiaoyang/.workbuddy/skills/html-image-inliner/scripts/inline_images.py \
  --html "<html_file>" \
  --assets-dir "assets/_compressed"
```

脚本会自动：
- 遍历压缩目录下所有图片文件
- 对每张图同时尝试 `.png` 和 `.jpg` 两种原引用（应对 png→jpg 压缩场景）
- 输出替换日志 + 最终文件大小

### 5. 验证

```bash
# 0 残留 = 成功
grep -c 'src="assets/' <html_file>
# 嵌入计数
grep -c 'src="data:image/' <html_file>
# 最终大小
ls -lh <html_file>
```

### 6. 清理

```bash
rm -rf assets/_compressed
```

**不要删 `assets/` 原图**——后续再改图需要。

## Pitfalls

1. **编辑性折损**：内嵌后 HTML 会变成 1~N MB 大文件，编辑器打开会卡；建议**保留 `.bak.html` 作为日常编辑版**，发布前再跑这个 skill 生成内嵌版
2. **png→jpg 映射**：手机截图 PNG 转 JPG 后文件名扩展名变了，但 HTML 里仍引用 `.png` ——脚本要做映射，不能只扫 `_compressed/` 目录
3. **透明度**：有透明背景的 PNG（logo、图标、数据图表）**不要转 JPG**，否则会变黑底；只对手机截图类 PNG 做格式转换
4. **sips 的 `-Z`**：是"max dimension"，按长边按比例缩，不会拉伸；保留原宽高比
5. **中文路径**：sips 对中文路径支持完全 OK，但 zsh 通配符可能出幺蛾子——复杂场景用 Python 的 `pathlib.Path`
6. **企微/邮件大小**：企微单文件 200MB、邮件 20MB 上限，控制最终 HTML < 5MB 安全
7. **浏览器 base64 长度限制**：Chrome/Safari 无硬限制，但单张图超 10MB 解码会卡；所以一定要先压缩
8. **不要用外链图床**（图床挂 / 防盗链 / 要登录 / 改 referer 都会整体挂），本 skill 只做内嵌

## Verification

成功标志（全部满足）：
- ✅ `grep -c 'src="assets/' <html>` 输出 `0`
- ✅ `grep -c 'src="data:image/' <html>` 输出等于原引用数
- ✅ 用浏览器打开（或移动文件到新位置再打开）图片正常显示
- ✅ `.bak.html` 保留为编辑版
- ✅ 最终 HTML 大小 < 5MB（否则需要更激进的压缩参数）

快速人工验证：
```bash
cp <html_file> /tmp/test_portable.html
# 从 /tmp 打开（没 assets 目录），图片应全部显示
open /tmp/test_portable.html
```
