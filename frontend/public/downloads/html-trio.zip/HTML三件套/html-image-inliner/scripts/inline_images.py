#!/usr/bin/env python3
"""
HTML 图片 Base64 内嵌工具（html-image-inliner skill 配套脚本）

用法：
    python3 inline_images.py --html 搜索口径升级汇报.html --assets-dir assets/_compressed
    python3 inline_images.py --html report.html --assets-dir assets  # 不经压缩直接嵌入

会自动处理 png→jpg 的扩展名映射：若原 HTML 引用 xxx.png 而压缩目录只有 xxx.jpg，脚本会自动匹配。
"""
import argparse
import base64
import os
import re
import sys
from pathlib import Path


IMG_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
MIME = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def build_mapping(assets_dir: Path):
    """扫描 assets_dir，返回 {basename_without_ext: (filepath, mime)} 映射，便于 png→jpg 跨扩展名匹配"""
    by_stem = {}
    for fp in assets_dir.rglob("*"):
        if fp.suffix.lower() in IMG_EXTS and fp.is_file():
            by_stem[fp.stem] = (fp, MIME[fp.suffix.lower()])
    return by_stem


def encode_data_uri(fp: Path, mime: str) -> str:
    b = fp.read_bytes()
    return f"data:{mime};base64,{base64.b64encode(b).decode('ascii')}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True, help="要处理的 HTML 文件路径")
    ap.add_argument("--assets-dir", required=True, help="图片目录（压缩后或原始目录均可）")
    ap.add_argument("--dry-run", action="store_true", help="只报告不写回")
    args = ap.parse_args()

    html_path = Path(args.html).resolve()
    assets_dir = Path(args.assets_dir).resolve()
    if not html_path.exists():
        sys.exit(f"[ERR] HTML 文件不存在: {html_path}")
    if not assets_dir.exists():
        sys.exit(f"[ERR] 资源目录不存在: {assets_dir}")

    html = html_path.read_text(encoding="utf-8")
    orig_size = len(html.encode("utf-8"))

    stem_map = build_mapping(assets_dir)
    print(f"[scan] {assets_dir} 下发现 {len(stem_map)} 张图片")

    # 匹配所有 <img src="xxx"> 或 src='xxx'，把非 data:/http(s):/ 开头的提出来
    pattern = re.compile(r'''src=(["'])(?!data:|https?://)([^"']+\.(?:png|jpg|jpeg|gif|webp))\1''', re.IGNORECASE)

    replacements = {}  # {原 src 值: data URI}
    hit_files = set()  # 命中了压缩目录中的哪些文件
    missing = []       # HTML 里引用了但目录里没找到的

    for m in pattern.finditer(html):
        raw_src = m.group(2)
        # 取 basename 的 stem（去掉扩展名）
        stem = Path(raw_src).stem
        if stem in stem_map:
            fp, mime = stem_map[stem]
            if raw_src not in replacements:
                replacements[raw_src] = encode_data_uri(fp, mime)
                hit_files.add(fp.name)
        else:
            missing.append(raw_src)

    # 批量替换
    total_sub = 0
    for raw_src, uri in replacements.items():
        cnt = html.count(raw_src)
        html = html.replace(raw_src, uri)
        total_sub += cnt
        print(f"[sub] {raw_src}  × {cnt}")

    if missing:
        print("\n[WARN] 以下 HTML 里的引用在资源目录中找不到（保持原样）:")
        for m in sorted(set(missing)):
            print(f"  - {m}")

    unused = set(stem_map) - {Path(s).stem for s in replacements}
    if unused:
        print(f"\n[INFO] 资源目录有 {len(unused)} 张图 HTML 未引用，已跳过:")
        for stem in sorted(unused):
            print(f"  - {stem_map[stem][0].name}")

    if args.dry_run:
        print("\n[DRY-RUN] 未写回文件")
        return

    html_path.write_text(html, encoding="utf-8")
    new_size = os.path.getsize(html_path)
    print(f"\n== DONE ==\n替换次数: {total_sub}\n原大小: {orig_size/1024/1024:.2f} MB  →  新大小: {new_size/1024/1024:.2f} MB")

    # 验证
    remaining = len(re.findall(r'''src=["'](?!data:|https?://)[^"']+\.(?:png|jpg|jpeg|gif|webp)["']''', html, re.I))
    print(f"[verify] 残留未内嵌的相对路径引用: {remaining}")
    if remaining > 0:
        print("[verify] 有未嵌入的图，检查上面 [WARN] 列表")


if __name__ == "__main__":
    main()
