# HTML 三件套 · 安装说明

## 这是什么

三个独立的 WorkBuddy / Codebuddy skill，串成一条流水线，覆盖 HTML 报告的「嵌图 → 转 PPT / 转 PDF」全流程。

打开 `README.html` 查看详细介绍和用户故事。

## 三个 skill

| 目录 | 作用 | 触发词示例 |
|---|---|---|
| `html-image-inliner` | 把 HTML 里的所有图片转 base64 内嵌 | "嵌入图片", "转 base64", "让 HTML 转发不挂图" |
| `html-to-ppt-deck` | 把长滚动 HTML 改成翻页 PPT 形式 | "改成 PPT", "一页一页", "翻页形式" |
| `html-to-pdf-print` | 把 HTML 转成 A4 PDF（文本可选可搜） | "导出 PDF", "PDF 便于传阅", "打印成 PDF" |

## 安装

把三个 skill 目录复制到 WorkBuddy / Codebuddy 的 skill 目录：

```bash
# macOS / Linux
cp -r html-image-inliner html-to-ppt-deck html-to-pdf-print ~/.workbuddy/skills/

# 注册到 agent-created 列表（如果你的客户端用这个）
# 编辑 ~/.workbuddy/skills/agent-created-skills.json
# 在 skills 数组里追加三条:
{
  "name": "html-image-inliner",
  "createdAt": "2026-05-09T09:27:17Z",
  "skillDir": "html-image-inliner"
},
{
  "name": "html-to-ppt-deck",
  "createdAt": "2026-05-29T07:36:27Z",
  "skillDir": "html-to-ppt-deck"
},
{
  "name": "html-to-pdf-print",
  "createdAt": "2026-05-30T13:31:51Z",
  "skillDir": "html-to-pdf-print"
}
```

## 依赖

| Skill | 依赖 |
|---|---|
| `html-image-inliner` | macOS 自带的 `sips`（无需额外安装） + Python 3 |
| `html-to-ppt-deck` | 仅 Python 3（不需要 Node / 浏览器） |
| `html-to-pdf-print` | `pip install playwright pypdf` + 系统 Chrome（或 `playwright install chromium`） |

## 使用

skill 装好后，在 WorkBuddy 对话里直接说人话即可触发，例如：

- "把 X.html 的图片嵌进去"
- "把 X.html 改成 PPT 形式"
- "把 X.html 转成 PDF"
- "把 X.html 同时出 PPT 版和 PDF 版"（自动按 inliner → deck + pdf 两条路并行）

每个 skill 里的 `SKILL.md` 包含详细的使用步骤、Pitfalls 和 Verification 清单。
`scripts/` 里是可直接运行的模板脚本。
`references/` 里是查询用的速查表。

## 作者

毕骁扬 · 笔笔省购物搜索 · 2026.06
