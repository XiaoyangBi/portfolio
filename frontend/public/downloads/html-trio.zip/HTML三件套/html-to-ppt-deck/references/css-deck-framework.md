# Deck CSS Framework Contract

PPT 翻页框架的 CSS 设计契约。下次需要修改翻页样式时查这里。

## 核心结构

```
<body>
  ├── <button id="fs-btn" class="fullscreen-btn">⛶ 全屏</button>
  ├── <div class="deck-hint">键盘提示</div>
  ├── <div class="click-zone left" id="zone-left"></div>     ← 左半屏点击热区
  ├── <div class="click-zone right" id="zone-right"></div>   ← 右半屏点击热区
  ├── <div class="deck">
  │     <section class="slide" data-density="...">           ← 12 张 slide
  │       <div class="slide-inner">{content}</div>
  │     </section>
  │     ...
  ├── <div class="deck-bar">
  │     <div class="dot-pages">                              ← 底部圆点页码
  │       <button class="pg" data-target="0"></button>
  │     </div>
  │     <div class="page-counter" id="page-counter">01 / 12</div>
  └── <script>...</script>                                    ← 翻页 JS
```

## Density 三档体系

### `loose`（疏松，给空页用）
- 用 flex 整页**垂直居中**
- 标题字号: 28-40px clamp
- 正文字号: 16-20px clamp
- 适用: 封面、章节扉页、引言、困惑、致谢

### `normal`（默认，绝大部分内容）
- 不覆盖任何样式，沿用源 HTML 的字号
- 适用: 章节正文、文字+1-2 张图

### `tight`（紧凑，给图密集页用）
- 强制 `.shot .frame { aspect-ratio: auto; min-height: auto; padding: 0 }`
- 强制 `img { max-height: 240px; object-fit: contain }`
- caption 字号缩到 12px、tag 10px、sub 11px
- gallery-label margin 收紧
- 适用: 5+ 张并排图、含 SVG 思维导图的实证页

## 翻页交互契约

| 事件 | 触发 | 行为 |
|---|---|---|
| `keydown ArrowLeft` / `PageUp` | 任意页 | 上一页 |
| `keydown ArrowRight` / `PageDown` / `Space` | 任意页 | 下一页 |
| `keydown Home` | 任意页 | 首页 |
| `keydown End` | 任意页 | 末页 |
| `keydown F/f` | 任意页 | 切换全屏 |
| `click #zone-left` | 左 12% 屏 | 上一页 |
| `click #zone-right` | 右 12% 屏 | 下一页 |
| `click .pg[data-target=N]` | 底部圆点 | 跳到第 N 页 |
| `touchstart → touchend` | 滑动 60px+ | 翻页 |
| URL `#p3` | 加载/刷新 | 直接跳到第 3 页 |

## 切换动画

```css
.slide              { transform: translateX(40px);  opacity: 0; visibility: hidden; }
.slide.active       { transform: translateX(0);     opacity: 1; visibility: visible; }
.slide.prev         { transform: translateX(-40px); opacity: 0; visibility: hidden; }
transition: opacity .35s ease, transform .35s ease;
```

进入下一页时：
- 当前 active.slide 加 `prev` class（向左滑出）
- 下一页 slide 加 `active` class（从右滑入）

## 单页内容溢出处理优先级

**永远不要让内容溢出而不处理。** 处理优先级（必须按顺序尝试）：

1. **第一步**: 试 `data-density="tight"` — 字号 / 图片 / 间距全压
2. **第二步**: 仍溢出 → **拆成两张 slide**
   - 找语义切割点（不同概念之间，比如"实证"和"反向实验"）
   - 第二张加续接 chip（如 "心法 B · 续"）
   - 给第二张独立 H3 标题，避免显得是溢出尾巴
3. **第三步**: 仍溢出 → 移除装饰性图，或缩小核心图

## 转发兼容性约束（必守）

- **单文件**：所有 CSS、JS、image 全部 inline，禁止 `<link>` 或 `<script src>`
- **不引外库**：不用 Reveal.js / Impress.js / Tailwind CDN
- **图大小**：每张 < 200KB（JPEG 75/Z1200 一般够）
- **总大小**：HTML 文件 < 5MB（微信发送上限大致 25MB，但 Chrome/Safari 加载体验在 5MB 以内最佳）

## 打印 / PDF 兼容（可选）

如果用户要求把 deck 导出 PDF，加一段 print CSS：

```css
@media print {
  .deck-bar, .deck-hint, .fullscreen-btn, .click-zone { display: none !important; }
  .slide {
    position: relative !important;
    page-break-after: always;
    transform: none !important;
    opacity: 1 !important;
    visibility: visible !important;
    height: 100vh;
    overflow: visible !important;
  }
}
```

然后 `Ctrl+P` → 保存为 PDF 即可。
