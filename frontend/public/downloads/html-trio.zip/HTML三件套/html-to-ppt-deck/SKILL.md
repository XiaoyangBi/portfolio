---
name: html-to-ppt-deck
description: Convert a long single-page scrollable HTML report into a horizontally-paginated PPT-style HTML deck (single self-contained file with keyboard/click/swipe navigation, fullscreen mode, page anchors). Use when the user wants to "把 HTML 改成 PPT 形式 / 翻页形式 / 一页一页", "做成 PPT 风格 HTML", "横向翻页", "现场分享需要 PPT 模式". Preserves original CSS variables and design system, splits content by sections, supports per-slide density (loose / normal / tight), and handles content overflow either by compression or by splitting one logical section into multiple slides. Output remains a single self-contained HTML that survives forwarding (images stay inlined as base64).
description_zh: HTML 转 PPT 翻页
description_en: HTML to PPT deck
disable: false
agent_created: true
---

# html-to-ppt-deck

## When to use

Trigger when ANY of these signals appear:

- User says: "可以变成一页一页吗", "改成 PPT", "做成 PPT 形式", "类似 PPT 那样", "左右滑动", "分页 / 翻页 HTML", "现场用 PPT 模式"
- User has a long scrollable HTML report (single big `<body>` with stacked sections) and wants to present it on a projector / share live
- User wants both a scrollable version (for forwarding/reading) AND a PPT version (for live presentation) — keep both, do NOT overwrite the scroll version

DO NOT use this skill when:
- User just wants a cosmetic style change (font size, color) — edit HTML directly instead
- The source is a Markdown file or a different format — convert to HTML first, or use a dedicated PPT generator
- The content is short enough to fit on one screen — pagination adds nothing

## Core design decisions to confirm with user before building

Always ask these 4 questions if not already answered. Default recommendations are the **A** option:

1. **Split granularity** — A) coarse: 1 chapter = 1 slide (~8 slides); B) medium: 1 sub-block = 1 slide (~14); C) fine: 1 caption = 1 slide (~22)
2. **Navigation interaction** — A) keyboard ←/→ + bottom dot pagination + click left/right half-screen (recommended); B) wheel scroll; C) page-dot click only
3. **Keep both versions?** — A) keep `<name>.html` (scroll) + `<name>_ppt.html` (deck) (recommended); B) only PPT version, overwrite
4. **Live use vs forwarding priority** — A) live priority (large fonts, fixed timing); B) forward priority (normal fonts, free navigation); C) both (default fonts + free nav + F-key fullscreen) (recommended)

## Steps

### Step 1 · Inspect source structure
Read the source HTML and identify all top-level `<section>` blocks (or major content blocks if no sections exist). Get IDs and rough content size for each.

```bash
grep -n '<section\|</section>' "$SRC" | head
wc -l "$SRC"
```

Record this mapping:
- Which sections will become 1 slide each (low density)
- Which sections need to be split into 2-3 sub-slides (high density)

### Step 2 · Use the build script
Copy `@scripts/build_ppt.py` into the workspace as `_build_ppt.py` and customize:

1. Update `SRC` and `DST` paths
2. Update `extract_section()` calls for the source's section IDs
3. Define how to split high-density sections (use string markers like `<!-- 心法 b -->`, `<div class="arc"`, gallery labels)
4. Build the `slides` list — each entry is `(slide_id, title, html_body, density)` where `density ∈ {loose, normal, tight}`
5. Fill in `cover_html` with the project's title/subtitle/meta

### Step 3 · Run build and verify
```bash
python3 _build_ppt.py
```

Expected output: `Generated <name>_ppt.bak.html · N slides · X KB`

### Step 4 · Inline all images (if source has external image refs)
Use `html-image-inliner` skill or equivalent process: copy `.bak.html` → `.html`, compress images to JPEG, run inliner script, verify zero external `src="image..."` references remain.

### Step 5 · Preview and density review
Open the `<name>_ppt.html`. Walk through every slide and check:

- **Empty slides** (cover, intro, ending) → set density `loose` (large fonts, vertical center)
- **Normal slides** (chapter content) → density `normal` (defaults)
- **Overflow slides** (multiple images + text) → density `tight` first; if STILL overflows, **split into multiple slides**

### Step 6 · Iterate splitting on overflow
**MANDATORY RULE — REMEMBER THIS**:

> "Any slide that overflows: first try `tight` density. If it still overflows, split it into multiple slides. Never let content overflow without action."

When splitting:
- Find a natural semantic boundary (e.g. "实证图组" vs "反向实验" — different concepts)
- Each sub-slide gets a continuation chip (e.g. "心法 B · 续")
- Add a unique heading on the second slide so it doesn't feel like dumb overflow

## Pitfalls

- **`.frame` aspect-ratio sticks even when img is shrunk** — when applying tight density, you MUST explicitly override `.frame { aspect-ratio: auto; min-height: auto; padding: 0; background: transparent; border: none }`, otherwise you get a tall empty frame around a small image.
- **Splitting content cuts middle of `<div>`** — when splitting on a string marker, find the OUTER container's open tag (using `rfind` to walk backward), not just the marker. Then close the unbalanced tags manually at the cut point.
- **Splitting a `.method-grid` container loses outer wrapper** — re-wrap each split into a fresh `.method-wrap` div with `display:flex; flex-direction:column; gap:18px`.
- **Page hash navigation** — always use `#p<N>` URL hash + `history.replaceState` so refresh keeps the user on the same slide.
- **`<header>` / `<footer>` show up in deck mode** — explicitly hide them with `header.header, footer.footer { display: none !important }` in the deck CSS.
- **Slide internal scrolling** — every slide MUST have `overflow-y: auto`, otherwise content past viewport is lost. But keep `overflow-x: hidden` so horizontal slide animation does not clash.
- **Don't break the source HTML's `<style>` block** — extract its inner content and prepend it to the deck CSS. If source has `@media` rules for narrow screens, they still apply inside slides.
- **Forward priority** — must NOT use external JS libraries (no Reveal.js, no Impress.js). Single-file inline JS only, so the file survives forwarding through messengers.
- **Image base64 size budget** — total HTML should stay under ~5 MB. If exceeding, lower JPEG quality to 65 / max-dim to 1000, or remove decorative images.

## Verification

After build + inline:

```bash
# 1. Page count is correct
grep -c 'class="slide"' <name>_ppt.html

# 2. No external image refs (everything inlined)
grep -c 'src="image' <name>_ppt.html       # must be 0
grep -c 'src="data:image/' <name>_ppt.html # must equal image count

# 3. File size sanity check
ls -lh <name>_ppt.html

# 4. Density distribution looks right
grep -oE 'class="slide" [^>]*data-density="[^"]+"' <name>_ppt.html | awk -F'"' '{print $NF}' | sort | uniq -c
```

Then **manually walk every slide** in the browser:
- Cover / first / last → check vertical centering + readable large text
- Image-heavy slides → no white space below images, no overflow
- Press `→` from each slide → next slide loads, dots update, counter updates, hash updates

## Quick reference

- Navigation keys: `←` `→` prev/next, `Space`/`PageDown` next, `Home`/`End` first/last, `F` fullscreen toggle
- URL hash: `<file>.html#p3` deep-links to slide 3
- Mobile: left/right swipe (60px threshold)
- Click hot zones: leftmost/rightmost 12% of viewport

See `@scripts/build_ppt.py` for the full template script.
See `@references/css-deck-framework.md` for the deck CSS contract details.
