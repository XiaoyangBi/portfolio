#!/usr/bin/env python3
"""
TEMPLATE — html-to-ppt-deck

把一个长 scrollable HTML 报告拆成横向翻页 PPT 风格的单文件 HTML deck。
使用前需修改的位置已经标注 [CUSTOMIZE]。

核心要素：
  - 不重写源内容，read source -> extract sections -> wrap into slide framework
  - 保留源 HTML 的 <style>（CSS 变量、字体、颜色全部继承）
  - 注入键盘 / 触摸 / 点击 / 全屏 / hash 路由 JS（inline，不引外库）
  - 每张 slide 标注 density: loose / normal / tight，对应不同字号与图片限高

使用流程：
  1) 修改 SRC / DST 路径
  2) 修改 extract_section() 调用，对应源文件的 section id
  3) 定义如何切割 high-density section（找 marker 用 rfind 回退到外层标签）
  4) 填写 slides 列表，每项 (slide_id, title, html_body, density)
  5) 填写 cover_html
  6) python3 _build_ppt.py
  7) 用 html-image-inliner skill 把 image 嵌入

参考: @SKILL.md, @references/css-deck-framework.md
"""
import re
import sys
from pathlib import Path

# [CUSTOMIZE] 路径
SRC = Path("/path/to/source/report.bak.html")
DST = Path("/path/to/source/report_ppt.bak.html")

html = SRC.read_text(encoding="utf-8")

# 1. 抽取 head 内 <style>...</style>
style_match = re.search(r"<style>(.*?)</style>", html, re.S)
style_inner = style_match.group(1) if style_match else ""

# 2. 抽取 5 个 section
def extract_section(sid):
    m = re.search(rf'<section class="section" id="{sid}">(.*?)</section>', html, re.S)
    return m.group(1).strip() if m else ""

# [CUSTOMIZE] 抽取源文件的 section（按你源文件的 id 改）
mainline_html = extract_section("mainline")
landing_html  = extract_section("landing")
ai_html       = extract_section("ai")
questions_html= extract_section("questions")
outro_html    = extract_section("outro")

# 3. 拆 landing 内部
# 边界标记
def split_blocks(s, delimiters):
    """按文本中出现的 marker 顺序切片，保留 delimiter 在后段开头"""
    cuts = []
    for m in delimiters:
        idx = s.find(m)
        if idx >= 0:
            cuts.append(idx)
    cuts = sorted(set(cuts))
    parts = []
    prev = 0
    for c in cuts:
        parts.append(s[prev:c])
        prev = c
    parts.append(s[prev:])
    return [p.strip() for p in parts if p.strip()]

# Landing 内部分块（按出现顺序）：
# part1 = h2 + 真实状态 insight + 信心区 4 图
# part2 = 中段 down arc + 拍照/传图搜单图
# part3 = 自救 up arc + 5.1 汇报全图
# part4 = 贴链找品 + 沉淀 insight
landing_parts = split_blocks(
    landing_html,
    [
        '<div class="arc"',  # 第一个 arc 起点 -> part2 开始
    ]
)
# 简单二分：part1 = before first arc，rest = from first arc 到末尾
arc_idx = landing_html.find('<div class="arc"')
landing_part1 = landing_html[:arc_idx].strip()
landing_rest = landing_html[arc_idx:].strip()

# 在 landing_rest 内再按 "↑ 自救" 那段 arc 切（找第二个 arc）
second_arc_idx = landing_rest.find('<div class="arc"', 1)
landing_part2 = landing_rest[:second_arc_idx].strip() if second_arc_idx > 0 else landing_rest
landing_remain = landing_rest[second_arc_idx:].strip() if second_arc_idx > 0 else ""

# 在 landing_remain 内按"汇报后的延伸"切
extend_idx = landing_remain.find('汇报后的延伸')
# 往前找最近的 <div class="gallery-label">
if extend_idx > 0:
    gl_idx = landing_remain.rfind('<div class="gallery-label">', 0, extend_idx)
    landing_part3 = landing_remain[:gl_idx].strip()
    landing_part4 = landing_remain[gl_idx:].strip()
else:
    landing_part3 = landing_remain
    landing_part4 = ""

# 4. 拆 AI 内部
# AI part1 = 思维导图（card 含 svg）
# AI part2 = 心法 A
# AI part3 = 心法 B
ai_thinking_end = ai_html.find('<div style="display:flex; flex-direction:column; gap:24px;">')
ai_part1 = ai_html[:ai_thinking_end].strip() if ai_thinking_end > 0 else ai_html
ai_rest = ai_html[ai_thinking_end:].strip() if ai_thinking_end > 0 else ""

# 在 ai_rest 切心法 A（第一个 method）和过渡条 + 心法 B
# method A start: <!-- 心法 a -->
ma = ai_rest.find('<!-- 心法 a -->')
mb = ai_rest.find('<!-- 心法 b -->')
# 过渡条在中间
trans_start = ai_rest.find('<!-- 过渡条')
if ma >= 0 and trans_start > ma:
    ai_part2 = ai_rest[ma:trans_start].strip()
    ai_part3_full = ai_rest[trans_start:].strip()
else:
    ai_part2 = ai_rest
    ai_part3_full = ""

# 把 ai_part3_full 拆成两片：3a（PRD 工作台 + 4 类材料 + 实证三图）和 3b（反向实验 + 一句结论）
# 切割点：「反向实验」note 块的开头
rev_marker = '<strong style="color:var(--text);">反向实验：</strong>'
rev_idx = ai_part3_full.find(rev_marker)
if rev_idx > 0:
    # 往前找最近的 <div class="note"
    cut = ai_part3_full.rfind('<div class="note"', 0, rev_idx)
    if cut > 0:
        ai_part3a_inner = ai_part3_full[:cut].rstrip()
        ai_part3b_inner = ai_part3_full[cut:].rstrip()
    else:
        ai_part3a_inner = ai_part3_full
        ai_part3b_inner = ""
else:
    ai_part3a_inner = ai_part3_full
    ai_part3b_inner = ""

# 处理收尾标签：3a 必须把 .method 和 .method-wrap 关闭；3b 需要重新外包标题
# 简单做法：因为 3a 切完后，<!-- 过渡条 → method 起始 → 内容 → 还没 </div></div>，
# 我们手工补齐
def close_method_tail(inner):
    """如果切片中 method 标签没闭合，补上 </div></div>"""
    open_method = inner.count('<div class="method">')
    close_count = inner.count('</div>')
    # 简单判断：method-wrap 外层 div + method 内层 div 都需要闭合
    return inner + '\n        </div>\n      </div>'

# 3a 末尾补闭合
if ai_part3a_inner:
    ai_part3a = '<div class="method-wrap" style="display:flex; flex-direction:column; gap:18px;">' + close_method_tail(ai_part3a_inner) + '</div>'
else:
    ai_part3a = ''

# 3b 头部需要新建一个 method 卡片包住反向实验
if ai_part3b_inner:
    ai_part3b = (
        '<div class="method-wrap" style="display:flex; flex-direction:column; gap:18px;">'
        '<div class="method">'
        '<div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-bottom:12px;">'
        '<span class="tag">心法 B · 续</span>'
        '<span style="display:inline-block; background:var(--danger-light); border:1px solid #fca5a5; color:var(--danger); font-size:11px; font-weight:600; padding:3px 10px; border-radius:999px; letter-spacing:0.3px;">反向实验 · 检验干净度</span>'
        '</div>'
        '<h3>故意打破规则会发生什么？</h3>'
        + ai_part3b_inner +
        '</div>'
        '</div>'
    )
else:
    ai_part3b = ''


# 5. 构造 9 张 slides（粗拆但不爆页）
# slide 0 = 封面（hero）
# slide 1 = 主线开场（mainline）
# slide 2 = Landing - part1（信心区）
# slide 3 = Landing - part2（中段 down + 拍图搜）
# slide 4 = Landing - part3（自救 + 汇报）
# slide 5 = Landing - part4（贴链 + 沉淀）
# slide 6 = AI - 思维导图
# slide 7 = AI - 心法 A
# slide 8 = AI - 心法 B
# slide 9 = 困惑
# slide 10 = 致谢

# [CUSTOMIZE] 封面页 HTML — 改成你项目的标题/副标/署名
cover_html = '''
<div class="slide-cover">
  <div class="cover-tag">新人交流会分享</div>
  <h1 class="cover-title">从被打破的闭环<br>到自己造一个闭环</h1>
  <div class="cover-meta">
    <span><span class="dot"></span>毕骁扬 · 笔笔省购物搜索</span>
    <span><span class="dot"></span>2026.05.29 周五</span>
  </div>
</div>
'''

# [CUSTOMIZE] slides 列表 — 每项 (slide_id, title, html_body, density)
# density 取值: loose（封面/扉页/致谢，字大居中）
#               normal（默认章节）
#               tight（图密集页，强制压缩）

slides = [
    ("cover",     "封面",                       cover_html,        "loose"),
    ("mainline",  "主线",                       mainline_html,     "loose"),
    ("landing-1", "Landing · 前段（信心区）",    landing_part1,     "normal"),
    ("landing-2", "Landing · 中段（拍照/传图搜）", landing_part2,    "normal"),
    ("landing-3", "Landing · 自救（5.1 汇报）",   landing_part3,    "normal"),
    ("landing-4", "Landing · 延伸 + 沉淀",       landing_part4,     "tight"),
    ("ai-1",      "AI · Harness 思维导图",       ai_part1,          "normal"),
    ("ai-2",      "AI · 心法 A · 阅读系统",      ai_part2,          "normal"),
    ("ai-3a",     "AI · 心法 B · PRD 工作台",    ai_part3a,         "tight"),
    ("ai-3b",     "AI · 心法 B · 反向实验",      ai_part3b,         "normal"),
    ("questions", "我的困惑",                    questions_html,    "loose"),
    ("outro",     "致谢",                        outro_html,        "loose"),
]

# 6. 生成 PPT 框架 HTML
ppt_extra_css = """
/* === PPT 翻页框架 === */
html, body {
  height: 100%;
  margin: 0;
  overflow: hidden;
  background: var(--bg);
}
body { display: flex; flex-direction: column; }
header.header { display: none !important; }
footer.footer { display: none !important; }

.deck {
  flex: 1;
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
}
.slide {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100vh;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 56px clamp(32px, 6vw, 96px) 88px;
  box-sizing: border-box;
  opacity: 0;
  visibility: hidden;
  transform: translateX(40px);
  transition: opacity .35s ease, transform .35s ease, visibility 0s linear .35s;
  background: var(--bg);
}
.slide.active {
  opacity: 1;
  visibility: visible;
  transform: translateX(0);
  transition: opacity .35s ease, transform .35s ease, visibility 0s;
}
.slide.prev { transform: translateX(-40px); }

.slide-inner {
  max-width: 1100px;
  margin: 0 auto;
}

.slide .section h2 {
  font-size: clamp(22px, 2.6vw, 30px);
  margin: 0 0 18px;
  letter-spacing: -0.5px;
  color: var(--text);
  border-left: 4px solid var(--primary);
  padding-left: 12px;
}
.slide .section { padding: 0; margin: 0; }

/* === 内容密度分级 === */
/* 空页（封面/主线/困惑/致谢）—— 放大、居中 */
.slide[data-density="loose"] { display: flex; align-items: center; padding-top: 56px; padding-bottom: 88px; }
.slide[data-density="loose"] .slide-inner { width: 100%; }

.slide[data-density="loose"] .section h2 {
  font-size: clamp(28px, 3.4vw, 40px);
  margin-bottom: 28px;
}
.slide[data-density="loose"] .lead {
  font-size: clamp(16px, 1.8vw, 20px);
  line-height: 1.85;
}
.slide[data-density="loose"] .stage-num { font-size: 13px; }
.slide[data-density="loose"] .stage-title { font-size: clamp(22px, 2.6vw, 30px); }
.slide[data-density="loose"] .stage-sub { font-size: clamp(14px, 1.4vw, 16px); line-height: 1.7; }
.slide[data-density="loose"] .arrow { font-size: 32px; color: var(--primary); }
.slide[data-density="loose"] .stage { padding: 28px 24px; }

.slide[data-density="loose"] .qs h3 { font-size: clamp(20px, 2vw, 24px); }
.slide[data-density="loose"] .qbody { font-size: clamp(14px, 1.5vw, 17px); line-height: 1.85; }
.slide[data-density="loose"] .qn { font-size: 28px; }
.slide[data-density="loose"] .q { padding: 32px 28px; }

.slide[data-density="loose"] .outro p { font-size: clamp(15px, 1.6vw, 18px); }
.slide[data-density="loose"] .outro .sign { font-size: clamp(14px, 1.5vw, 17px); }
.slide[data-density="loose"] .outro { padding: 36px 32px; }

/* 紧凑页（贴链找品、心法 B）—— 缩小图、缩短间距 */
.slide[data-density="tight"] .shot .frame {
  aspect-ratio: auto !important;
  min-height: auto !important;
  padding: 0 !important;
  background: transparent !important;
  border: none !important;
}
.slide[data-density="tight"] .shot .frame img {
  max-height: 240px !important;
  object-fit: contain !important;
  width: auto !important;
  max-width: 100% !important;
  margin: 0 auto !important;
  display: block !important;
}
.slide[data-density="tight"] .shot {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 8px;
}
.slide[data-density="tight"] .caption { font-size: 12px; padding-top: 6px; }
.slide[data-density="tight"] .caption .tag { font-size: 10px; padding: 1px 6px; }
.slide[data-density="tight"] .caption .sub { font-size: 11px; }
.slide[data-density="tight"] .gallery-label { margin: 14px 0 8px; font-size: 12px; }
.slide[data-density="tight"] .desc, .slide[data-density="tight"] p, .slide[data-density="tight"] .lead { font-size: 13px; line-height: 1.65; }
.slide[data-density="tight"] .method { padding: 16px 18px; }
.slide[data-density="tight"] .method h3 { font-size: 16px; margin: 4px 0 8px; }
.slide[data-density="tight"] .prompt { font-size: 12.5px; padding: 10px 12px; }
.slide[data-density="tight"] .chain-step { padding: 10px 8px !important; font-size: 11px; }
.slide[data-density="tight"] .chain-step .n { font-size: 10px; }
.slide[data-density="tight"] .mat { padding: 10px 8px; font-size: 12px; }
.slide[data-density="tight"] .mat-tag { font-size: 10px; }
.slide[data-density="tight"] .note { font-size: 12px; }
.slide[data-density="tight"] .insight p { font-size: 13px; line-height: 1.7; }
.slide[data-density="tight"] .insight { padding: 14px 18px; }


/* 翻页控件 */
.deck-bar {
  position: fixed;
  bottom: 14px;
  left: 0;
  right: 0;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 14px;
  z-index: 50;
  pointer-events: none;
}
.deck-bar > * { pointer-events: auto; }
.dot-pages {
  display: flex;
  gap: 6px;
  background: rgba(255,255,255,0.92);
  border: 1px solid var(--border);
  border-radius: 999px;
  padding: 7px 14px;
  backdrop-filter: blur(8px);
}
.dot-pages .pg {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--text3);
  border: none;
  cursor: pointer;
  padding: 0;
  transition: all .2s;
  opacity: 0.4;
}
.dot-pages .pg.active {
  width: 24px;
  border-radius: 4px;
  background: var(--primary);
  opacity: 1;
}
.dot-pages .pg:hover { opacity: 0.85; }

.page-counter {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--text2);
  background: rgba(255,255,255,0.92);
  border: 1px solid var(--border);
  border-radius: 999px;
  padding: 7px 14px;
  font-weight: 600;
  letter-spacing: 0.5px;
}

.deck-hint {
  position: fixed;
  top: 14px;
  right: 14px;
  z-index: 50;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text3);
  background: rgba(255,255,255,0.85);
  border: 1px solid var(--border);
  border-radius: 999px;
  padding: 6px 12px;
  backdrop-filter: blur(8px);
  letter-spacing: 0.3px;
}
.deck-hint kbd {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 4px;
  padding: 1px 6px;
  font-family: var(--font-mono);
  font-size: 10px;
  margin: 0 2px;
}

.fullscreen-btn {
  position: fixed;
  top: 14px;
  left: 14px;
  z-index: 50;
  background: rgba(255,255,255,0.92);
  border: 1px solid var(--border);
  border-radius: 999px;
  padding: 6px 14px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text2);
  cursor: pointer;
  letter-spacing: 0.5px;
  font-weight: 600;
  transition: all .2s;
}
.fullscreen-btn:hover { color: var(--primary); border-color: var(--primary); }

/* 点击左右半屏热区 */
.click-zone {
  position: fixed;
  top: 0;
  width: 12%;
  height: 100vh;
  z-index: 5;
  cursor: pointer;
  background: transparent;
}
.click-zone.left { left: 0; }
.click-zone.right { right: 0; }
.click-zone:hover::before {
  content: '';
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: rgba(7, 193, 96, 0.12);
}
.click-zone.left:hover::before { left: 18px; }
.click-zone.right:hover::before { right: 18px; }

/* 封面页 */
.slide-cover {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  padding: 0 clamp(20px, 6vw, 80px);
}
.cover-tag {
  font-family: var(--font-mono);
  font-size: 13px;
  color: var(--primary-dark);
  letter-spacing: 1.5px;
  text-transform: uppercase;
  margin-bottom: 24px;
  padding: 6px 14px;
  background: var(--primary-light);
  border-radius: 999px;
  display: inline-block;
}
.cover-title {
  font-size: clamp(36px, 6vw, 64px);
  font-weight: 700;
  line-height: 1.18;
  letter-spacing: -1.5px;
  color: var(--text);
  margin: 0 0 32px;
}
.cover-meta {
  display: flex;
  flex-direction: column;
  gap: 10px;
  font-family: var(--font-mono);
  font-size: 14px;
  color: var(--text2);
}
.cover-meta .dot {
  display: inline-block;
  width: 5px; height: 5px;
  background: var(--primary);
  border-radius: 50%;
  margin-right: 8px;
  vertical-align: middle;
}

/* 滚动条美化 */
.slide::-webkit-scrollbar { width: 6px; }
.slide::-webkit-scrollbar-track { background: transparent; }
.slide::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
.slide::-webkit-scrollbar-thumb:hover { background: var(--text3); }

/* 移动端 */
@media (max-width: 720px) {
  .slide { padding: 32px 16px 76px; }
  .deck-hint { display: none; }
  .click-zone { width: 18%; }
  .cover-title { font-size: 32px; }
}
"""

slides_html = ""
for idx, (sid, title, body, density) in enumerate(slides):
    slides_html += f'<section class="slide" id="slide-{idx}" data-slide-id="{sid}" data-title="{title}" data-density="{density}"><div class="slide-inner">{body}</div></section>\n'

dot_buttons = "".join(
    f'<button class="pg" data-target="{i}" title="{slides[i][1]}"></button>'
    for i in range(len(slides))
)

ppt_js = """
<script>
(function(){
  var slides = document.querySelectorAll('.slide');
  var dots = document.querySelectorAll('.dot-pages .pg');
  var counter = document.getElementById('page-counter');
  var total = slides.length;
  var current = 0;
  // 触摸滑动
  var touchStartX = null;
  var touchStartY = null;

  function go(idx) {
    if (idx < 0) idx = 0;
    if (idx >= total) idx = total - 1;
    if (idx === current) return;
    slides[current].classList.remove('active');
    if (idx < current) {
      slides[current].classList.add('prev');
    } else {
      slides[current].classList.remove('prev');
    }
    current = idx;
    slides[current].classList.add('active');
    slides[current].classList.remove('prev');
    slides[current].scrollTop = 0;
    dots.forEach(function(d, i){ d.classList.toggle('active', i === current); });
    counter.textContent = (current + 1).toString().padStart(2, '0') + ' / ' + total.toString().padStart(2, '0');
    // 同步 hash
    history.replaceState(null, '', '#p' + (current + 1));
  }

  function next() { go(current + 1); }
  function prev() { go(current - 1); }

  // 键盘
  document.addEventListener('keydown', function(e){
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
    if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') { e.preventDefault(); next(); }
    else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); prev(); }
    else if (e.key === 'Home') { go(0); }
    else if (e.key === 'End') { go(total - 1); }
    else if (e.key === 'f' || e.key === 'F') {
      if (!document.fullscreenElement) document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
      else document.exitFullscreen && document.exitFullscreen();
    }
  });

  // 点击左右半屏（避开链接、按钮、滚动条）
  document.getElementById('zone-left').addEventListener('click', prev);
  document.getElementById('zone-right').addEventListener('click', next);

  // 页码点击
  dots.forEach(function(d){
    d.addEventListener('click', function(){ go(parseInt(d.dataset.target, 10)); });
  });

  // 全屏按钮
  document.getElementById('fs-btn').addEventListener('click', function(){
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen && document.exitFullscreen();
    }
  });

  // 触摸滑动
  document.addEventListener('touchstart', function(e){
    if (e.touches.length !== 1) return;
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
  }, {passive:true});
  document.addEventListener('touchend', function(e){
    if (touchStartX == null) return;
    var dx = (e.changedTouches[0].clientX - touchStartX);
    var dy = (e.changedTouches[0].clientY - touchStartY);
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.4) {
      if (dx < 0) next(); else prev();
    }
    touchStartX = null;
  }, {passive:true});

  // 启动
  function init() {
    slides.forEach(function(s){ s.classList.remove('active','prev'); });
    var hash = (location.hash || '').replace('#p','');
    var startIdx = parseInt(hash, 10);
    if (!isNaN(startIdx) && startIdx >= 1 && startIdx <= total) current = startIdx - 1;
    slides[current].classList.add('active');
    dots[current].classList.add('active');
    counter.textContent = (current + 1).toString().padStart(2, '0') + ' / ' + total.toString().padStart(2, '0');
  }
  init();
})();
</script>
"""

# 处理 ai_part2 / ai_part3 中残留的 .method-grid 容器需要换为 method-wrap（已 wrap）
# 检查 .method-grid 是否还出现
final_html = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>新人分享 · 毕骁扬 · PPT 版</title>
<style>
{style_inner}
{ppt_extra_css}
</style>
</head>
<body>

<button id="fs-btn" class="fullscreen-btn" title="全屏 (F)">⛶ 全屏</button>
<div class="deck-hint">键盘 <kbd>←</kbd><kbd>→</kbd> · 空格翻页 · <kbd>F</kbd> 全屏</div>

<div class="click-zone left" id="zone-left" title="上一页"></div>
<div class="click-zone right" id="zone-right" title="下一页"></div>

<div class="deck">
{slides_html}
</div>

<div class="deck-bar">
  <div class="dot-pages">
    {dot_buttons}
  </div>
  <div class="page-counter" id="page-counter">01 / {len(slides):02d}</div>
</div>

{ppt_js}

</body>
</html>
"""

DST.write_text(final_html, encoding="utf-8")
print(f"Generated {DST.name} · {len(slides)} slides · {len(final_html)/1024:.1f} KB")
