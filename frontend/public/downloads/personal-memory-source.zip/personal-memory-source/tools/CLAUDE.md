# tools/

L2 | 父级: ../CLAUDE.md

## 成员

memory_runtime.py：当前/历史组包、按 query 编译、写入门禁、四项认知报告、使用回执、可审核蒸馏版本包与蒸馏决定台账。
compile 以 BM25 和元数据过滤自动召回，query、Notes、记忆与回查提示共享 8000 字符。
自动候选保持 BM25 顺序并跳过可选分层配额；手工 pack 与 required 的权重、分层限制不变。
编译回执重算检索和 Notes 哈希；访问强度不参与召回排序。
正文上限 8000 字符，required 不可静默跳过。
默认只选 active 且处于有效期内的记录，历史须显式 include-history。
读回执仅在显式 ack 后生成，按会话和文件幂等，保留 as_of 与历史视图。
自动写限定为已有项目/关系文件的新事实原文。
replace-confirmed 只执行已确认唯一精确替代，同步变更日志、回读并扫描残留。
原文审计先落盘，已写入内容回读验证；历史写入失败恢复目标正文。
cue 校验 description/tags 召回线索，--target 不合格退出码 2。
distill / forget / strength 只出候选和溯源路径，不删除、不归档、不改写正文。
health 汇总四项并只生成当前记录的复核报告，不归档或删除；附带 outcome_review 只读汇总与 distill_review 已审分布。
outcome 绑定真实组包 receipt 追加使用回执，session 与证据不可凭空指定，跳过的候选留痕作漏报线索。
outcome-summary 分轴报告证据有效率与纠正率；无记录时指标为 null，不把未观测写成零失败或零成本。
distill-pack 在工作区生成带 source_sha256 / evidence_hash 的待审版本包，候选全为 pending 且不生成归纳正文。
distill-verify 复算源正文哈希，变化即标 stale。
distill-decide 在版本包内追加一次 accept / reject，同步写决定台账，审完全部候选置顶层 status=reviewed。
distill-import 幂等把既有版本包 decisions 镜像进台账并补修顶层 status；不重算候选，不写正文。
candidate_id 是 kind、source_paths、shared_cues 的稳定指纹，distill 与版本包共用；distill 默认列出全部候选并标注 decision / reviewed_at，--only-unreviewed 显式过滤。
以上都不改记忆正文，accept 不等于写入，沉淀仍按 README 第 7 节由小毕确认。

build_index.py：从必填字段和可选生命周期元数据编译总索引。
先校验结构、字段、有效日期、替代指针和 context/facts 原子 schema，再原子替换 INDEX。
只扫描五层目录，不收集运行日志。

task_state.py：工作区任务 Notes、结构化 History、hint 与精确搜索。
状态位于 .agent-state/tasks/<task_id>/，不写长期记忆，不复制完整模型 Trace。

 test_memory_runtime.py：隔离临时库的 unittest。
覆盖预算、访问、闲置、证据门禁、生命周期、确认替代、失败恢复、query 编译，以及编码 cue、蒸馏、遗忘与命中反哺。
测试不向真实访问日志写记录。
test_memory_content.py：真实记忆当前口径的只读回归，不写文件。
test_build_index.py：生命周期字段、有效日期、替代指针和原子 schema 的隔离回归。
test_task_state.py：任务 Notes、History、hint、搜索与路径边界的隔离回归。
test_recall_outcome.py：使用回执追加、校验、分轴汇总、组包绑定与 CLI 接线的隔离回归。
test_distill_bundle.py：版本包只读性、证据漂移、决定校验、顶层状态、台账幂等、已审标注与 CLI 端到端的隔离回归。

recall_outcome.jsonl：运行时追加的召回使用回执，不参与 INDEX 或召回。
distill_decisions.jsonl：运行时追加的蒸馏决定台账，只存指纹、决定、版本与时间，按 (candidate_id, version_id) 幂等，不参与 INDEX 或召回。
write_audit.jsonl：运行时生成的本地证据审计。
原始证据不自动推送远端。
.memory-runtime.lock：脚本写入的文件锁。
只协调本脚本，不能阻止其他编辑器修改。

## 数据流

README 路由 → 当前/历史 pack → Agent 读包 → ack。
任务 Notes + 当前 query + 自动召回 → compile → Agent 读包 → ack。
任务事件 → 工作区 HISTORY；信息不足 → search / 原始 Trace 回查。
原文候选 → audit → 原文增补 → 回读。
确认替代 → 当前正文 + 变更日志 → 回读 → 残留复核。
回读通过 → cue --target 门禁 → build_index → 单独提交 → 推私库。
ack 回执 → strength 体检排序（不参与 pack 选择）。
真实组包 → outcome 使用回执 → outcome-summary 分轴汇总（不参与召回排序，不改正文）。
distill 候选 → 库外版本包 → distill-verify 证据复验 → distill-decide 人工决定（不写记忆）。
distill-decide / distill-import → 决定台账 → distill 标注已审 → --only-unreviewed 取干净候选集（不写记忆）。

## 检查

python tools/test_memory_runtime.py
python tools/test_memory_content.py
python tools/test_build_index.py
python tools/test_task_state.py
python tools/test_recall_outcome.py
python tools/test_distill_bundle.py
python tools/build_index.py
python tools/memory_runtime.py health
python tools/memory_runtime.py cue
python tools/memory_runtime.py distill
python tools/memory_runtime.py distill --only-unreviewed
python tools/memory_runtime.py forget
python tools/memory_runtime.py strength
python tools/memory_runtime.py outcome-summary

[PROTOCOL]: 变更时更新此头部，然后检查 CLAUDE.md
