#!/usr/bin/env python3
"""Build bounded memory packets, audit writes and report encoding/consolidation health.

[INPUT]: Markdown memories, selectors, lifecycle metadata, receipts, evidence, outcomes and distill decisions.
[OUTPUT]: JSON packets, route plans, skipped-cue lines, append-only access/audit/outcome/decision records and review candidates.
[POS]: Current view is default; writes are confirmed; runtime curation is read-only and never edits memory.
[PROTOCOL]: Change this contract, then check tools/CLAUDE.md and ../CLAUDE.md.
"""
from __future__ import annotations
import argparse
import contextlib
import datetime as dt
import fcntl
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile

LIMIT = 8000
LAYERS = {"identity": "W1", "principles": "W1", "preferences": "W2", "context": "W4"}
CAPS = {"W1": 3, "W2": 3, "W3": 2, "W4": 3, "W5": 1}
MAX_FILES = 6
DEEP_QUERY_TERM_THRESHOLD = 12
ROUTE_L2_MARKERS = ("原话", "出处", "证据", "追溯", "哪天", "对比", "变化", "历史",
                    "以前", "过去", "为什么", "原因", "进展", "汇总", "所有", "哪些",
                    "关系", "过程", "复盘")
CUE_HEADER = "[CONTEXT skipped_cues]"
CUE_LINE_BUDGET = 300
SECTION_FLOOR = 600
SKIPPED_USED = ("yes", "partial", "no")
HISTORY_PATH = "knowledge/experiences/memory-changelog.md"
GENERIC_CUES = frozenset({"记忆系统", "规范", "测试", "笔记", "其他", "通用", "总结", "资料",
                          "文档", "记录", "方法", "索引", "杂项", "外部输入", "变更日志"})
CUE_MARKERS = ("时调用", "时读", "时查", "时参考", "用于", "遇到", "需要", "场景", "任务",
               "调用", "回答", "写", "查", "分析", "评估", "设计", "排查", "处理", "生成",
               "整理", "汇报", "答辩", "面试", "决策", "判断", "优化", "回顾", "确认")
DATE_LINE = re.compile(r"\d{4}[-/年]\d{1,2}[-/月]\d{1,2}|\d{1,2}月\d{1,2}日|"
                       r"\d{4}\.\d{1,2}\.\d{1,2}|\d{4}-\d{2}-\d{2}")
ACCESS_HEADER = """# ACCESS_LOG

运行记录，不是用户记忆；不参与 INDEX 或召回。只记录已读 packet 的文件。
从此文件创建后开始计数，不回填历史；同会话同文件只记一次。

| 日期 | 会话 | 路径 | 字符 | 片段SHA256 |
|---|---|---|---|---|
"""


def now():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def metadata(text):
    match = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not match:
        raise ValueError("missing frontmatter")
    return {k.strip(): v.strip().strip('\"') for line in match[1].splitlines()
            if ":" in line for k, v in [line.split(":", 1)]}


def body(text):
    return re.sub(r"^---\n.*?\n---\n", "", text, count=1, flags=re.S).strip()


def is_current(meta, as_of):
    if meta.get("status") != "active" or meta.get("superseded_by"):
        return False
    valid_from = meta.get("valid_from")
    valid_to = meta.get("valid_to")
    if valid_from and as_of < dt.date.fromisoformat(valid_from):
        return False
    if valid_to and as_of >= dt.date.fromisoformat(valid_to):
        return False
    return True


def resolve_memory(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError(f"invalid memory path: {relative}")
    parts = path.relative_to(root.resolve()).parts
    if path.suffix != ".md" or not (len(parts) == 3 and parts[0] in LAYERS or
                                    len(parts) == 3 and parts[0] == "knowledge" or
                                    relative == "BASELINE.md"):
        raise ValueError(f"not a memory file: {relative}")
    return path


def weight(relative):
    parts = relative.split("/")
    if relative == "BASELINE.md":
        return "base"
    if parts[0] == "knowledge":
        return "W3" if parts[1] == "skills" else "W5"
    return LAYERS[parts[0]]


def select(root, selector, as_of=None, include_history=False):
    relative, _, heading = selector.partition("#")
    path = resolve_memory(root, relative)
    text = path.read_text(encoding="utf-8")
    day = as_of or dt.date.today()
    if not include_history and not is_current(metadata(text), day):
        raise ValueError(f"archived or inactive; not current at {day}: {relative}")
    content = body(text)
    if heading:
        lines = content.splitlines()
        hits = [i for i, line in enumerate(lines) if re.match(r"^#{1,6} ", line)
                and re.sub(r"^#+ ", "", line) == heading]
        if len(hits) != 1:
            raise ValueError(f"heading not unique or absent: {selector}")
        start = hits[0]
        level = len(lines[start].split(" ", 1)[0])
        end = next((i for i in range(start + 1, len(lines))
                    if re.match(r"^#{1,6} ", lines[i]) and
                    len(lines[i].split(" ", 1)[0]) <= level), len(lines))
        content = "\n".join(lines[start:end]).strip()
    return {"selector": selector, "path": relative, "weight": weight(relative),
            "content": content, "chars": len(content), "sha256": digest(content)}


@contextlib.contextmanager
def locked(root):
    tools = root / "tools"
    if not tools.is_dir():
        tools.mkdir(exist_ok=True)
    with (tools / ".memory-runtime.lock").open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        yield


def access_rows(root):
    path = root / "ACCESS_LOG.md"
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        columns = [c.strip() for c in line.strip("|").split("|")]
        if len(columns) == 5 and re.fullmatch(r"\d{4}-\d{2}-\d{2}", columns[0]):
            rows.append(dict(zip(["date", "session", "path", "chars", "sha256"], columns)))
    return rows


OUTCOME_FILE = "tools/recall_outcome.jsonl"
OUTCOME_CITED = frozenset({"yes", "partial", "no"})
OUTCOME_CORRECTION = frozenset({"none", "confirmed", "rewritten", "rejected"})
ID_SHORT_LENGTH = 16
VERSION_SHORT_LENGTH = 8


def outcome_rows(root):
    path = root / OUTCOME_FILE
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def record_outcome(root, session, selectors, cited, correction, packet_sha=None,
                   evidence=(), note="", skipped=(), route_tier=None, chars_used=None,
                   skipped_used=None, latency_ms=None):
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", session):
        raise ValueError("session requires an explicit ASCII identifier")
    if cited not in OUTCOME_CITED:
        raise ValueError("cited_in_answer must be yes, partial or no")
    if correction not in OUTCOME_CORRECTION:
        raise ValueError("user_correction must be none, confirmed, rewritten or rejected")
    if route_tier not in (None, "L1", "L2"):
        raise ValueError("route_tier must be L1, L2 or null")
    if skipped_used is not None and skipped_used not in SKIPPED_USED:
        raise ValueError("skipped_used must be yes, partial, no or null")
    for label, value in (("chars_used", chars_used), ("latency_ms", latency_ms)):
        if value is not None and (not isinstance(value, (int, float)) or value < 0):
            raise ValueError(f"{label} must be a non-negative measured number or null")
    paths = list(dict.fromkeys(selectors))
    if not paths:
        raise ValueError("at least one recalled selector is required")
    row = {"ts": now(), "session": session, "selectors": paths,
           "cited_in_answer": cited, "user_correction": correction,
           "packet_sha256": packet_sha, "packet_skipped": list(dict.fromkeys(skipped)),
           "evidence": list(evidence), "note": note,
           "route_tier": route_tier, "chars_used": chars_used,
           "skipped_used": skipped_used, "latency_ms": latency_ms}
    with locked(root):
        with (root / OUTCOME_FILE).open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    return {"action": "append_only_outcome_record", "path": OUTCOME_FILE, "record": row,
            "note": "ACCESS_LOG.md 保持原表格格式；本记录不改写任何记忆正文"}


def outcome_from_packet(root, data, cited, correction, session=None, evidence=(), note="",
                        skipped_used=None, latency_ms=None):
    """Bind a usage receipt to a real packet; session and evidence cannot be invented."""
    if not isinstance(data, dict) or not isinstance(data.get("receipt"), dict):
        raise ValueError("packet must contain a receipt object")
    receipt = data["receipt"]
    items = receipt.get("items")
    if not items:
        raise ValueError("packet receipt has no recalled items")
    packet_session = str(receipt.get("session", ""))
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", packet_session):
        raise ValueError("packet receipt session is invalid")
    if session and session != packet_session:
        raise ValueError("session must match the packet receipt session")
    skipped = [row["selector"] for row in (data.get("skipped") or []) if "selector" in row]
    selectors = [row["path"] for row in items]
    result = record_outcome(root, packet_session, selectors, cited, correction,
                            receipt.get("context_sha256"), evidence, note, skipped,
                            receipt.get("route_tier"), receipt.get("chars"),
                            skipped_used, latency_ms)
    result["packet_session"] = packet_session
    result["packet_skipped"] = skipped
    return result


def outcome_summary(root):
    rows = outcome_rows(root)
    if not rows:
        return {"observed": False, "records": 0, "sessions": 0,
                "evidence_effective_rate": None, "correction_rate": None,
                "packets_with_skips": None, "skipped_events": None,
                "by_tier": None, "measured": None,
                "note": "无有效记录时指标为 null，不把未观测写成零失败或零成本"}
    cited = sum(1 for row in rows if row.get("cited_in_answer") in {"yes", "partial"})
    corrected = sum(1 for row in rows if row.get("user_correction") != "none")
    skipped_rows = [row.get("packet_skipped") or [] for row in rows]

    def measured_mean(field):
        values = [row[field] for row in rows if isinstance(row.get(field), (int, float))]
        return {"observed": len(values),
                "mean": round(sum(values) / len(values), 2) if values else None}

    skipped_used = [row.get("skipped_used") for row in rows
                    if row.get("skipped_used") in SKIPPED_USED]
    return {"observed": True, "records": len(rows),
            "sessions": len({row["session"] for row in rows}),
            "evidence_effective_rate": round(cited / len(rows), 4),
            "correction_rate": round(corrected / len(rows), 4),
            "packets_with_skips": sum(1 for item in skipped_rows if item),
            "skipped_events": sum(len(item) for item in skipped_rows),
            "by_cited": {key: sum(1 for row in rows if row.get("cited_in_answer") == key)
                         for key in sorted(OUTCOME_CITED)},
            "by_correction": {key: sum(1 for row in rows if row.get("user_correction") == key)
                              for key in sorted(OUTCOME_CORRECTION)},
            "by_tier": {"L1": sum(1 for row in rows if row.get("route_tier") == "L1"),
                        "L2": sum(1 for row in rows if row.get("route_tier") == "L2"),
                        "unobserved": sum(1 for row in rows
                                          if row.get("route_tier") is None)},
            "measured": {"chars_used": measured_mean("chars_used"),
                         "latency_ms": measured_mean("latency_ms"),
                         "skipped_used": {
                             "observed": len(skipped_used),
                             "by_value": {key: skipped_used.count(key)
                                          for key in SKIPPED_USED}}},
            "note": "分轴报告，不压成单一总分；未采集的字段记 null；skipped 只是漏报线索，漏报率需人工标注应召回集合后另算"}


def packet(root, selectors, required=(), session="", general=False, budget=LIMIT,
           as_of=None, include_history=False, ranked=False):
    if not 1 <= budget <= LIMIT:
        raise ValueError("budget must be between 1 and 8000 characters")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", session):
        raise ValueError("session requires an explicit ASCII identifier")
    day = as_of or dt.date.today()
    base_selector = "BASELINE.md"
    if general:
        if selectors or required:
            raise ValueError("general mode cannot select business memory")
        base_selector += "#我要 AI 怎么协作（W2，详见 preferences/）"
    items = [select(root, base_selector, day, include_history)]
    selected = set([base_selector])
    required = list(dict.fromkeys(required))
    optional = list(dict.fromkeys(selectors))
    if not ranked:
        optional.sort(key=lambda s: weight(s.split("#")[0]))
    skipped, counts = [], {}

    def render(records):
        return "\n\n".join(f"[MEMORY {r['selector']}]\n{r['content']}" for r in records)

    if len(render(items)) > budget:
        raise ValueError("baseline exceeds budget; explicit baseline maintenance is required")
    for selector in required + optional:
        if selector in selected:
            continue
        row = select(root, selector, day, include_history)
        mandatory = selector in required
        reason = None
        if len(render(items + [row])) > budget:
            reason = "character_budget"
        elif (len(items) - 1 >= MAX_FILES or
              ((mandatory or not ranked) and
               counts.get(row["weight"], 0) >= CAPS[row["weight"]])):
            reason = "channel_quota"
        if reason:
            if mandatory:
                raise ValueError(
                    f"required memory cannot fit: {selector} ({reason}); "
                    "select complete relevant sections")
            skipped.append({"selector": selector, "reason": reason})
            continue
        items.append(row)
        selected.add(selector)
        counts[row["weight"]] = counts.get(row["weight"], 0) + 1
    context = render(items)
    receipt = {"session": session, "created_at": now(), "context_sha256": digest(context),
               "chars": len(context), "budget": budget, "as_of": str(day),
               "include_history": include_history,
               "items": [{k: v for k, v in row.items() if k != "content"} for row in items]}
    return {"context": context, "chars": len(context), "budget": budget,
            "skipped": skipped, "receipt": receipt}


def query_terms(text):
    terms = []
    for part in re.findall(r"[a-z0-9_]+|[\u4e00-\u9fff]+", text.lower()):
        if part[0].isascii():
            terms.append(part)
        elif len(part) == 1:
            terms.append(part)
        else:
            terms.extend(part[index:index + 2] for index in range(len(part) - 1))
    return terms


def retrieval_depth(query):
    markers = ("对比", "变化", "历史", "以前", "过去", "为什么", "原因", "进展",
               "汇总", "所有", "哪些", "关系", "过程", "复盘")
    deep_query = any(marker in query for marker in markers) or \
        len(query_terms(query)) > DEEP_QUERY_TERM_THRESHOLD
    return "high" if deep_query else "low"


def route_tier(query, tier=None):
    """Resolve an explicit tier override; None keeps the legacy compile path."""
    if tier is None:
        return None
    if tier == "auto":
        return "L2" if any(marker in query for marker in ROUTE_L2_MARKERS) else "L1"
    if tier not in ("L1", "L2"):
        raise ValueError("tier must be auto, L1 or L2")
    return tier


def route_report(root, query):
    """Read-only scheduling plan; builds no packet and reads no memory file."""
    tier = route_tier(query, "auto")
    depth = retrieval_depth(query)
    return {"tier": tier, "depth": depth,
            "markers": [marker for marker in ROUTE_L2_MARKERS if marker in query],
            "candidate_limit": 5 if depth == "high" else 3,
            "cue_budget": CUE_LINE_BUDGET if tier == "L2" else 0,
            "l0_entry": "pack --general", "root": str(root)}


def best_section(root, relative, query, ceiling):
    """Pick one complete heading section that fits; never cut inside a paragraph."""
    text = resolve_memory(root, relative).read_text(encoding="utf-8")
    lines = body(text).splitlines()
    starts = [(index, line) for index, line in enumerate(lines)
              if re.match(r"^#{1,6} ", line)]
    if not starts:
        return None
    terms = set(query_terms(query))
    best = None
    for position, (start, heading) in enumerate(starts):
        end = starts[position + 1][0] if position + 1 < len(starts) else len(lines)
        chunk = "\n".join(lines[start:end]).strip()
        if len(chunk) > ceiling:
            continue
        score = sum(1 for term in terms if term in chunk)
        if best is None or score > best[0]:
            best = (score, re.sub(r"^#+ ", "", heading))
    return best[1] if best else None


def section_selectors(root, paths, query, ceiling, as_of=None, include_history=False):
    """Keep BM25 order; shrink only whole documents above the per-candidate ceiling."""
    plan = {}
    for relative in paths:
        if select(root, relative, as_of, include_history)["chars"] <= ceiling:
            continue
        heading = best_section(root, relative, query, ceiling)
        if heading:
            plan[relative] = f"{relative}#{heading}"
    return plan


def cue_block(root, skipped):
    """Compress skipped candidates into bounded navigation cues, not memory text."""
    lines = []
    used = len(CUE_HEADER) + 1
    omitted = 0
    for row in skipped:
        selector = row["selector"].split("#")[0]
        meta = metadata(resolve_memory(root, selector).read_text(encoding="utf-8"))
        line = f"- {selector} | {meta.get('title', '')} | {meta.get('description', '')}"
        if used + len(line) + 1 > CUE_LINE_BUDGET:
            omitted += 1
            continue
        lines.append(line)
        used += len(line) + 1
    block = CUE_HEADER + "\n" + "\n".join(lines) if lines else ""
    return {"block": block, "chars": len(block), "listed": len(lines),
            "omitted": omitted}


def bm25_candidates(root, query, as_of=None, include_history=False):
    records = [record for record in active_files(root, as_of, include_history)
               if include_history or record["path"] != HISTORY_PATH]
    terms = list(dict.fromkeys(query_terms(query)))
    if not terms or not records:
        return []
    documents = []
    frequencies = {}
    for record in records:
        meta = record["meta"]
        cues = " ".join(meta.get(key, "") for key in
                        ("title", "description", "tags", "entities", "topic"))
        tokens = query_terms(f"{cues} {cues} {cues} {record['body']}")
        counts = {term: tokens.count(term) for term in terms}
        documents.append((record, len(tokens), counts))
        for term in terms:
            frequencies[term] = frequencies.get(term, 0) + int(counts[term] > 0)
    average_length = sum(row[1] for row in documents) / max(1, len(documents))
    ranked = []
    for record, length, counts in documents:
        score = 0.0
        for term in terms:
            frequency = counts[term]
            if not frequency:
                continue
            inverse = math.log(1 + (len(documents) - frequencies[term] + 0.5) /
                               (frequencies[term] + 0.5))
            denominator = frequency + 1.5 * (1 - 0.75 + 0.75 * length / max(1, average_length))
            score += inverse * frequency * 2.5 / denominator
        if score > 0:
            ranked.append({"path": record["path"], "score": round(score, 6)})
    weight_order = {"W1": 0, "W2": 1, "W3": 2, "W4": 3, "W5": 4}
    ranked.sort(key=lambda row: (-row["score"], weight_order[weight(row["path"])], row["path"]))
    return ranked


def compile_context(root, query, selectors=(), required=(), session="", budget=LIMIT,
                    as_of=None, include_history=False, notes_path=None, top_k=None,
                    tier=None):
    if not query.strip():
        raise ValueError("compile requires a non-empty query")
    if not 1 <= budget <= LIMIT:
        raise ValueError("budget must be between 1 and 8000 characters")
    if top_k is not None and not 1 <= top_k <= MAX_FILES:
        raise ValueError(f"top_k must be between 1 and {MAX_FILES}")
    resolved_tier = route_tier(query, tier)
    depth = retrieval_depth(query)
    limit = top_k or (5 if depth == "high" else 3)
    candidates = bm25_candidates(root, query, as_of, include_history)
    explicit = {selector.split("#")[0] for selector in list(selectors) + list(required)}
    eligible = [row for row in candidates if row["path"] not in explicit]
    selected_candidates = eligible[:limit]
    automatic = [row["path"] for row in selected_candidates]
    notes = "无任务 Notes；仅按当前 query 与长期记忆组包。"
    resolved_notes = None
    if notes_path:
        resolved_notes = Path(notes_path).expanduser().resolve()
        if not resolved_notes.is_file():
            raise ValueError("notes file does not exist")
        notes = resolved_notes.read_text(encoding="utf-8").strip()
    prefix = f"[CONTEXT current_query]\n{query.strip()}\n\n[CONTEXT working_state]\n{notes}"
    fallback = ("[CONTEXT evidence_and_fallback]\n"
                "记忆按路径回源；信息不足时搜索任务 HISTORY 或原始 Trace，不用旧记忆猜测。")
    cue_reserve = CUE_LINE_BUDGET + 2 if resolved_tier == "L2" else 0
    memory_budget = budget - len(prefix) - len(fallback) - cue_reserve - 4
    if memory_budget < 1:
        raise ValueError("query and notes exceed the total context budget")
    automatic_selectors = automatic
    sections = {}
    if resolved_tier == "L2":
        slots = max(1, len(automatic) + len(required) + len(selectors))
        ceiling = max(SECTION_FLOOR, memory_budget // slots)
        sections = section_selectors(root, automatic, query, ceiling, as_of, include_history)
        automatic_selectors = [sections.get(path, path) for path in automatic]
    memory = packet(root, list(selectors) + automatic_selectors, required, session, False,
                    memory_budget, as_of, include_history, ranked=True)
    cue = {"block": "", "chars": 0, "listed": 0, "omitted": 0}
    if resolved_tier == "L2" and memory["skipped"]:
        cue = cue_block(root, memory["skipped"])
    suffix = fallback + ("\n" + cue["block"] if cue["block"] else "")
    context = prefix + "\n\n" + memory["context"] + "\n\n" + suffix
    if len(context) > budget:
        raise ValueError("compiled context exceeds hard limit")
    receipt = {**memory["receipt"], "mode": "context_compiler", "query": query.strip(),
               "explicit_selectors": list(selectors), "required": list(required),
               "notes_path": str(resolved_notes) if resolved_notes else None,
               "top_k": top_k, "depth": depth, "budget": budget,
               "route_tier": resolved_tier, "cue_chars": cue["chars"],
               "skipped_cues": {"listed": cue["listed"], "omitted": cue["omitted"]},
               "sections": sections,
               "memory_budget": memory_budget, "chars": len(context),
               "context_sha256": digest(context)}
    return {"context": context, "chars": len(context), "budget": budget,
            "skipped": memory["skipped"],
            "retrieval_plan": {"depth": depth, "limit": limit,
                               "candidates": selected_candidates, "automatic": automatic,
                               "sections": sections},
            "receipt": receipt}


def acknowledge(root, data):
    receipt = data["receipt"]
    as_of = dt.date.fromisoformat(receipt.get("as_of", str(dt.date.today())))
    include_history = receipt.get("include_history", False)
    if not isinstance(include_history, bool):
        raise ValueError("include_history must be boolean")
    expected_items = [select(root, r["selector"], as_of, include_history)
                      for r in receipt["items"]]
    if receipt.get("mode") == "context_compiler":
        rebuilt = compile_context(root, receipt["query"], receipt["explicit_selectors"],
                                  receipt["required"], receipt["session"], receipt["budget"],
                                  as_of, include_history, receipt["notes_path"], receipt["top_k"],
                                  receipt.get("route_tier"))
        context = rebuilt["context"]
    else:
        context = "\n\n".join(f"[MEMORY {r['selector']}]\n{r['content']}" for r in expected_items)
    if digest(context) != receipt["context_sha256"] or len(context) != receipt["chars"]:
        raise ValueError("packet changed since read; regenerate and read again")
    if receipt["chars"] > LIMIT:
        raise ValueError("packet exceeds hard limit")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", receipt["session"]):
        raise ValueError("invalid session")
    if dt.datetime.fromisoformat(receipt["created_at"]).date() != dt.date.today():
        raise ValueError("receipt is not from today")
    # Receipt proves content identity, not that a host truly read it. Host must acknowledge after reading.
    with locked(root):
        path = root / "ACCESS_LOG.md"
        if not path.exists():
            path.write_text(ACCESS_HEADER, encoding="utf-8")
        existing = {(r["session"], r["path"]) for r in access_rows(root)}
        written = []
        grouped = {}
        for row in expected_items:
            grouped.setdefault(row["path"], []).append(row)
        with path.open("a", encoding="utf-8") as stream:
            for relative, rows in grouped.items():
                if (receipt["session"], relative) in existing:
                    continue
                chars = sum(r["chars"] for r in rows)
                sha = digest("\n".join(r["sha256"] for r in rows))
                stream.write(f"| {dt.date.today()} | {receipt['session']} | {relative} | {chars} | {sha} |\n")
                written.append(relative)
        return {"recorded": written, "duplicate_session_paths_ignored": len(grouped) - len(written)}


def active_files(root, as_of=None, include_history=False):
    """Second-level memories in the current view, or all records for explicit history."""
    day = as_of or dt.date.today()
    files = []
    for top in list(LAYERS) + ["knowledge"]:
        folder = root / top
        if not folder.is_dir():
            continue
        for path in sorted(folder.glob("*/*.md")):
            text = path.read_text(encoding="utf-8")
            meta = metadata(text)
            if not include_history and not is_current(meta, day):
                continue
            files.append({"path": str(path.relative_to(root)), "meta": meta, "body": body(text)})
    return files


def parse_tags(value):
    return [tag.strip() for tag in str(value).strip().strip("[]").split(",") if tag.strip()]


def cue_report(root, as_of=None, target=None, files=None):
    """Encoding specificity: description/tags are retrieval cues, not decorative metadata."""
    files = active_files(root, as_of) if files is None else files
    if target and not any(record["path"] == target for record in files):
        raise ValueError(f"target is not an active memory file: {target}")
    items = []
    for record in files:
        if target and record["path"] != target:
            continue
        meta = record["meta"]
        description, title = meta.get("description", ""), meta.get("title", "")
        tags = parse_tags(meta.get("tags", ""))
        issues = []
        if len(description) < 12:
            issues.append("description_too_short")
        if description and description == title:
            issues.append("description_duplicates_title")
        if not any(marker in description for marker in CUE_MARKERS):
            issues.append("no_retrieval_scenario_marker")
        if not tags:
            issues.append("no_cue_tags")
        elif len(tags) < 2:
            issues.append("too_few_cues")
        if tags and not any(tag not in GENERIC_CUES for tag in tags):
            issues.append("only_generic_cues")
        items.append({"path": record["path"], "title": title, "description": description,
                      "tags": tags, "status": "cue_ok" if not issues else "cue_review",
                      "issues": issues})
    review = [row for row in items if row["status"] == "cue_review"]
    return {"action": "report_only_no_auto_rewrite", "scanned": len(items),
            "cue_ok": len(items) - len(review), "cue_review_count": len(review),
            "cue_review": review, "items": items,
            "cue_contract": "写前先回答未来会被怎么搜到：把任务信号、项目别名、口径名写进 description 与 tags；机检只查最小约束，语义质量由 Agent 和本人确认"}


def strength_index(root, as_of=None, files=None):
    """Rehearsal feedback: real read receipts reinforce ranking hints, not truth or recall order."""
    day = as_of or dt.date.today()
    files = active_files(root, day) if files is None else files
    by_path = {}
    for row in access_rows(root):
        by_path.setdefault(row["path"], []).append(row)
    observed, unobserved = [], []
    for record in files:
        relative = record["path"]
        if relative.startswith(("identity/", "principles/", "preferences/")):
            continue
        rows = by_path.get(relative, [])
        if not rows:
            unobserved.append({"path": relative, "observed": False, "hits": 0,
                               "idle_days": None, "strength_hint": None,
                               "note": "no_observation_not_stale"})
            continue
        try:
            modified = dt.date.fromisoformat(record["meta"].get("timestamp", ""))
        except ValueError:
            modified = day
        last = max(dt.date.fromisoformat(row["date"]) for row in rows)
        hits = len({row["session"] for row in rows})
        idle = max(0, (day - max(last, modified)).days)
        strength = (1 + math.log(max(1, hits))) * math.exp(-idle / 180)
        observed.append({"path": relative, "observed": True, "hits": hits,
                         "last_accessed": str(last), "idle_days": idle,
                         "strength_hint": round(strength, 4)})
    return {"as_of": str(day),
            "ranking": sorted(observed, key=lambda row: (-row["strength_hint"], row["path"])),
            "unobserved": [row["path"] for row in unobserved],
            "protected_layers_excluded": "W1/W2",
            "formula": "(1+ln(命中会话数))×exp(-闲置天数/180)",
            "note": "命中反哺只影响体检排序提示，不参与 pack 的召回选择顺序；用得多不代表事实正确"}


def health(root, as_of=None, idle_days=90):
    day = as_of or dt.date.today()
    by_path = {}
    for row in access_rows(root):
        by_path.setdefault(row["path"], []).append(row)
    report = {"as_of": str(day), "idle_threshold": idle_days, "idle_review": [],
              "unobserved": [], "freshness_review": [], "protected_files": 0,
              "action": "report_only_no_archiving_or_deletion"}
    for top in list(LAYERS) + ["knowledge"]:
        for path in sorted((root / top).glob("*/*.md")):
            meta = metadata(path.read_text(encoding="utf-8"))
            if not is_current(meta, day):
                continue
            relative = str(path.relative_to(root))
            if top in {"identity", "principles", "preferences"}:
                report["protected_files"] += 1
                continue
            modified = dt.date.fromisoformat(meta["timestamp"])
            rows = by_path.get(relative, [])
            last = max((dt.date.fromisoformat(r["date"]) for r in rows), default=None)
            if last is None:
                report["unobserved"].append({"path": relative, "status": "no_observation_not_stale"})
            else:
                # A newly revised file has not been idle since its old access date.
                idle = max(0, (day - max(last, modified)).days)
                count = len({r["session"] for r in rows})
                strength = (1 + math.log(max(1, count))) * math.exp(-idle / 180)
                if idle >= idle_days:
                    report["idle_review"].append({"path": relative, "idle_days": idle,
                        "last_accessed": str(last), "sessions": count,
                        "strength_hint": round(strength, 4), "decision": "needs_user_review"})
            if top == "context" and (day - modified).days >= idle_days:
                report["freshness_review"].append({"path": relative, "timestamp": str(modified),
                    "reason": "old_context_may_be_stale_even_if_recently_read"})
    report["monthly_auto_write_sample"] = auto_write_sample(root, day)
    current = active_files(root, day)
    cues = cue_report(root, day, files=current)
    distilled = distill_report(root, day, files=current)
    forgetting = forget_report(root, day, idle_days, include_similarity=False, files=current)
    strengths = strength_index(root, day, files=current)
    report["cue_review"] = {"needs_review": cues["cue_review_count"],
                            "sample": [row["path"] for row in cues["cue_review"][:5]],
                            "detail_command": "python tools/memory_runtime.py cue"}
    report["distill_review"] = {"candidates": distilled["total_candidates"],
                                "reviewed": distilled["reviewed_candidates"],
                                "unreviewed": distilled["unreviewed_candidates"],
                                "sample": [row["source_paths"] for row in distilled["candidates"][:3]],
                                "detail_command": "python tools/memory_runtime.py distill",
                                "unreviewed_command": "python tools/memory_runtime.py distill --only-unreviewed"}
    report["forget_review"] = {
        "compression_candidates": len(forgetting["compression_candidates"]),
        "detail_command": "python tools/memory_runtime.py forget"}
    report["strength_ranking"] = strengths["ranking"][:5]
    report["outcome_review"] = outcome_summary(root)
    return report


def distill_report(root, as_of=None, min_events=3, min_shared=2, limit=20, files=None,
                   only_unreviewed=False):
    """Episodic -> semantic candidates, annotated with prior decisions; never auto-writes."""
    if min_events < 1 or min_shared < 1 or limit < 1:
        raise ValueError("distill thresholds and limit must be positive")
    current = active_files(root, as_of) if files is None else files
    files = [record for record in current
             if record["path"].startswith(("context/", "knowledge/experiences/"))
             and record["path"] != HISTORY_PATH]
    candidates = []
    for record in files:
        dated = [line.strip() for line in record["body"].splitlines() if DATE_LINE.search(line)]
        if len(dated) >= min_events:
            candidates.append({
                "kind": "episodic_to_semantic", "source_paths": [record["path"]],
                "event_lines": len(dated), "shared_cues": [],
                "candidate_id": candidate_fingerprint("episodic_to_semantic",
                                                      [record["path"]], []),
                "suggested_target": "knowledge/skills/ 或 principles/（需小毕确认）",
                "reason": "同一文件含多条带日期事件，建议抽象成无时间绑定的方法或判断原则",
                "keep_source_link": True})
    groups = {}
    for record in files:
        tags = sorted(set(parse_tags(record["meta"].get("tags", ""))) - GENERIC_CUES)
        if len(tags) >= min_shared:
            for combo in itertools.combinations(tags, min_shared):
                groups.setdefault(combo, set()).add(record["path"])
    for combo, paths in sorted(groups.items()):
        if len(paths) >= 2:
            source_paths = sorted(paths)
            shared_cues = list(combo)
            candidates.append({
                "kind": "cross_file_theme", "source_paths": source_paths,
                "event_lines": None, "shared_cues": shared_cues,
                "candidate_id": candidate_fingerprint("cross_file_theme",
                                                      source_paths, shared_cues),
                "suggested_target": "合并到同一主题文件，或抽象成 knowledge/skills/ 方法（需小毕确认）",
                "reason": "多个当前文件共享同一组召回线索，可能存在可合并的重复叙述",
                "keep_source_link": True})
    candidates.sort(key=lambda row: (row["kind"] != "episodic_to_semantic",
                                     -(row["event_lines"] or 0), row["source_paths"]))
    ledger = {row["candidate_id"]: row for row in distill_decision_rows(root)}
    for row in candidates:
        record = ledger.get(row["candidate_id"])
        row["decision"] = record["decision"] if record else None
        row["reviewed_at"] = record["at"] if record else None
    reviewed = sum(1 for row in candidates if row["decision"])
    returned = ([row for row in candidates if row["decision"] is None]
                if only_unreviewed else candidates)
    return {"action": "report_only_no_auto_rewrite", "scanned": len(files),
            "min_events": min_events, "min_shared": min_shared,
            "total_candidates": len(candidates), "reviewed_candidates": reviewed,
            "unreviewed_candidates": len(candidates) - reviewed,
            "returned_candidates": len(returned[:limit]),
            "only_unreviewed": only_unreviewed, "candidates": returned[:limit],
            "note": "默认列出全部候选，已审只是标注不算删除；需要干净候选集用 --only-unreviewed 显式过滤。升方法/原则或合并文件都需小毕确认，变更日志不参与蒸馏"}


DISTILL_DECISIONS = frozenset({"accept", "reject"})
DISTILL_DECISION_FILE = "tools/distill_decisions.jsonl"
CANDIDATE_ID_PATTERN = re.compile(r"[0-9a-f]{" + str(ID_SHORT_LENGTH) + r"}")


def candidate_fingerprint(kind, source_paths, shared_cues):
    """Stable candidate identity shared by the report and the reviewable bundle."""
    return digest(json.dumps([kind, source_paths, shared_cues],
                             ensure_ascii=False, sort_keys=True))[:ID_SHORT_LENGTH]


def distill_decision_rows(root):
    path = root / DISTILL_DECISION_FILE
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def record_distill_decision(root, candidate_id, decision, version_id):
    """Append-only in-repo ledger; idempotent on (candidate_id, version_id)."""
    if not isinstance(candidate_id, str) or not CANDIDATE_ID_PATTERN.fullmatch(candidate_id):
        raise ValueError("candidate_id must be a hex fingerprint")
    if decision not in DISTILL_DECISIONS:
        raise ValueError("decision must be accept or reject")
    rows = distill_decision_rows(root)
    if any(row.get("candidate_id") == candidate_id and
           row.get("version_id") == version_id for row in rows):
        return {"action": "duplicate_no_write", "candidate_id": candidate_id}
    entry = {"at": now(), "candidate_id": candidate_id, "decision": decision,
             "version_id": version_id}
    with locked(root):
        with (root / DISTILL_DECISION_FILE).open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return {"action": "append_only_decision_ledger", "path": DISTILL_DECISION_FILE,
            "record": entry}


def sync_bundle_decisions(root, bundle):
    """Idempotently mirror existing bundle decisions into the ledger; fix reviewed status."""
    valid_bundle(bundle)
    written = 0
    for row in bundle.get("decisions", []):
        result = record_distill_decision(root, row["candidate_id"], row["decision"],
                                         bundle.get("version_id"))
        written += int(result["action"] == "append_only_decision_ledger")
    if bundle.get("decisions") and len(bundle["decisions"]) == len(bundle["candidates"]):
        bundle["status"] = "reviewed"
    return {"action": "sync_only_no_memory_write", "version_id": bundle.get("version_id"),
            "ledger_written": written, "ledger_total": len(distill_decision_rows(root)),
            "bundle_status": bundle.get("status"),
            "note": "台账只存指纹、决定、版本与时间；不存正文或用户问题；不改写记忆正文"}


def distill_bundle(root, as_of=None, min_events=3, min_shared=2, limit=20):
    """Out-of-band reviewable version pack: inputs stay untouched, no generated summary."""
    report = distill_report(root, as_of, min_events, min_shared, limit)
    items = []
    for row in report["candidates"]:
        sources = {path: digest(resolve_memory(root, path).read_text(encoding="utf-8"))
                   for path in row["source_paths"]}
        candidate = {key: value for key, value in row.items() if key != "keep_source_link"}
        candidate["candidate_id"] = candidate_fingerprint(
            row["kind"], row["source_paths"], row.get("shared_cues"))
        candidate["source_sha256"] = sources
        candidate["evidence_hash"] = digest(json.dumps(sources, ensure_ascii=False,
                                                       sort_keys=True))
        candidate["status"] = candidate.get("decision") or "pending"
        candidate["proposed_content"] = None
        items.append(candidate)
    day = as_of or dt.date.today()
    version = digest(json.dumps([item["candidate_id"] for item in items],
                                ensure_ascii=False, sort_keys=True))[:VERSION_SHORT_LENGTH]
    return {"action": "auditable_distill_bundle_no_memory_write",
            "version_id": f"distill-{day}-{version}", "created_at": now(),
            "as_of": str(day), "status": "pending", "candidates": items,
            "decisions": [],
            "source_of_truth": "personal-memory active files; this bundle lives outside the repo",
            "boundary": "输入记忆正文只读；不自动生成归纳内容；accept 不等于写入，沉淀仍按 README 第 7 节由小毕确认"}


def valid_bundle(bundle):
    if not isinstance(bundle, dict) or not isinstance(bundle.get("candidates"), list):
        raise ValueError("bundle must be an object with a candidates list")
    if not isinstance(bundle.get("decisions", []), list):
        raise ValueError("bundle decisions must be a list")
    return bundle


def distill_verify(root, bundle):
    """Read-only evidence re-check; changed sources invalidate the bundle."""
    valid_bundle(bundle)
    checks = []
    for candidate in bundle.get("candidates", []):
        for path, expected in candidate.get("source_sha256", {}).items():
            try:
                actual = digest(resolve_memory(root, path).read_text(encoding="utf-8"))
            except (OSError, ValueError):
                actual = None
            checks.append({"candidate_id": candidate.get("candidate_id"), "path": path,
                           "evidence_valid": actual == expected})
    stale = [row for row in checks if not row["evidence_valid"]]
    return {"action": "verify_only_no_write", "version_id": bundle.get("version_id"),
            "evidence_checked": len(checks), "evidence_valid": len(checks) - len(stale),
            "stale": stale, "status": bundle.get("status"),
            "decisions": bundle.get("decisions", []),
            "note": "源正文变化会使证据哈希失效，须重新生成版本包；校验不改写记忆或版本包"}


def distill_decide(root, bundle, candidate_id, decision, note=""):
    """Append one decision to the bundle and mirror it into the in-repo ledger."""
    valid_bundle(bundle)
    if decision not in DISTILL_DECISIONS:
        raise ValueError("decision must be accept or reject")
    if not any(row["candidate_id"] == candidate_id for row in bundle.get("candidates", [])):
        raise ValueError("candidate_id is not in this bundle")
    decisions = bundle.setdefault("decisions", [])
    if any(row["candidate_id"] == candidate_id for row in decisions):
        raise ValueError("candidate already decided; regenerate the bundle to reconsider")
    decisions.append({"candidate_id": candidate_id, "decision": decision,
                      "at": now(), "note": note})
    for candidate in bundle["candidates"]:
        if candidate["candidate_id"] == candidate_id:
            candidate["status"] = decision
    bundle["reviewed"] = len(decisions)
    if len(decisions) == len(bundle["candidates"]):
        bundle["status"] = "reviewed"
    ledger = record_distill_decision(root, candidate_id, decision, bundle.get("version_id"))
    return {"action": "append_only_bundle_decision_no_memory_write",
            "version_id": bundle.get("version_id"), "decision": decisions[-1],
            "reviewed": len(decisions), "remaining": len(bundle["candidates"]) - len(decisions),
            "bundle_status": bundle["status"], "ledger_action": ledger["action"],
            "ledger_path": DISTILL_DECISION_FILE,
            "note": "决定落在版本包与库内台账；台账供 distill 标注已审；真正沉淀按 README 第 7 节单独确认与提交"}


def shingles(text, size=3):
    flat = re.sub(r"\s+", "", text)
    return {flat[i:i + size] for i in range(max(0, len(flat) - size + 1))} if flat else set()


def forget_report(root, as_of=None, idle_days=90, similarity=0.8,
                  strength_floor=0.6, include_similarity=True, limit=20, files=None):
    """Active forgetting = compression + deduplication candidates, never silent deletion."""
    if not 0 < similarity <= 1 or limit < 1:
        raise ValueError("similarity must be within (0, 1] and limit positive")
    day = as_of or dt.date.today()
    current = active_files(root, day) if files is None else files
    files = [record for record in current if record["path"] != HISTORY_PATH]
    sizes = {record["path"]: len(record["body"]) for record in files}
    compression = []
    for row in strength_index(root, day, files=files)["ranking"]:
        if row["idle_days"] >= idle_days and row["strength_hint"] < strength_floor:
            compression.append({**row, "chars": sizes.get(row["path"], 0),
                                "suggested_action": "summarize_in_place_keep_source_link_never_delete"})
    near_duplicates = []
    if include_similarity:
        prepared = [(record["path"], len(record["body"]), shingles(record["body"]))
                    for record in files]
        for (path_a, len_a, set_a), (path_b, len_b, set_b) in itertools.combinations(prepared, 2):
            if not set_a or not set_b:
                continue
            if min(len_a, len_b) / max(len_a, len_b) < 0.7:
                continue
            score = len(set_a & set_b) / len(set_a | set_b)
            if score >= similarity:
                near_duplicates.append({"path_a": path_a, "path_b": path_b,
                                        "similarity": round(score, 4),
                                        "suggested_action": "merge_keep_one_source_of_truth_confirm_first"})
        near_duplicates.sort(key=lambda row: (-row["similarity"], row["path_a"], row["path_b"]))
    return {"action": "report_only_no_deletion_or_merging", "as_of": str(day),
            "idle_days": idle_days, "strength_floor": strength_floor,
            "compression_candidates": compression[:limit],
            "near_duplicates": near_duplicates[:limit],
            "near_duplicate_detection": "included" if include_similarity else "skipped_use_forget_command",
            "note": "压缩与合并都只列候选，不删除、不归档、不改写正文；变更日志不参与，W1/W2 不做闲置压缩"}


def auto_write_sample(root, as_of=None):
    audit = root / "tools" / "write_audit.jsonl"
    if not audit.exists():
        return []
    entries = [json.loads(s) for s in audit.read_text(encoding="utf-8").splitlines() if s.strip()]
    day = as_of or dt.date.today()
    entries = [e for e in entries if e.get("decision") == "auto_append" and
               e.get("stage") == "applied" and
               0 <= (day - dt.datetime.fromisoformat(e["at"]).date()).days <= 30]
    if not entries:
        return []
    # Deterministic sample: ceil(20%), minimum 1. Very small monthly batches are fully reviewed.
    entries = sorted(entries, key=lambda e: digest(e["id"]))
    n = len(entries) if len(entries) <= 5 else math.ceil(len(entries) * .2)
    return [{"id": e["id"], "target": e["target"], "source_locator": e["source_locator"],
             "source_quote": e["source_quote"]} for e in entries[:n]]


def contains_quote(text, quote):
    if quote.strip() in body(text):
        return True
    for line in body(text).splitlines():
        if line.startswith("原文："):
            try:
                if json.loads(line[len("原文："):]) == quote:
                    return True
            except (ValueError, TypeError):
                continue
    return False


def validate_candidate(root, candidate):
    needed = ["id", "kind", "target", "subject", "text", "source_kind", "source_locator",
              "source_quote", "evidence_text", "evidence_sha256", "novelty_checked", "conflict_checked"]
    missing = [k for k in needed if k not in candidate]
    if missing:
        raise ValueError(f"missing candidate fields: {missing}")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", candidate["id"]):
        raise ValueError("candidate id requires an ASCII identifier")
    quote, evidence = candidate["source_quote"], candidate["evidence_text"]
    if not isinstance(quote, str) or not quote.strip() or quote not in evidence:
        raise ValueError("source quote must occur verbatim in evidence")
    if digest(evidence) != candidate["evidence_sha256"]:
        raise ValueError("evidence hash mismatch")
    if candidate["source_kind"] not in {"user_message", "verified_document"}:
        raise ValueError("assistant summaries are not evidence")
    if not candidate["source_locator"] or not candidate["subject"] or not candidate["text"].strip():
        raise ValueError("source, subject and statement must be explicit")
    target = candidate["target"]
    path = resolve_memory(root, target)
    text = path.read_text(encoding="utf-8")
    if not is_current(metadata(text), dt.date.today()):
        raise ValueError("target is not active and current")
    if candidate["novelty_checked"] is not True or candidate["conflict_checked"] is not True:
        return "needs_decision"
    # Narrow allow-list. Clear quotation alone does not authorize replacement or inference.
    permitted = target.startswith(("context/projects/", "context/relationships/"))
    if candidate["kind"] != "fact_add" or not permitted:
        return "needs_decision"
    if candidate["text"] != quote:
        return "needs_decision"  # only verbatim additive statements can be auto-written
    if contains_quote(text, quote):
        return "duplicate_no_write"
    return "auto_append"


def audit_candidate(root, candidate):
    decision = validate_candidate(root, candidate)
    row = {**candidate, "decision": decision, "stage": "proposed", "at": now()}
    with locked(root):
        with (root / "tools" / "write_audit.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    return {"id": candidate["id"], "decision": decision,
            "note": "evidence persisted; semantic conflict checks remain an agent responsibility"}


def atomic_write(path, text):
    fd, name = tempfile.mkstemp(prefix=".memory-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def apply_auto(root, candidate):
    # Source audit is durable before touching authoritative memory.
    result = audit_candidate(root, candidate)
    if result["decision"] != "auto_append":
        return result
    with locked(root):
        path = resolve_memory(root, candidate["target"])
        text = path.read_text(encoding="utf-8")
        if contains_quote(text, candidate["source_quote"]):
            return {"id": candidate["id"], "decision": "duplicate_no_write"}
        text = re.sub(r"(?m)^timestamp: .*?$", f"timestamp: {dt.date.today()}", text, count=1)
        # JSON string encoding keeps embedded newlines and Markdown headings from altering the file structure.
        quoted = json.dumps(candidate["source_quote"], ensure_ascii=False)
        locator = json.dumps(candidate["source_locator"], ensure_ascii=False)
        text = text.rstrip() + f"\n\n### 证据增补 {candidate['id']}\n\n原文：{quoted}\n来源：{locator}\n"
        atomic_write(path, text)
        if path.read_text(encoding="utf-8") != text:
            raise ValueError("read-back mismatch")
        applied = {**candidate, "decision": "auto_append", "stage": "applied", "at": now(),
                   "after_sha256": digest(text)}
        with (root / "tools" / "write_audit.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(applied, ensure_ascii=False) + "\n")
    return {"id": candidate["id"], "decision": "auto_append", "applied": True,
            "next": "rebuild_index_then_commit_only_this_change_and_push"}


def validate_replacement(root, candidate):
    needed = ["id", "target", "subject", "old_text", "new_text", "source_kind",
              "source_locator", "source_quote", "evidence_text", "evidence_sha256",
              "confirmed"]
    missing = [key for key in needed if key not in candidate]
    if missing:
        raise ValueError(f"missing replacement fields: {missing}")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", candidate["id"]):
        raise ValueError("replacement id requires an ASCII identifier")
    if candidate["confirmed"] is not True:
        raise ValueError("replacement requires explicit user confirmation")
    quote, evidence = candidate["source_quote"], candidate["evidence_text"]
    if not isinstance(quote, str) or not quote.strip() or quote not in evidence:
        raise ValueError("source quote must occur verbatim in evidence")
    if digest(evidence) != candidate["evidence_sha256"]:
        raise ValueError("evidence hash mismatch")
    if candidate["source_kind"] not in {"user_message", "verified_document"}:
        raise ValueError("assistant summaries are not evidence")
    old_text, new_text = candidate["old_text"], candidate["new_text"]
    if not old_text or not new_text or old_text == new_text or old_text in new_text:
        raise ValueError("old and new text must be non-empty, distinct and non-nested")
    if new_text not in quote or not candidate["subject"] or not candidate["source_locator"]:
        raise ValueError("new text, subject and source must be explicit")
    if candidate.get("effective_date"):
        dt.date.fromisoformat(candidate["effective_date"])
    target = resolve_memory(root, candidate["target"])
    history = resolve_memory(root, HISTORY_PATH)
    for path in (target, history):
        text = path.read_text(encoding="utf-8")
        if not is_current(metadata(text), dt.date.today()):
            raise ValueError(f"replacement target is not active and current: {path.name}")
    return target, history


def table_text(value):
    return str(value).replace("|", "\\|").replace("\n", " ").strip()


def replacement_history_entry(candidate):
    day = candidate.get("effective_date", str(dt.date.today()))
    source = f"{day}；{candidate['id']}；{candidate['source_locator']}"
    values = [candidate["subject"], candidate["old_text"], candidate["new_text"], source]
    return "| " + " | ".join(table_text(value) for value in values) + " |"


def replacement_residuals(root, old_text):
    matches = []
    for top in list(LAYERS) + ["knowledge"]:
        for path in sorted((root / top).glob("*/*.md")):
            relative = str(path.relative_to(root))
            if relative == HISTORY_PATH:
                continue
            text = path.read_text(encoding="utf-8")
            if not is_current(metadata(text), dt.date.today()):
                continue
            for number, line in enumerate(body(text).splitlines(), 1):
                if old_text in line:
                    matches.append({"path": relative, "body_line": number, "text": line.strip()})
    return matches


def apply_replacement(root, candidate):
    target, history = validate_replacement(root, candidate)
    with locked(root):
        target, history = validate_replacement(root, candidate)
        original_target = target.read_text(encoding="utf-8")
        original_history = history.read_text(encoding="utf-8")
        entry = replacement_history_entry(candidate)
        old_count = body(original_target).count(candidate["old_text"])
        if old_count == 0 and candidate["new_text"] in original_target and entry in original_history:
            return {"id": candidate["id"], "decision": "duplicate_no_write", "applied": False}
        if old_count != 1:
            raise ValueError("old text must occur exactly once in the target body")
        proposed = {**candidate, "decision": "confirmed_replace", "stage": "proposed", "at": now()}
        with (root / "tools" / "write_audit.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(proposed, ensure_ascii=False) + "\n")
        new_target = original_target.replace(candidate["old_text"], candidate["new_text"], 1)
        new_target = re.sub(r"(?m)^timestamp: .*?$", f"timestamp: {dt.date.today()}",
                            new_target, count=1)
        new_history = re.sub(r"(?m)^timestamp: .*?$", f"timestamp: {dt.date.today()}",
                             original_history, count=1)
        new_history = new_history.rstrip() + "\n" + entry + "\n"
        try:
            atomic_write(target, new_target)
            if target.read_text(encoding="utf-8") != new_target:
                raise ValueError("target read-back mismatch")
            atomic_write(history, new_history)
            if history.read_text(encoding="utf-8") != new_history:
                raise ValueError("history read-back mismatch")
        except (OSError, ValueError):
            atomic_write(target, original_target)
            atomic_write(history, original_history)
            raise
        residuals = replacement_residuals(root, candidate["old_text"])
        applied = {**candidate, "decision": "confirmed_replace", "stage": "applied",
                   "at": now(), "target_after_sha256": digest(new_target),
                   "history_after_sha256": digest(new_history), "residuals": residuals}
        with (root / "tools" / "write_audit.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(applied, ensure_ascii=False) + "\n")
    return {"id": candidate["id"], "decision": "confirmed_replace", "applied": True,
            "residuals": residuals, "residual_review_required": bool(residuals),
            "next": "review residuals, rebuild index, then commit only confirmed changes"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(Path.home() / "personal-memory"))
    commands = parser.add_subparsers(dest="command", required=True)
    pack = commands.add_parser("pack")
    pack.add_argument("--select", action="append", default=[])
    pack.add_argument("--required", action="append", default=[])
    pack.add_argument("--session", required=True)
    pack.add_argument("--general", action="store_true")
    pack.add_argument("--budget", type=int, default=LIMIT)
    pack.add_argument("--as-of", type=dt.date.fromisoformat, help="Current-view date; default today")
    pack.add_argument("--include-history", action="store_true",
                      help="Explicitly allow superseded, expired, archived and future records")
    pack.add_argument("--out", help="Optional packet JSON, outside the memory directories")
    compiler = commands.add_parser("compile", help="Compile query, working notes and recalled memory")
    compiler.add_argument("--query", required=True)
    compiler.add_argument("--select", action="append", default=[])
    compiler.add_argument("--required", action="append", default=[])
    compiler.add_argument("--session", required=True)
    compiler.add_argument("--budget", type=int, default=LIMIT)
    compiler.add_argument("--as-of", type=dt.date.fromisoformat)
    compiler.add_argument("--include-history", action="store_true")
    compiler.add_argument("--notes", help="Optional task NOTES.md path")
    compiler.add_argument("--top-k", type=int)
    compiler.add_argument("--tier", choices=("auto", "L1", "L2"), default="auto",
                          help="Runtime memory budget; auto picks L1 or L2 from query markers")
    compiler.add_argument("--out", help="Optional compiled packet JSON, outside the memory directories")
    router = commands.add_parser("route", help="Read-only query-aware tier plan")
    router.add_argument("--query", required=True)
    ack = commands.add_parser("ack")
    ack.add_argument("--packet", required=True)
    ack.add_argument("--read-confirmed", action="store_true", required=True)
    check = commands.add_parser("health")
    check.add_argument("--as-of", type=dt.date.fromisoformat)
    check.add_argument("--idle-days", type=int, default=90)
    cue = commands.add_parser("cue", help="Encoding-cue lint; --target acts as a write gate")
    cue.add_argument("--as-of", type=dt.date.fromisoformat)
    cue.add_argument("--target", help="Check one active memory file; exit 2 on cue_review")
    distill = commands.add_parser("distill")
    distill.add_argument("--as-of", type=dt.date.fromisoformat)
    distill.add_argument("--min-events", type=int, default=3)
    distill.add_argument("--min-shared", type=int, default=2)
    distill.add_argument("--limit", type=int, default=20)
    distill.add_argument("--only-unreviewed", action="store_true",
                         help="Explicitly hide already-decided candidates; default lists all")
    forget = commands.add_parser("forget")
    forget.add_argument("--as-of", type=dt.date.fromisoformat)
    forget.add_argument("--idle-days", type=int, default=90)
    forget.add_argument("--similarity", type=float, default=0.8)
    forget.add_argument("--strength-floor", type=float, default=0.6)
    forget.add_argument("--limit", type=int, default=20)
    strength = commands.add_parser("strength")
    strength.add_argument("--as-of", type=dt.date.fromisoformat)
    outcome = commands.add_parser("outcome", help="Append a recall-usage receipt for one real packet")
    outcome.add_argument("--packet", required=True)
    outcome.add_argument("--session", help="Optional; must match the packet receipt session")
    outcome.add_argument("--cited-in-answer", choices=sorted(OUTCOME_CITED), required=True)
    outcome.add_argument("--user-correction", choices=sorted(OUTCOME_CORRECTION), default="none")
    outcome.add_argument("--evidence", action="append", default=[])
    outcome.add_argument("--note", default="")
    outcome.add_argument("--skipped-used", choices=SKIPPED_USED,
                         help="Whether the host actually read skipped candidates; omit if unobserved")
    outcome.add_argument("--latency-ms", type=int,
                         help="Measured wall-clock milliseconds; omit if unobserved")
    commands.add_parser("outcome-summary", help="Read-only aggregate of recall-usage receipts")
    bundle = commands.add_parser("distill-pack", help="Build an out-of-band reviewable distill bundle")
    bundle.add_argument("--as-of", type=dt.date.fromisoformat)
    bundle.add_argument("--min-events", type=int, default=3)
    bundle.add_argument("--min-shared", type=int, default=2)
    bundle.add_argument("--limit", type=int, default=20)
    bundle.add_argument("--out", required=True)
    verify = commands.add_parser("distill-verify", help="Re-check bundle evidence hashes")
    verify.add_argument("--bundle", required=True)
    decide = commands.add_parser("distill-decide", help="Append one accept/reject decision")
    decide.add_argument("--bundle", required=True)
    decide.add_argument("--candidate-id", required=True)
    decide.add_argument("--decision", choices=sorted(DISTILL_DECISIONS), required=True)
    decide.add_argument("--note", default="")
    importer = commands.add_parser("distill-import",
                                   help="Idempotently mirror an existing bundle's decisions into the ledger")
    importer.add_argument("--bundle", required=True)
    for command in ("audit-write", "apply-auto", "replace-confirmed"):
        item = commands.add_parser(command)
        item.add_argument("--candidate", required=True)
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()
    try:
        if args.command == "pack":
            result = packet(root, args.select, args.required, args.session, args.general,
                            args.budget, args.as_of, args.include_history)
            if args.out:
                output = Path(args.out).resolve()
                if output.is_relative_to(root):
                    raise ValueError("packet files must live outside the authoritative memory repo")
                atomic_write(output, json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        elif args.command == "compile":
            result = compile_context(root, args.query, args.select, args.required, args.session,
                                     args.budget, args.as_of, args.include_history,
                                     args.notes, args.top_k, args.tier)
            if args.out:
                output = Path(args.out).resolve()
                if output.is_relative_to(root):
                    raise ValueError("packet files must live outside the authoritative memory repo")
                atomic_write(output, json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        elif args.command == "route":
            result = route_report(root, args.query)
        elif args.command == "ack":
            result = acknowledge(root, json.loads(Path(args.packet).read_text(encoding="utf-8")))
        elif args.command == "health":
            if args.idle_days < 1:
                raise ValueError("idle days must be positive")
            result = health(root, args.as_of, args.idle_days)
        elif args.command == "cue":
            result = cue_report(root, args.as_of, args.target)
        elif args.command == "distill":
            result = distill_report(root, args.as_of, args.min_events, args.min_shared,
                                    args.limit, only_unreviewed=args.only_unreviewed)
        elif args.command == "forget":
            if args.idle_days < 1:
                raise ValueError("idle days must be positive")
            result = forget_report(root, args.as_of, args.idle_days, args.similarity,
                                   args.strength_floor, True, args.limit)
        elif args.command == "strength":
            result = strength_index(root, args.as_of)
        elif args.command == "outcome":
            data = json.loads(Path(args.packet).read_text(encoding="utf-8"))
            result = outcome_from_packet(root, data, args.cited_in_answer,
                                         args.user_correction, args.session,
                                         args.evidence, args.note,
                                         args.skipped_used, args.latency_ms)
        elif args.command == "outcome-summary":
            result = outcome_summary(root)
        elif args.command == "distill-pack":
            result = distill_bundle(root, args.as_of, args.min_events,
                                    args.min_shared, args.limit)
            output = Path(args.out).resolve()
            if output.is_relative_to(root):
                raise ValueError("distill bundles must live outside the authoritative memory repo")
            atomic_write(output, json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        elif args.command in ("distill-verify", "distill-decide", "distill-import"):
            path = Path(args.bundle).resolve()
            if path.is_relative_to(root) or not path.is_file():
                raise ValueError("bundle must be an existing file outside the memory repo")
            data = json.loads(path.read_text(encoding="utf-8"))
            if args.command == "distill-verify":
                result = distill_verify(root, data)
            elif args.command == "distill-decide":
                result = distill_decide(root, data, args.candidate_id, args.decision, args.note)
                atomic_write(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
            else:
                result = sync_bundle_decisions(root, data)
                atomic_write(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
        else:
            candidate = json.loads(Path(args.candidate).read_text(encoding="utf-8"))
            if args.command == "replace-confirmed":
                result = apply_replacement(root, candidate)
            else:
                result = (apply_auto if args.command == "apply-auto" else audit_candidate)(root, candidate)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.command == "cue" and args.target and result["items"] and \
                result["items"][0]["status"] == "cue_review":
            sys.exit(2)  # write gate: fix description/tags before committing a new memory
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
