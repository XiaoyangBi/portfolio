#!/usr/bin/env python3
"""[INPUT]: Required frontmatter plus optional lifecycle fields in Markdown memories.
[OUTPUT]: Validated INDEX.md; errors never overwrite the previous index.
[POS]: Portable index compiler. Runtime records and tools are not memories.
[PROTOCOL]: Change this contract, then check tools/CLAUDE.md and ../CLAUDE.md.
"""
import datetime
import os
from pathlib import Path
import re
import sys
import tempfile

LAYERS = {"identity": "Identity", "principles": "Principle", "preferences": "Preference",
          "context": "Context", "knowledge": None}
KNOWLEDGE = {"skills": "Skill", "experiences": "Experience", "learnings": "Learning"}
FIELDS = ["type", "title", "description", "status", "privacy", "tags", "timestamp"]
STATUSES = {"active", "superseded", "expired", "archived"}
ATOMIC_FIELDS = ["fact_id", "entities", "topic", "salience", "source", "scope", "valid_from"]
WEIGHTS = {"identity": "W1", "principles": "W1", "preferences": "W2", "context": "W4"}


def parse(text):
    match = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not match:
        return {}
    return {k.strip(): v.strip() for line in match[1].splitlines() if ":" in line
            for k, v in [line.split(":", 1)]}


def collect(root):
    errors, rows = [], []
    for layer, expected in LAYERS.items():
        folder = root / layer
        if not folder.is_dir():
            errors.append(f"missing layer: {layer}")
            continue
        for directory, subdirs, files in os.walk(folder, followlinks=False):
            subdirs[:] = [d for d in subdirs if not d.startswith(".")]
            path = Path(directory)
            depth = len(path.relative_to(root).parts)
            if depth > 2:
                errors.append(f"third-level directory: {path.relative_to(root)}")
            for filename in sorted(files):
                if not filename.endswith(".md"):
                    continue
                file = path / filename
                relative = str(file.relative_to(root))
                if depth != 2 or file.is_symlink():
                    errors.append(f"memory must be a regular second-level file: {relative}")
                    continue
                meta = parse(file.read_text(encoding="utf-8"))
                missing = [f for f in FIELDS if not meta.get(f)]
                if missing:
                    errors.append(f"missing {missing}: {relative}")
                actual_type = KNOWLEDGE.get(path.name) if layer == "knowledge" else expected
                if not actual_type or meta.get("type") != actual_type:
                    errors.append(f"type-directory mismatch: {relative}")
                if meta.get("status") not in STATUSES:
                    errors.append(f"invalid status: {relative}")
                if meta.get("privacy") not in {"internal", "public"}:
                    errors.append(f"invalid privacy: {relative}")
                if relative.startswith("context/facts/"):
                    atomic_missing = [field for field in ATOMIC_FIELDS if not meta.get(field)]
                    if atomic_missing:
                        errors.append(f"missing atomic fields {atomic_missing}: {relative}")
                    fact_id = meta.get("fact_id", "")
                    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", fact_id) or fact_id != file.stem:
                        errors.append(f"fact_id must match filename: {relative}")
                    if meta.get("salience") not in {"low", "normal", "high"}:
                        errors.append(f"invalid salience: {relative}")
                try:
                    datetime.date.fromisoformat(meta.get("timestamp", ""))
                except ValueError:
                    errors.append(f"invalid timestamp: {relative}")
                dates = {}
                for field in ("valid_from", "valid_to"):
                    try:
                        dates[field] = datetime.date.fromisoformat(meta[field]) if meta.get(field) else None
                    except ValueError:
                        errors.append(f"invalid {field}: {relative}")
                if dates.get("valid_from") and dates.get("valid_to") and \
                        dates["valid_to"] <= dates["valid_from"]:
                    errors.append(f"valid_to must be after valid_from: {relative}")
                successor = meta.get("superseded_by", "")
                if successor:
                    successor_path = (root / successor).resolve()
                    if not successor_path.is_relative_to(root.resolve()) or not successor_path.is_file():
                        errors.append(f"invalid superseded_by target: {relative}")
                    if successor == relative:
                        errors.append(f"superseded_by cannot reference itself: {relative}")
                    if meta.get("status") != "superseded":
                        errors.append(f"superseded_by requires superseded status: {relative}")
                if meta.get("status") == "superseded" and not successor:
                    errors.append(f"superseded status requires superseded_by: {relative}")
                weight = "W3" if layer == "knowledge" and path.name == "skills" else (
                    "W5" if layer == "knowledge" else WEIGHTS[layer])
                rows.append((weight, relative, meta))
    return errors, sorted(rows, key=lambda r: (r[0], r[1]))


def build(root):
    errors, rows = collect(root)
    if errors:
        raise ValueError("LINT ERRORS:\n" + "\n".join(errors))
    header = ["---", "type: Index", "title: 记忆库总索引",
              "description: 记忆标题与调用说明。先扫索引，再按 README 的预算和路由选择正文。",
              "status: active", "privacy: internal", "tags: [索引]",
              f"timestamp: {datetime.date.today()}", "---", "", "# INDEX", "",
              "由 tools/build_index.py 自动生成。ACCESS_LOG、tools 和审计数据不参与召回。",
              "archived、superseded、expired 仅留导航记录；历史须显式调用。", "",
              "| 权重 | 路径 | 标题 | 何时调用 | 状态 |", "|---|---|---|---|---|"]
    escape = lambda s: s.replace("|", "\\|").replace("\n", " ")
    for weight, relative, meta in rows:
        values = [weight, relative, meta["title"], meta["description"], meta["status"]]
        header.append("| " + " | ".join(escape(v) for v in values) + " |")
    text = "\n".join(header) + "\n"
    fd, temporary = tempfile.mkstemp(prefix=".index-", dir=root)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(text)
        os.replace(temporary, root / "INDEX.md")
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return len(rows)


if __name__ == "__main__":
    root = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
    try:
        print(f"indexed {build(root)} files; lint ok")
    except (ValueError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
