#!/usr/bin/env python3
"""Workspace-local task Notes and structured History for cross-window handoff.

[INPUT]: Explicit workspace, ASCII task id, working-state values and event evidence.
[OUTPUT]: .agent-state/tasks/<task>/NOTES.md and append-only HISTORY.jsonl.
[POS]: Task runtime state only; never writes long-term personal memory or full model traces.
[PROTOCOL]: Change this contract, then check CLAUDE.md and ../CLAUDE.md.
"""
from __future__ import annotations
import argparse
import contextlib
import datetime as dt
import fcntl
import json
import os
from pathlib import Path
import re
import tempfile
import uuid

FIELDS = {
    "goal": "Goal",
    "current_status": "Current status",
    "completed": "Completed",
    "pending": "Pending",
    "failed_attempts": "Failed attempts",
    "constraints": "Constraints",
    "evidence": "Evidence pointers",
}
SCALARS = {"goal", "current_status"}
HINT_ORDER = ["Goal", "Current status", "Pending", "Constraints", "Failed attempts",
              "Completed", "Evidence pointers"]


def now():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def task_dir(workspace, task):
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", task):
        raise ValueError("task id requires an ASCII identifier")
    root = Path(workspace).expanduser().resolve()
    if not root.is_dir():
        raise ValueError("workspace does not exist")
    path = (root / ".agent-state" / "tasks" / task).resolve()
    if not path.is_relative_to(root):
        raise ValueError("task state escapes workspace")
    return path


def atomic_write(path, text):
    fd, temporary = tempfile.mkstemp(prefix=".task-state-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@contextlib.contextmanager
def locked(path):
    path.mkdir(parents=True, exist_ok=True)
    with (path / ".lock").open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        yield


def notes_path(path):
    return path / "NOTES.md"


def history_path(path):
    return path / "HISTORY.jsonl"


def require_task(path):
    if not notes_path(path).is_file() or not history_path(path).is_file():
        raise ValueError("task is not initialized")


def template(goal):
    sections = []
    for heading in FIELDS.values():
        value = goal if heading == "Goal" else "Initialized; no execution result yet." \
            if heading == "Current status" else ""
        sections.append(f"## {heading}\n{value}".rstrip())
    return "# Task notes\n\n" + "\n\n".join(sections) + "\n"


def init_task(workspace, task, goal):
    if not goal.strip():
        raise ValueError("goal must be non-empty")
    path = task_dir(workspace, task)
    with locked(path):
        if notes_path(path).exists() or history_path(path).exists():
            raise ValueError("task already exists")
        atomic_write(notes_path(path), template(goal.strip()))
        atomic_write(history_path(path), "")
    return {"task": task, "notes": str(notes_path(path)), "history": str(history_path(path))}


def update_task(workspace, task, field, value):
    if field not in FIELDS:
        raise ValueError(f"unknown field: {field}")
    if not value.strip() or "\n" in value:
        raise ValueError("field value must be non-empty and single-line")
    path = task_dir(workspace, task)
    with locked(path):
        require_task(path)
        text = notes_path(path).read_text(encoding="utf-8")
        heading = FIELDS[field]
        pattern = rf"(?ms)^## {re.escape(heading)}\n.*?(?=^## |\Z)"
        replacement = f"## {heading}\n{value.strip()}" if field in SCALARS else None
        if replacement is None:
            match = re.search(pattern, text)
            if not match:
                raise ValueError(f"notes section missing: {heading}")
            replacement = match.group(0).rstrip() + f"\n- {value.strip()}"
        updated, count = re.subn(pattern, lambda _: replacement.rstrip() + "\n\n", text, count=1)
        if count != 1:
            raise ValueError(f"notes section missing: {heading}")
        updated = updated.rstrip() + "\n"
        atomic_write(notes_path(path), updated)
        if notes_path(path).read_text(encoding="utf-8") != updated:
            raise ValueError("notes read-back mismatch")
    return {"task": task, "field": field, "updated": True}


def add_event(workspace, task, kind, summary, evidence=()):
    if not re.fullmatch(r"[a-z][a-z0-9_-]{0,40}", kind):
        raise ValueError("event kind must be lowercase ASCII")
    if not summary.strip():
        raise ValueError("event summary must be non-empty")
    path = task_dir(workspace, task)
    with locked(path):
        require_task(path)
        event = {"event_id": uuid.uuid4().hex[:16], "at": now(), "kind": kind,
                 "summary": summary.strip(), "evidence": list(evidence)}
        with history_path(path).open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(event, ensure_ascii=False) + "\n")
    return {"task": task, "event": event}


def sections(text):
    result = {}
    matches = list(re.finditer(r"(?m)^## (.+)$", text))
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        result[match.group(1)] = text[match.end():end].strip()
    return result


def hint_task(workspace, task, max_chars):
    if max_chars < 80:
        raise ValueError("max_chars must be at least 80")
    path = task_dir(workspace, task)
    require_task(path)
    data = sections(notes_path(path).read_text(encoding="utf-8"))
    output, truncated = [], False
    for heading in HINT_ORDER:
        content = data.get(heading, "")
        if not content:
            continue
        block = f"## {heading}\n{content}"
        candidate = "\n\n".join(output + [block])
        if len(candidate) > max_chars:
            truncated = True
            break
        output.append(block)
    hint = "\n\n".join(output)
    if not hint:
        raise ValueError("max_chars cannot fit the first working-state section")
    return {"task": task, "chars": len(hint), "truncated": truncated, "hint": hint}


def search_task(workspace, task, query):
    if not query.strip():
        raise ValueError("search query must be non-empty")
    path = task_dir(workspace, task)
    require_task(path)
    needle = query.casefold()
    matches = []
    for source, file in (("notes", notes_path(path)), ("history", history_path(path))):
        for number, line in enumerate(file.read_text(encoding="utf-8").splitlines(), 1):
            if needle in line.casefold():
                matches.append({"source": source, "line": number, "text": line})
    return {"task": task, "query": query, "matches": matches}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--task", required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init")
    init.add_argument("--goal", required=True)
    update = commands.add_parser("update")
    update.add_argument("--field", choices=sorted(FIELDS), required=True)
    update.add_argument("--value", required=True)
    event = commands.add_parser("event")
    event.add_argument("--kind", required=True)
    event.add_argument("--summary", required=True)
    event.add_argument("--evidence", action="append", default=[])
    commands.add_parser("show")
    hint = commands.add_parser("hint")
    hint.add_argument("--max-chars", type=int, default=1200)
    search = commands.add_parser("search")
    search.add_argument("--query", required=True)
    args = parser.parse_args()
    try:
        if args.command == "init":
            result = init_task(args.workspace, args.task, args.goal)
        elif args.command == "update":
            result = update_task(args.workspace, args.task, args.field, args.value)
        elif args.command == "event":
            result = add_event(args.workspace, args.task, args.kind, args.summary, args.evidence)
        elif args.command == "show":
            path = task_dir(args.workspace, args.task)
            require_task(path)
            result = {"task": args.task, "notes": notes_path(path).read_text(encoding="utf-8")}
        elif args.command == "hint":
            result = hint_task(args.workspace, args.task, args.max_chars)
        else:
            result = search_task(args.workspace, args.task, args.query)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (ValueError, OSError, TypeError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
