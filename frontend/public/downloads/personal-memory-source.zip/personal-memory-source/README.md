# personal-memory · 公开源码摘录

这套记忆库的设计是「归本人所有、带预算、有审批」。本包只公开运行时脚本与工具地图，用于展示实现，不含任何记忆正文。

## 包含

- `tools/memory_runtime.py`：召回打包、query 编译、访问回执、使用回执、写入审计、cue 门禁、蒸馏与遗忘报告
- `tools/build_index.py`：从 frontmatter 编译导航索引
- `tools/task_state.py`：长任务的 NOTES / HISTORY 状态记录
- `tools/CLAUDE.md`：工具地图与执行约定

## 有意排除

- `identity/`、`principles/`、`preferences/`、`context/`、`knowledge/`：个人记忆正文
- `BASELINE.md`、`INDEX.md`、`ACCESS_LOG.md`：基线与读取记录
- `write_audit.jsonl`、`recall_outcome.jsonl`、`distill_decisions.jsonl`：审计与回执数据
- `test_*.py`：回归用例里含内部业务口径举例

## 说明

代码从个人工作库中摘出，依赖同库的目录约定，单独运行需要补齐记忆目录。
五层两级结构、8000 字符预算、写入分级授权与四项认知机制的设计说明，见作品集案例页。
